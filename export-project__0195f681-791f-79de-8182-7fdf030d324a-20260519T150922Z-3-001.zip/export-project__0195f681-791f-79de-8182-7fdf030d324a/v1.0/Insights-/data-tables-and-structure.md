---
title: "Data tables and structure"
slug: "data-tables-and-structure"
excerpt: ""
hidden: true
createdAt: "Thu Mar 28 2024 09:47:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Mar 28 2024 09:47:52 GMT+0000 (Coordinated Universal Time)"
---
