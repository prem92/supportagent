---
title: "Data Exports"
slug: "data-exports"
excerpt: ""
hidden: true
createdAt: "Tue Aug 20 2024 09:14:44 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 09 2024 10:40:34 GMT+0000 (Coordinated Universal Time)"
---
# Introduction

Data Exports is a feature that allows us to share data that is stored in Capillary's system, with the brand via a secure FTP location. The brand can use this data for:

- Conducting detailed analysis on customer behaviour, transactions, or campaigns; 
- Integrating the exported data into external tools for analysis; or
- Retrieving comprehensive member data. 

> 📘 Note
> 
> Brands are required to have their own Secure FTP (SFTP) infrastructure to utilize this feature. Currently, Capillary supports data exports only via SFTP.

# Templates

You can set up an export job using either predefined standard templates or custom templates. 

Standard templates allow us to share data as is stored in the system in the form of facts, and dimensions.

Whereas custom templates are used to share aggregated metrics, built using KPIs, and dimensions. Custom templates give more flexibility in exporting data at a granular level.

For example, you can use a standard template to export transaction-level data as it is stored in our system. However, if you need KPIs at the customer level, you need to use custom templates.

(GIVE LINK TO STANDARD AND CUSTOM TEMPLATES)

# Use cases

Few scenarios where data exports help us are:

- Create custom templates for data export, according to your requirement, such as:
  - Export data of customers who received messages of a specific campaign.
  - Export the dataset of loyalty points scheduled for expiration on a specified date.
- Export custom fields, extended fields, and Profile V2 (profiles other than Instore, such as WebEngage and WhatsApp) data.
- Retrieve data based on either the most recent update or the original event date.
- Export IDs for stores, users, and products.
- Export a specific audience list.
- Automatically sync data based on the latest table updates.

<br />

# Limitations

- Supports a maximum of one year's data. The maximum size of the file which can be exported is 20GB. If the exported file exceeds this limit, a validation error is triggered.
- Always work with incremental datasets, which include only the updates or changes since the last export or processing. This approach optimizes resource use and efficiency, especially with large data volumes.
- You can select a maximum of five dimensions in a custom template for an export job.

<br />

> 📘 Note
> 
> - Please note that you cannot:
>   - Edit the template after creation.
>   - Modify KPIs, dimensions, filters, and customer list once scheduled.
>   - Export measures (such as bill id, bill number, bill amount, auto update time) and custom fields in custom templates. You can export only KPIs and its dimensions.
> - Current day's data will not be included in the exported data as the data will be synced to the capillary server only during non-business hours.

<br />

# Prerequisites

- Insights access
- FTP server configuration (ADD LINK)

For more questions, refer to the Data Export FAQs. (ADD LINK, add FAQ page as the last page)
