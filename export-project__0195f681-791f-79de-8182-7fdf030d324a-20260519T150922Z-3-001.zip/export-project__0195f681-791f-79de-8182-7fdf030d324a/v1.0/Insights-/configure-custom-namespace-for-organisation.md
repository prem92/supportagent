---
title: "Custom Namespace for Organisation"
slug: "configure-custom-namespace-for-organisation"
excerpt: ""
hidden: false
createdAt: "Sun Jan 29 2023 10:54:59 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
As are moving towards onboarding more brands across verticals such as fuel retail, hospitality, CPG and so on in past years. With this, demands to make the reporting customization have also increased. 

We have now introduced the conversion of UI labels in Insights+ for the airline industry. For eg - Currently, across an organization, an airline vertical may not want to see points mentioned anywhere in its reporting view. Instead, you can now enable custom namespace conversion under the organization settings and points will be replaced with miles across the organization in Insights+.

Below images show how the UI labels change once the custom namespace feature is enabled.

> Please note: The feature is now enabled for aviation-focused organizations initially on a pilot basis. We will be rolling out soon for other verticals over the next quarters.

To enable a custom namespace -

1. Go to organization settings.

2. Under Organization Setup -\> Organization Profile

3. Click Edit.

4. Select Org Locale.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f39f937-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Click on "Enable Custom Namespace"

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8b7fa6b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Once the settings are applied click submit.

> Note : It takes 24 hours for the changes to take place across org.
