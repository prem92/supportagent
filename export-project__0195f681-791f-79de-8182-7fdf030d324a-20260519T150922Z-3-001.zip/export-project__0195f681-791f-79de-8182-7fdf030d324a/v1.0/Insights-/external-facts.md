---
title: "External facts"
slug: "external-facts"
excerpt: ""
hidden: true
createdAt: "Mon Dec 06 2021 20:06:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
