---
title: "Standard templates"
slug: "standard-templates"
excerpt: ""
hidden: true
createdAt: "Mon Dec 06 2021 20:06:41 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Sep 12 2024 04:46:56 GMT+0000 (Coordinated Universal Time)"
---
