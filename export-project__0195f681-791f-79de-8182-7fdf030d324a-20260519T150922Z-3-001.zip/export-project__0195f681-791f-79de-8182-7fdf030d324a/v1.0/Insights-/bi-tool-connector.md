---
title: "BI Tool Connector"
slug: "bi-tool-connector"
excerpt: ""
hidden: false
createdAt: "Tue May 23 2023 17:46:31 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
## Bi Tool Connectors

#### What BI Tool connectors?

BI Tool connector is a solution that enables connectivity between the Data Analytics tool to a data source. Data Connectors enable you to connect your data sources to the Visulatisation tools securely without expensive re-engineering, testing, or retraining.

#### How can we access BI Tool Connector?

BI Tool connector can be used by creating a private cluster within databricks. You can contact your CSM or Sales team to get a databricks license. Please refer to the process below -

[Read here](https://docs.capillarytech.com/changelog/insights-ond22)
