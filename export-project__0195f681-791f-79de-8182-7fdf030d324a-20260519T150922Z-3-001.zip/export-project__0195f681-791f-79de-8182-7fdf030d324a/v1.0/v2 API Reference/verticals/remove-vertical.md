---
title: "Remove Vertical"
slug: "remove-vertical"
excerpt: "This lets you remove a vertical from the org."
hidden: true
createdAt: "Fri May 27 2022 07:21:27 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:32 GMT+0000 (Coordinated Universal Time)"
---
