---
title: "Get Active Verticals"
slug: "get-active-verticals"
excerpt: "Retrieves the list of verticals enabled for the org (active verticals)."
hidden: true
createdAt: "Fri May 27 2022 07:26:47 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:32 GMT+0000 (Coordinated Universal Time)"
---
