---
title: "Add Vertical"
slug: "add-vertical"
excerpt: "This lets you add a new vertical to an org."
hidden: true
createdAt: "Fri May 27 2022 07:12:01 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:33 GMT+0000 (Coordinated Universal Time)"
---
