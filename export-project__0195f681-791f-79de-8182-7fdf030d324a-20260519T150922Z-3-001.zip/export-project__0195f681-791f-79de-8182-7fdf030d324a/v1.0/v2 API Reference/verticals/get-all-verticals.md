---
title: "Get All Verticals"
slug: "get-all-verticals"
excerpt: "Retrieves the list of all verticals available for the org. This include both active and inactive verticals."
hidden: true
createdAt: "Fri May 27 2022 07:24:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:31 GMT+0000 (Coordinated Universal Time)"
---
