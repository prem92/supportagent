---
title: "Get Fleet Permissions"
slug: "get-fleet-permissions"
excerpt: "Retrieves permissions configured for the fleet."
hidden: true
createdAt: "Tue May 31 2022 07:38:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:31 GMT+0000 (Coordinated Universal Time)"
---
