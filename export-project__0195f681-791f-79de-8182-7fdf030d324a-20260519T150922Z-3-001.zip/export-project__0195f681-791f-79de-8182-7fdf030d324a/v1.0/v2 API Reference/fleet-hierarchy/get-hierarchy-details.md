---
title: "Get Hierarchy Details"
slug: "get-hierarchy-details"
excerpt: "Retrieves details of a specific hierarchy. You cannot fetch the details of an inactive hierarchy."
hidden: true
createdAt: "Tue May 31 2022 07:32:27 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:32 GMT+0000 (Coordinated Universal Time)"
---
