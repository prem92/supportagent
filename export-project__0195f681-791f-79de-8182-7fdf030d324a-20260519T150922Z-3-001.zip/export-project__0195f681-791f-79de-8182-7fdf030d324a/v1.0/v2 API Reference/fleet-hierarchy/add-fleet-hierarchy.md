---
title: "Add Fleet Hierarchy"
slug: "add-fleet-hierarchy"
excerpt: "Lets you create the business hierarchy for the org."
hidden: true
createdAt: "Tue May 31 2022 07:14:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:31 GMT+0000 (Coordinated Universal Time)"
---
