---
title: "Get Brand Rewards"
slug: "get-brand-rewards"
excerpt: "Retrieves rewards of a specific brand."
hidden: true
createdAt: "Fri Jun 10 2022 07:42:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:31 GMT+0000 (Coordinated Universal Time)"
---
