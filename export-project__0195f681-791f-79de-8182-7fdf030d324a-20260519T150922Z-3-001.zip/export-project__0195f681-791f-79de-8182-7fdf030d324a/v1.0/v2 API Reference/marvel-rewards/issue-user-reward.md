---
title: "Issue User Reward"
slug: "issue-user-reward"
excerpt: "Lets you issue rewards to a specific customer. Customer points are deducted according to the voucher issued."
hidden: true
createdAt: "Fri Jun 10 2022 08:57:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:33 GMT+0000 (Coordinated Universal Time)"
---
