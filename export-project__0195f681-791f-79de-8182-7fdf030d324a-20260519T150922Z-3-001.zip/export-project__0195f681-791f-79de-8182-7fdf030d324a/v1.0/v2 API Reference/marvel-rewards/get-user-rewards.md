---
title: "Get User Rewards"
slug: "get-user-rewards"
excerpt: "Retrieves rewards of a specific customer."
hidden: true
createdAt: "Fri Jun 10 2022 07:53:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:32 GMT+0000 (Coordinated Universal Time)"
---
