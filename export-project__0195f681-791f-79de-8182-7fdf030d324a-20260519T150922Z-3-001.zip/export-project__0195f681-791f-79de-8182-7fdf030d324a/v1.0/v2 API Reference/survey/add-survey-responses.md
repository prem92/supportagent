---
title: "Add Survey Responses"
slug: "add-survey-responses"
excerpt: "Lets you add customer responses to a survey."
hidden: true
createdAt: "Tue May 24 2022 17:05:46 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:32 GMT+0000 (Coordinated Universal Time)"
---
