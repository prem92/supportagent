---
title: "Update Survey"
slug: "update-survey"
excerpt: "Lets you update an existing survey."
hidden: true
createdAt: "Tue May 24 2022 16:31:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:31 GMT+0000 (Coordinated Universal Time)"
---
> 📘 At least one query parameter is mandatory
