---
title: "Create Survey"
slug: "create-survey"
excerpt: "Lets you create a new survey."
hidden: true
createdAt: "Tue May 24 2022 16:21:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:32 GMT+0000 (Coordinated Universal Time)"
---
