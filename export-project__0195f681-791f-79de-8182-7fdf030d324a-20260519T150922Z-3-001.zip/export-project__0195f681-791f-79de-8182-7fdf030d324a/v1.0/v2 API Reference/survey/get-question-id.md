---
title: "Get Question ID"
slug: "get-question-id"
excerpt: "Retrieves the ID of a specific survey question."
hidden: true
createdAt: "Wed May 25 2022 06:48:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:31 GMT+0000 (Coordinated Universal Time)"
---
> 📘 In response, `entity` is the unique ID of the question.
