---
title: "Add Survey Questions"
slug: "add-survey-questions"
excerpt: "Lets you add questions to an existing survey."
hidden: true
createdAt: "Tue May 24 2022 16:48:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:31 GMT+0000 (Coordinated Universal Time)"
---
> 📘 At least one query parameter is mandatory.
