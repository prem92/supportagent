---
title: "Get All Survey Questions"
slug: "get-survey-questions"
excerpt: "Retrieves all questions of a specific survey using surveyId or external reference ID."
hidden: true
createdAt: "Wed May 25 2022 06:39:15 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:32 GMT+0000 (Coordinated Universal Time)"
---
