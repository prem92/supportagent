---
title: "Coupon Upload"
slug: "coupon-upload-copy"
excerpt: "This resource consists of APIs related to batch coupon operations."
hidden: true
createdAt: "Wed Aug 16 2023 06:49:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jun 06 2024 10:16:48 GMT+0000 (Coordinated Universal Time)"
---
> 📘 This is not a v2 API. Hence, all the API details including host and headers are provided in this section itself.

# Host URLs

- **India**: <https://intouch.capillary.co.in>
- **Apac2**: <https://apac2.intouch.capillarytech.com>
- **EU**: <https://eu.intouch.capillarytech.com>
- **China**: <https://intouch.capillarytech.cn.com>
