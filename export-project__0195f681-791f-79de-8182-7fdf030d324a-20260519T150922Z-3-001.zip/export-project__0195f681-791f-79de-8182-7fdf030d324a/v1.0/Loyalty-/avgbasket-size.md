---
title: "Profile : Current Customer"
slug: "avgbasket-size"
excerpt: ""
hidden: false
createdAt: "Mon Aug 14 2023 14:19:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Sun Aug 11 2024 17:29:16 GMT+0000 (Coordinated Universal Time)"
---
currentCustomer (Customer Profile)- Allows you to write conditions based on the properties of the customer who is currently performing the activity. 

## Attributes - Customer Identity

_The below grouping of attributes is based on customer identity information. _

[block:parameters]
{
  "data": {
    "h-0": "Attributes",
    "h-1": "Definition",
    "h-2": "Link",
    "0-0": "name",
    "0-1": "Customer’s Full Name.",
    "0-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#name)",
    "1-0": "firstname",
    "1-1": "Customer’s First Name  \nstring.",
    "1-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#first-name--last-name-)",
    "2-0": "lastname",
    "2-1": "Customer’s Last Name.",
    "2-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#first-name--last-name-)",
    "3-0": "email",
    "3-1": "Customer's Email ID.",
    "3-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#email)",
    "4-0": "externalId",
    "4-1": "Customer's External ID.",
    "4-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#external-id-externalid)",
    "5-0": "mobile",
    "5-1": "Mobile number of a customer.",
    "5-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#mobile)",
    "6-0": "hasInstoreProfile",
    "6-1": "Checks if the current customer is registered and has an in-store Profile.",
    "6-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#hasinstoreprofile)",
    "7-0": "hasWeChatProfile",
    "7-1": "Returns True, if the current customer has a WeChat Profile.",
    "7-2": "[Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#haswechatprofile)"
  },
  "cols": 3,
  "rows": 8,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


## Attributes - Custom Field

_The below grouping of attributes is based on custom fields created at the customer level._

| Attributes               | Definition                                                        | Link                                                                                               |
| :----------------------- | :---------------------------------------------------------------- | :------------------------------------------------------------------------------------------------- |
| customFieldValueIncludes | Check if the customer has some custom field present with a value. | [Learn More](https://docs.capillarytech.com/docs/attributes-custom-field#customfieldvalueincludes) |
| customFieldValueExcludes | If the customer has some custom field present.                    | [Learn More](https://docs.capillarytech.com/docs/attributes-custom-field#customfieldvalueexcludes) |
| customFieldValueExists   | checks If the customer data has some custom field present.        | [Learn More](https://docs.capillarytech.com/docs/attributes-custom-field#customfieldvalueexists)   |

## Attributes - KPI based on Points

_The below grouping of attributes is based on the Key Performance Indicators on customer's points. _

| Attributes            | Definition                                                        | Link                                                                                                                |
| :-------------------- | :---------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------ |
| currentPoints         | Customer's current redeemable points.                             | [Learn More](https://docs.capillarytech.com/docs/attributes-current-customer-points#attribute--currentpoints)       |
| initialCurrentPoints  | Customer's current redeemable points before evaluating the event. | [Learn More](https://docs.capillarytech.com/docs/attributes-current-customer-points#attribute-initialcurrentpoints) |
| currentAllPoints      | The sum of all Points, redeemable as well as Promised Points.     | [Learn More](https://docs.capillarytech.com/docs/attributes-current-customer-points#currentallpoints)               |
| lifetimePoints        | Total points earned by a customer from the date of registration.  | [Learn More](https://docs.capillarytech.com/docs/attributes-current-customer-points#lifetimepoints)                 |
| lifetimeAllPoints     | The sum of lifetimePoints and lifetimeNonRedeemablePoints.        | [Learn More](https://docs.capillarytech.com/docs/attributes-current-customer-points#lifetimeallpoints)              |
| initialLifetimePoints | Customer's lifetime redeemable points before the current event.   | [Learn More](https://docs.capillarytech.com/docs/attributes-current-customer-points#intiallifetimepoints)           |

## Attributes - KPI based on transaction data

_The below grouping is done based on the Key Performance Indicators on the customer's transaction data._

| Attributes              | Definition                                                                | Link                                                                                        |
| :---------------------- | :------------------------------------------------------------------------ | :------------------------------------------------------------------------------------------ |
| avgBasketSize           | Returns the average number of line items present in a transaction.        | [Learn More](https://docs.capillarytech.com/docs/attributes-kpis#1-attribute-avgbasketsize) |
| avgSpendPerVisit        | This is the average amount a customer is spending on a transaction.       | [Learn More](https://docs.capillarytech.com/docs/attributes-kpis#2-avgspendpervisit)        |
| numberOfTxns            | Number of transactions since the registration date of the customer        | [Learn More](https://docs.capillarytech.com/docs/attributes-kpis#3-numberoftxns)            |
| numberOfTxnsToday       | Number of transactions made by a customer on the current day.             | [Learn More](https://docs.capillarytech.com/docs/attributes-kpis#4-numberoftxnstoday)       |
| numberOfVisits          | Number of unique days when a customer made the transaction                | [Learn More](https://docs.capillarytech.com/docs/attributes-kpis#5-numberofvisits)          |
| lifetimePurchase        | Customer's purchases since start including current transaction's purchase | [Learn More](https://docs.capillarytech.com/docs/attributes-kpis#6-lifetimepurchase)        |
| InitialLifetimePurchase | Customer's purchase since start before current transaction's purchase     | [Learn More](https://docs.capillarytech.com/docs/attributes-kpis#7-initiallifetimepurchase) |

## Attributes - Date

| Attribute | Definition        | Link                                                                          |
| :-------- | :---------------- | :---------------------------------------------------------------------------- |
| joinDate  | Registration date | [Learn More](https://docs.capillarytech.com/docs/attribute-joindate#joindate) |

## Attributes - Tracker based

[block:parameters]
{
  "data": {
    "h-0": "Attribute",
    "h-1": "Definition",
    "0-0": "trackerValueBeforeEvent",
    "0-1": "Gets the tracker value of a customer excluding the current event. Can be used in any set of the workflows, and can be used in loyalty promotions also.  \n  \nTrackers that are created based on alternate currencies will only work with this profile, as those tracker won't be visible in tracker/points-tracker sets.  \n  \n**E.g.:**currentCustomer.trackerValueBeforeEvent(\"Tracker name\", \"Case name\")>\\<=X",
    "1-0": "trackerValueCurrentEvent",
    "1-1": "Gets the tracker value of a customer including the changes that happened during the current event (until the previous set). Can be used in any set of the workflows (evaluation set, end set), and can be used in loyalty promotions also.  \n  \nTrackers that are created based on alternate currencies will only work with this profile, as those tracker won't be visible in tracker/points-tracker sets.  \n  \n**E.g.:**currentCustomer.trackerValueCurrentEvent(\"Tracker name\", \"Case name\")>\\<=X"
  },
  "cols": 2,
  "rows": 2,
  "align": [
    "left",
    "left"
  ]
}
[/block]


## Attributes - Slab Information

_This grouping of attributes is done on the basis of Tier/Slab Information associated with the customer's loyalty. _

| Attributes        | Definition                                                              | Link                                                                                           |
| :---------------- | :---------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------- |
| initialSlabName   | Initial slab name of the Current Customer before evaluating an event.   | [Learn More](https://docs.capillarytech.com/docs/attribute-slab-information#initialslabname)   |
| initialSlabNumber | Initial slab number of the Current Customer before evaluating an event. | [Learn More](https://docs.capillarytech.com/docs/attribute-slab-information#initialslabnumber) |
| slabName          | Customer’s current tier name.                                           | [Learn More](https://docs.capillarytech.com/docs/attribute-slab-information#slabname)          |
| slabNumber        | Current Customer slab number let's say 10, 1, 3, etc                    | [Learn More](https://docs.capillarytech.com/docs/attribute-slab-information#slabnumber)        |

## Attributes - User Segment (EI)

_This grouping of attributes is based on the User Segment (Cluster) creations over the customer's base by brands. _

| Attributes           | Definition                                                                     | Link                                                                                                |
| :------------------- | :----------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------- |
| clusterValueIncludes | Returns true, if a customer belongs to a particular cluster (segment).         | [Learn More](https://docs.capillarytech.com/docs/user-segment-ei-attributes#cluster-value-includes) |
| clusterValueExcludes | Returns true, if a customer does not belong to a particular cluster (segment). | [Learn More](https://docs.capillarytech.com/docs/user-segment-ei-attributes#cluster-value-excludes) |

## Attribute - Other

| Attribute | Definition                                                                   | Link                                                                                         |
| :-------- | :--------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------- |
| isLoyal   | Checks if the current customer is registered in the brand's loyalty program. | [Learn More](https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name#isloyal) |

## Attribute - Customer status & label

| Attribute           | Definition                                                       | Link                                                                        |
| :------------------ | :--------------------------------------------------------------- | :-------------------------------------------------------------------------- |
| customerStatus      | When one wants to write rules based on the staus of the customer | [Link](https://docs.capillarytech.com/docs/attribute-customer-status-label) |
| customerStatusLabel | When one wants to write rules based on the label of the customer | [Link](https://docs.capillarytech.com/docs/attribute-customer-status-label) |

## Attribute - Milestones & Streaks

<br />

[block:parameters]
{
  "data": {
    "h-0": "Attribute",
    "h-1": "Definition",
    "h-2": "Link",
    "0-0": "avgTargetAchieved(targetName)",
    "0-1": "Returns the average of the target value achieved by the customer across the cycles of the milestone (target). ",
    "0-2": "[Link](https://docs.capillarytech.com/docs/attributes-milestones-streaks#avgtargetachievedtargetname)",
    "1-0": "targetAchievedInPeriod(targetName, periodRefCode)",
    "1-1": "Returns the target value achieved by the customer in a specific cycle/period of a particular milestone.  \n  \n`periodRefCode` is the name of the cycle, not the cycle ID.",
    "1-2": "[Link](https://docs.capillarytech.com/docs/attributes-milestones-streaks#targetachievedinperiodtargetname-periodrefcode)",
    "2-0": "isStreakAchieved(streakName)",
    "2-1": "Returns a true/false value indicating whether a user has achieved a specific streak level. Assume there is a streak (ABC) with two levels in it (ABC_1, ABC_2).  \n  \nThis will indicate whether the customer has achieved the specific level or not.",
    "2-2": "[Link](https://docs.capillarytech.com/docs/attributes-milestones-streaks#isstreakachievedstreakname)",
    "3-0": "streakCurrentValue(streakName)",
    "3-1": "Returns the current streak value of the customer (instead of a simple true/false) for a specific streak level.",
    "3-2": "[Link](https://docs.capillarytech.com/docs/attributes-milestones-streaks#streakcurrentvaluestreakname)",
    "4-0": "targetsAchievedForUnified(unifiedTargetGroupName, periodRefCode)",
    "4-1": "Returns the number of targets achieved by the user in a specific cycle/period of a specific unified target.  \n  \nAssume there is a unified target (ABC) that contains three targets (A, B, C) which the user has to achieve. This will return the number of targets achieved by the user in a cycle of ABC.",
    "4-2": "[Link](https://docs.capillarytech.com/docs/attributes-milestones-streaks#targetsachievedforunifiedunifiedtargetgroupname-periodrefcode)",
    "5-0": "targetAchievedInCurrentPeriod(targetName)",
    "5-1": "Returns the target value achieved by the customer during the current cycle.  \nOnly target name is required here and there's no need to specify the cycle's refCode. If there is no current cycle, the return value will be 0.",
    "5-2": "[Link](https://docs.capillarytech.com/docs/attributes-milestones-streaks#targetachievedincurrentperiodtargetname)",
    "6-0": "targetsAchievedForUnifiedInCurrentPeriod(unifiedTargetGroupName)",
    "6-1": "Returns the number of targets achieved by the user during the current cycle of a specific unified target.  \nOnly target name is required here and there's no need to specify the cycle's refCode If there is no current cycle, the return value will be 0.",
    "6-2": "[Link](https://docs.capillarytech.com/docs/attributes-milestones-streaks#targetsachievedforunifiedincurrentperiodunifiedtargetgroupname)"
  },
  "cols": 3,
  "rows": 7,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]
