---
title: "Attributes - Group Primary Customer's Custom Field."
slug: "custom-field"
excerpt: ""
hidden: true
createdAt: "Mon Aug 14 2023 14:26:02 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
# Profile - Group Primary Customer (groupPrimaryCustomer)

**Custom Fields : **Custom fields are columns that store special or custom information related to customers, transactions, transaction line-items, coupons, category and so on. 

The following are different entries for which you can create custom fields.

1. Loyalty registration
2. Loyalty transaction
3. Customer feedback
4. Zone custom fields
5. Store custom fields
6. Points redemption
7. Voucher redemption (coupon redemption)
8. Customer advanced feedback
9. Customer preferences
10. Customer Card  
    To know how to create a Custom Fields, [click here](https://docs.capillarytech.com/docs/data-fields#create-new-custom-fields)

**Attributes : **Attributes based on Custom Fields for Customer profile are listed below in the table.

[block:parameters]
{
  "data": {
    "h-0": "Profile",
    "h-1": "Data Type",
    "h-2": "Description",
    "h-3": "Sub-Attributes",
    "0-0": "customFieldValueIncludes",
    "0-1": "boolean",
    "0-2": "checks If group Primary customer has some custom field present with particular value",
    "0-3": "Sub-Attributes 1: custom Field Name  \nSub-Attributes 2: Value of custom field",
    "1-0": "customFieldValueExists",
    "1-1": "boolean",
    "1-2": "checks If Primary customer of a group has some custom field present.",
    "1-3": "Sub-Attribute 1: Custom field Value",
    "2-0": "customFieldValueExcludes",
    "2-1": "boolean",
    "2-2": "checks If Primary customer of a group has some custom field is not present with particular value",
    "2-3": "Sub-Attributes 1: custom Field Name  \nSub-Attributes 2: Value of custom field"
  },
  "cols": 4,
  "rows": 3,
  "align": [
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


## **customFieldValueIncludes**

Profile: groupPrimaryCustomer  
Attribute: customFieldValueIncludes  
Data Type: Boolean  
Description: Lets you evaluate conditions on a custom field value of the primary member (if a specific custom field value exists for the member).  
Sub-Attributes: Custom Field Name, Custom Field Value  
Syntax: groupPrimaryCustomer.customFieldValueIncludes(“custom_field_name”,”custom_field_value”)

| Example 1: Let’s see we have created a custom field by the name of cities and value includes Delhi, Indore, Bangalore, etc. Now a marketing manager wants to provide incentives to those Primary customers of a group who are from Bangalore. |
| :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Rule: groupPrimaryCustomer.customFieldValueExcludes("cities","Bangalore")                                                                                                                                                                     |

[block:parameters]
{
  "data": {
    "h-0": "Example 2: Suppose the college team in your city has won a major championship and you want to celebrate the event by offering discounts to primary customers of a group who had included that sport as their favorite.",
    "0-0": "Rule: To issue coupons to customers who had included SportX as their favorite, use the following condition:  \ngroupPrimaryCustomer.customFieldValueIncludes(\"Favorite_Sport\",\"SportX\")  \nIf the value returned is SportX, then the coupon is issued."
  },
  "cols": 1,
  "rows": 1,
  "align": [
    "left"
  ]
}
[/block]


| Example 3: Rule to check if the primary customer of a group is in age group between 25-40 or 40-90 and gender is Male & current transaction basket contains POLO and number of transactions done is greater than 1.                                                                                |
| :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Rule: (groupPrimaryCustomer.customFieldValueIncludes("age","25-40")\|\|groupPrimaryCustomer.customFieldValueIncludes("age","40-90"))&&(groupPrimaryCustomer.customFieldValueIncludes("gender","Male"))&&(currentTxn.basketIncludes("Producttype","polo"))&&(groupPrimaryCustomer.numberOfVisits>1) |

***

## **customFieldValueExcludes**

\*Profile : groupPrimaryCustomer  
Attribute : customFieldValueExcludes  
Data Type: Boolean  
Description : Lets you evaluate conditions on a custom field value of the customer. (Any value other than the value you mention here)  
Sub-Attributes: Custom Field Name, Custom Field Value  
Syntax: groupPrimaryCustomer.customFieldValueExcludes(“custom_field_name”,”custom_field_value”)

| Example 1: As a marketing manager I want to check if the customer is from homeclub_number and value 12 or 11.                                       |
| :-------------------------------------------------------------------------------------------------------------------------------------------------- |
| Rule:groupPrimaryCustomer.customFieldValueExcludes("homeclub_number","12")\|\|groupPrimaryCustomer.customFieldValueExcludes("homeclub_number","11") |

| Example 2 : Write an expression to evaluate that primary customer of a group, DVS custom field value is Home lovers and preferred language is not Arabic. |
| :-------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Rule : groupPrimaryCustomer.clusterValueIncludes("DVS","Home Lovers")&&(groupPrimaryCustomer.customFieldValueExcludes("preferredlanguage","Arabic"))      |

***

## **customFieldValueExists**

Profile : groupPrimaryCustomer  
Attribute : customFieldValueExists  
Data Type : Boolean  
Description : Lets you evaluate conditions on a custom field value of the primary member ( if a specific custom field value exists for the member).  
Sub-Attributes: Custom Field Name  
Syntax: groupProfileCustomer.customFieldValueExists(“custom_field_name”,”custom_field_value”)

| Example 1: Write a rule to check if primary customer of a group has a custom field by the name billdelayed. |
| :---------------------------------------------------------------------------------------------------------- |
| groupProfileCustomer.customFieldValueExists(“billdelayed”)                                                  |
