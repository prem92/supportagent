---
title: "Loyalty Settings"
slug: "loyalty-settings-2"
excerpt: ""
hidden: false
createdAt: "Wed Jul 26 2023 05:42:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
These are the setting in the Loyalty+ module, which are present in the top navigation panel, right corner. 

These setting are at an org level, and not at a program level.
