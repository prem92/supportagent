---
title: "Loyalty activities, rules & actions"
slug: "loyalty-activities-rules-actions"
excerpt: ""
hidden: true
createdAt: "Tue Feb 01 2022 10:21:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
## Activities

A rule expression is a combination of profile, attributes, sub-attributes (for selected attributes), operators, and expression values. Profiles might vary based on the activity and accordingly the attributes, and sub-attributes.

The following table provides the list of profiles supported for each activity. Each profile supports  certain attributes. Click on a profile to see more details.

[block:parameters]
{
  "data": {
    "h-0": "Activity",
    "h-1": "Description",
    "h-2": "Supported Profiles",
    "0-0": "Make a transaction (TransactionAdd)",
    "0-1": "Transaction Add is a combination of a new transaction and tracker finished activities.  Here, you can evaluate conditions and execute actions on a new transaction, tracker, and transaction complete activities.",
    "0-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[currentTracker](https://capillary-documentation.readme.io/docs/profiles-attributes#current-tracker-currenttracker)  \n[currentTrackerCondition](https://capillary-documentation.readme.io/docs/profiles-attributes#current-tracker-condition-currenttrackercondition)  \n[currentTxn](https://capillary-documentation.readme.io/docs/profiles-attributes#current-transaction-currenttxn)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)  \n[referrerCode](https://capillary-documentation.readme.io/docs/profiles-attributes#referrer-code-referrercode)  \n[tenderProfile](https://capillary-documentation.readme.io/docs/profiles-attributes#tender-profile-tenderprofile)",
    "1-0": "DelayedAccrual",
    "1-1": "Credits points to customer account after a specific number of days.",
    "1-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)",
    "2-0": "CustomerRegistration",
    "2-1": "Create rules and execute actions on a new customer registration activity.",
    "2-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)  \n[referrerCode](https://capillary-documentation.readme.io/docs/profiles-attributes#referrer-code-referrercode)",
    "3-0": "PointsRedemption",
    "3-1": "Configure rules and actions on points redemption activity.  \nEven before validating points redemption conditions, the system checks whether the points are redeemable.",
    "3-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)",
    "4-0": "CouponRedemption",
    "4-1": "Define rules and conditions on coupon redemption activity.",
    "4-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)",
    "5-0": "ReturnTransaction",
    "5-1": "Configure rules and actions on transaction return activity.",
    "5-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)  \n[returnBill](https://capillary-documentation.readme.io/docs/profiles-attributes#return-bill-returnbill)  \n[tenderProfile](https://capillary-documentation.readme.io/docs/profiles-attributes#tender-profile-tenderprofile)",
    "6-0": "CustomerUpdate",
    "6-1": "Configure rules and actions on the customer profile update activity.",
    "6-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)",
    "7-0": "TransactionUpdate",
    "7-1": "Configure rules and actions on the transaction update activity.",
    "7-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[currentTxn](https://capillary-documentation.readme.io/docs/profiles-attributes#current-transaction-currenttxn)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)",
    "8-0": "SocialConnect",
    "8-1": "Execute actions for social events (events through Social Connect)",
    "8-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)",
    "9-0": "SlabUpgrade",
    "9-1": "Configure rules for the tier upgrade activity.",
    "9-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[currentTxn](https://capillary-documentation.readme.io/docs/profiles-attributes#current-transaction-currenttxn)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)  \n[referrerCode](https://capillary-documentation.readme.io/docs/profiles-attributes#referrer-code-referrercode)  \n[tenderProfile](https://capillary-documentation.readme.io/docs/profiles-attributes#tender-profile-tenderprofile)",
    "10-0": "TargetCompleted",
    "10-1": "Configure rules for target-based loyalty.",
    "10-2": "[currentCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-currentcustomer)  \n[currentCustomerPartner](https://capillary-documentation.readme.io/docs/profiles-attributes#current-customer-partner-currentcustomerpartner)  \n[currentEvent](https://capillary-documentation.readme.io/docs/profiles-attributes#current-event-currentevent)  \n[currentStore](https://capillary-documentation.readme.io/docs/profiles-attributes#current-store-currentstore)  \n[groupPrimaryCustomer](https://capillary-documentation.readme.io/docs/profiles-attributes#group-primary-customer-groupprimarycustomer)  \n[organization](https://capillary-documentation.readme.io/docs/profiles-attributes#organization-organization)  \n[program](https://capillary-documentation.readme.io/docs/profiles-attributes#program-program)"
  },
  "cols": 3,
  "rows": 11,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


## Actions

You can set relevant actions when customers meet a specific condition. Loyalty+ allows you to define rules and execute actions when a condition is satisfied. The following are the different actions supported in Loyalty+.

[block:parameters]
{
  "data": {
    "h-0": "Action",
    "h-1": "Description",
    "0-0": "Award points to referee",
    "0-1": "This action allows you to award points to the referee. A referee is a customer who has been referred by a referrer. To refer to the steps involved in awarding points to the referee, see [here](https://capillary-documentation.readme.io/docs/award-points-to-referee).",
    "1-0": "Award points to referrer",
    "1-1": "This action allows you to award points to the referrer. A referrer is a customer who recommends more customers to interact with the brand. For instructions to award points to the referrer, see [here](https://capillary-documentation.readme.io/docs/award-points-to-referrer).",
    "2-0": "Forward to set",
    "2-1": "This action allows you to evaluate conditions on individual line items or individual payment methods of a transaction. To refer to the steps involved in forwarding to set, see [here](https://capillary-documentation.readme.io/docs/forward-to-set).",
    "3-0": "Issue coupon",
    "3-1": "This action allows you to define criteria for accepting points back. To refer to the steps involved in issuing a coupon, see [here](https://capillary-documentation.readme.io/docs/issue-coupon).",
    "4-0": "Renew tier",
    "4-1": "This action allows you to renew the tier of a customer. To refer to the steps involved in sending messages, see [here](https://capillary-documentation.readme.io/docs/renew-tier).",
    "5-0": "Send mail",
    "5-1": "This action allows you to send an email to a customer when a specific condition is satisfied. To refer to the steps involved in sending an email, see [here](https://capillary-documentation.readme.io/docs/send-mail).",
    "6-0": "Send messages",
    "6-1": "This action allows you to send messages over a chosen communication channel(s). To refer to the steps involved in sending messages, see [here](https://capillary-documentation.readme.io/docs/send-messages).",
    "7-0": "Send mobile push",
    "7-1": "This action allows you to send push notifications. To refer to the steps involved in sending messages, see [here](https://capillary-documentation.readme.io/docs/send-mobile-push).",
    "8-0": "Send SMS",
    "8-1": "This action allows you to send an SMS to a customer. To refer to the steps involved in sending an SMS, see [here](https://capillary-documentation.readme.io/docs/send-sms).",
    "9-0": "Send WeChat",
    "9-1": "This action allows you to send messages to customers over WeChat. To refer to the steps involved in sending messages over WeChat, see here.",
    "10-0": "Tag customer",
    "10-1": "This action allows you to add tag(s) to the customer(s).  \n  \nNote: This option is disabled till further notice.",
    "11-0": "Transaction point allocation",
    "11-1": "This action allows you to allocate points for transactions. To refer to the steps involved in sending messages, see here.",
    "12-0": "Upgrade to tier",
    "12-1": "This action allows you to upgrade a customer to a specific tier.  To refer to the steps involved in sending messages, see here.",
    "13-0": "Upgrade using tier",
    "13-1": "This action allows you to upgrade a customer based on a specific tier action. To refer to the steps involved in sending messages, see here."
  },
  "cols": 2,
  "rows": 14,
  "align": [
    "left",
    "left"
  ]
}
[/block]


## Configure Notifications

Notify customers when an action is executed successfully. The system can send notifications through different channels such as SMS, email, WeChat, and Mobile Push. 

Notification channels are of two types:

- **Mandatory Channels**: Channels that are mandatory for sending the notifications
- **Priority Channels**: Channels that need to be triggered based on priority and availability. For example, if Mobile is set as priority 1, Mobile Push as priority 2, and email as priority 3, the system first checks whether SMS is configured and checks if the mobile number is available for the customer. If anyone fails, then it will try to send the notification through mobile push and so on. 

> 📘 - Channels that are selected in **Mandatory Channels** will not appear in **Priority Channels** and vice versa.

#### To configure notifications, follow these steps.

1. Click any selected **Action** to set up channel notifications.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ea0e9b8-Bm0fzS4FokepPFhCq3GuuHswRl8x2EJ1rw.png",
        "Bm0fzS4FokepPFhCq3GuuHswRl8x2EJ1rw.png",
        954
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


2. Select **Mandatory Channels** and **Priority Channels** for the notifications and click **Save**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5f7cd90-ispKIT6uIdTHMgjRc-lseuJe0qyZO5Po1A.png",
        "ispKIT6uIdTHMgjRc-lseuJe0qyZO5Po1A.png",
        833
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c1c08c2-XY3-D3a4e3up-suJMD3yO5rQ9aLBRKuZqg.png",
        "XY3-D3a4e3up-suJMD3yO5rQ9aLBRKuZqg.png",
        858
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


3. Configure message templates and set the delay time. The following example shows the configuration screen for WeChat.
4. Choose the account id and template. Preview the message and click **Save**. For more details on configuring notifications, see Configuring Notification Messages.
5. Click **Save** to save the action configurations.
6. Again click on **Save** to save the ruleset.
7. Reconfigure the loyalty program to reflect the changes in the live program.

> 📘 - To know more about events, and writing rule expressions, see Creating Rules for the Loyalty Program.
> - A rule could have multiple rule sets. To check multiple cases to execute an action, create forward cases for each condition and set the execute action in the final sub ruleset.
