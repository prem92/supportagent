---
title: "Badges"
slug: "customer_badges"
excerpt: ""
hidden: false
createdAt: "Wed Nov 08 2023 17:39:22 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Apr 05 2024 06:19:31 GMT+0000 (Coordinated Universal Time)"
---
[Introduction to Badges](https://docs.capillarytech.com/docs/introduction-to-badges)

[Type of Badges](https://docs.capillarytech.com/docs/type-of-badges)

[Getting started](https://docs.capillarytech.com/docs/getting-started-badges)

[Configuration for Badges](https://docs.capillarytech.com/docs/configuration-for-badges)

[Managing Badges](https://docs.capillarytech.com/docs/managing-badges)

<br>
