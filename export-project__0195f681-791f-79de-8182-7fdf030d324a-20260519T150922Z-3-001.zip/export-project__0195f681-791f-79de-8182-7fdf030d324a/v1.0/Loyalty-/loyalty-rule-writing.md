---
title: "Loyalty Rule Writing"
slug: "loyalty-rule-writing"
excerpt: ""
hidden: true
createdAt: "Fri Jul 28 2023 06:16:18 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
These set of articles, will help you understand all the profiles, attributes and sub-attributes, on which you can write various rules in Loyalty Workflows.
