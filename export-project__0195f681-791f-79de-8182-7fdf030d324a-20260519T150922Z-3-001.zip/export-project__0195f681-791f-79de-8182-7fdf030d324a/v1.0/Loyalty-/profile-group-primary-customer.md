---
title: "Profile : Group Primary Customer (groupPrimaryCustomer)"
slug: "profile-group-primary-customer"
excerpt: ""
hidden: true
createdAt: "Sun Nov 05 2023 13:32:32 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
User Group Loyalty - User group loyalty allows an org to incentivize not only its customers but also incentivize other business entities or individuals that contribute to their profits. It is a customer retention solution with custom group structures and includes generic loyalty mechanics which helps an org to establish brand loyalty.  
In user group loyalty, an individual’s (member of a group) action will lead to other group members being rewarded.

## Attributes - Customer Identity

_The below grouping of attributes is based on Primary customer identity information. _

| Attributes        | Definition                                                                | Link             |
| :---------------- | :------------------------------------------------------------------------ | :--------------- |
| name              | Primary customer’s Full Name.                                             | [Learn More](<>) |
| firstname         | Lets you evaluate conditions on the first name of the primary customer.   |                  |
| lastname          | Primary customer’s Last Name.                                             |                  |
| email             | Primary customer's Email ID.                                              |                  |
| externalId        | Primary customer's External ID.                                           |                  |
| mobile            | Primary customer's Mobile number.                                         |                  |
| hasInstoreProfile | Checks if the primary customer is registered and has an in-store Profile. |                  |
| hasWeChatProfile  | Returns True, if the Primary customer has a WeChat Profile.               |                  |

## Attributes - Custom Field

_The below grouping of attributes is based on custom fields created at the Group Primary customer level._

| Attributes               | Definition                                                                      | Link |
| :----------------------- | :------------------------------------------------------------------------------ | :--- |
| customFieldValueIncludes | Check if the group primary customer has some custom field present with a value. |      |
| customFieldValueExcludes | Check If the group's primary customer has some custom field present.            |      |
| customFieldValueExists   | checks If the group's primary customer data has some custom field present.      |      |

## Attributes - KPI based on Points

_The below grouping of attributes is based on the points allocated or earned by the Group's primary customer's points. _

| Attributes                   | Definition                                                                                                      | Link |
| :--------------------------- | :-------------------------------------------------------------------------------------------------------------- | :--- |
| currentPoints                | Lets you evaluate conditions on the active points of the primary customer.                                      |      |
| initialCurrentPoints         | For Primary customer of a group, current redeemable points before the current event or Active                   |      |
| currentAllPoints             | The sum of all Points, redeemable as well as Promised Points of gtoup's primary customer.                       |      |
| lifetimePoints               | Total points earned by a Primary customer of a group from the date of registration.                             |      |
| lifetimeNonRedeemablePoints. | lifetime non-redeemable points = overall non-redeemable points earned - overall non-redeemable returned points. |      |
| initialLifetimePoints        | Primary customer of a group's lifetime redeemable points before the current event.                              |      |

## Attributes - KPI based on transaction data

_The below grouping is done based on the Key Performance Indicators on the primary customer's transaction data._

[block:parameters]
{
  "data": {
    "h-0": "Attributes",
    "h-1": "Definition",
    "h-2": "Link",
    "0-0": "avgBasketSize",
    "0-1": "Lets you evaluate conditions on the average basket size of the primary customer.  \n  \n(The ratio of the total quantities of line items purchased to the total number of transactions made).",
    "0-2": "",
    "1-0": "avgSpendPerVisit",
    "1-1": "Lets you evaluate conditions on the average spend per visit by the primary customer.  \n  \n(Total purchases amount)/ (Total number of transactions made).",
    "1-2": "",
    "2-0": "numberOfTxns",
    "2-1": "Lets you evaluate conditions on the total number of transactions by a primary customer.",
    "2-2": "",
    "3-0": "numberOfTxnsToday",
    "3-1": "Lets you evaluate conditions on the number of transactions made by the primary customer on the current day.",
    "3-2": "",
    "4-0": "numberOfVisits",
    "4-1": "Lets you evaluate conditions on the number of visits primary customers.",
    "4-2": "",
    "5-0": "lifetimePurchase",
    "5-1": "Lets you evaluate conditions on lifetime points of the primary customer.",
    "5-2": "",
    "6-0": "InitialLifetimePurchase",
    "6-1": "Lets you evaluate conditions on lifetime purchases of the primary customer.",
    "6-2": ""
  },
  "cols": 3,
  "rows": 7,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


## Attributes - Date

| Attribute | Definition                                                                           | Link |
| :-------- | :----------------------------------------------------------------------------------- | :--- |
| joinDate  | Lets you evaluate conditions based on the registration date of the primary customer. |      |

## Attributes - Slab Information

_This grouping of attributes is done on the basis of Tier/Slab Information associated with the group's primary customer's loyalty. _

| Attributes        | Definition                                                                                                | Link |
| :---------------- | :-------------------------------------------------------------------------------------------------------- | :--- |
| initialSlabName   | Initial slab name of the Primary Customer of group before evaluating an event, let's say gold,silver etc. |      |
| initialSlabNumber | Initial slab number of the Primary Customer of group before evaluating an event, let's say 10, 1, 3 etc   |      |
| slabName          | Lets you evaluate conditions on the tier name of a primary customer.                                      |      |
| slabNumber        | Lets you evaluate conditions on the tier number of the primary customer.                                  |      |
