---
title: "Loyalty+ Reporting"
slug: "point-conditions"
excerpt: ""
hidden: false
createdAt: "Mon Dec 06 2021 19:58:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
Along with Loyalty+, Capillary provides you with an excellent reporting tool called Insights+, which you can use to monitor different facets of your loyalty programs. You can read more about the Insights+ platform here. Read on to get information on the various Loyalty+ Reports.
