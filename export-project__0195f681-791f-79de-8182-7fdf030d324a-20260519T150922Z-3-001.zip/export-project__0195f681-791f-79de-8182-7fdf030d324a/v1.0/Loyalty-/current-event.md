---
title: "Profile : Current Event"
slug: "current-event"
excerpt: ""
hidden: false
createdAt: "Mon Aug 14 2023 14:22:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Aug 05 2024 11:15:22 GMT+0000 (Coordinated Universal Time)"
---
CurrentEvent: The current event profile returns the event that is triggered by the event listener, i.e., the event on which the rule is created. 

The following table consists of the descriptions of all the attributes of currentEvent.

## Attributes - Target based

[block:parameters]
{
  "data": {
    "h-0": "Attribute",
    "h-1": "Definition",
    "h-2": "Link",
    "0-0": "targetAchieved",
    "0-1": "Provides the numeric value of the actual achievement of the customer for the given target.",
    "0-2": "[Learn More](https://docs.capillarytech.com/docs/attribute-target-based)",
    "1-0": "targetDefined",
    "1-1": "Provides the numerical target value that is defined by the brand",
    "1-2": "",
    "2-0": "targetExists",
    "2-1": "Verifies whether the current event contains information about the target.  \n**Example:** currentEvent.targetExists(\"ABC\")",
    "2-2": "",
    "3-0": "targetName",
    "3-1": "Verifies whether the current event is talking about the target whose name contains the given string.  \n**Example:** currentEvent.targetName.contains(\"AB\")",
    "3-2": "",
    "4-0": "isTargetAchievedEvent",
    "4-1": "Verifies whether the current event is for the achievement of a target.  \n**Example:** currentEvent.isTargetAchievedEvent",
    "4-2": "",
    "5-0": "isUnifiedTargetAchievedEvent",
    "5-1": "Verifies whether the current event is for the achievement of a unified target.  \n**Example:** currentEvent.isUnifiedTargetAchievedEvent.",
    "5-2": "",
    "6-0": "isStreakAchievedEvent",
    "6-1": "Verifies whether the current event is for the achievement of a streak level.  \n**Example:** currentEvent.isStreakAchievedEvent",
    "6-2": "",
    "7-0": "isSubTargetAchievedEvent",
    "7-1": "Verifies whether the current event is for the achievement of a sub-target  \n**Example:** currentEvent.isSubTargetAchievedEvent",
    "7-2": "",
    "8-0": "targetMilestoneTrigger",
    "8-1": "Verifies whether the current event is about the specific sub-target.  \n**Example:** currentEvent.targetMilestoneTrigger.contains(\"name of sub-target\")",
    "8-2": "",
    "9-0": "streakName",
    "9-1": "Verifies whether the current event is about the specific streak-level.  \n**Example:** currentEvent.streakName(\"name of streak level\")",
    "9-2": "",
    "10-0": "streakExists",
    "10-1": "Verifies whether the current event contains information about the streak-level mentioned.  \n**Example:** currentEvent.streakExists(\"name of streak level\")",
    "10-2": ""
  },
  "cols": 3,
  "rows": 11,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


## Attributes - Loyalty Information

| Attribute           | Definition                                                                                                  | Link                                                                                                |
| :------------------ | :---------------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------- |
| previousLoyaltytype | Checks the loyalty status of the customer before the current event. Supported only for CustomerUpdate event | [Learn More](https://docs.capillarytech.com/docs/attribute-loyalty-information#previousloyaltytype) |
| currentLoyaltytype  | Checks the loyalty status of the customer during the current event. Supported only for CustomerUpdate event | [Learn More](https://docs.capillarytech.com/docs/attribute-loyalty-information#currentloyaltytype)  |

## Attribute - Custom Field

| Attribute                | Definition                               | Link                                                                                                 |
| :----------------------- | :--------------------------------------- | :--------------------------------------------------------------------------------------------------- |
| currentCustomFieldValue  | Value of custom field after updating     | [Learn More](https://docs.capillarytech.com/docs/attributes-custom-field-1#currentcustomfieldvalue)  |
| previousCustomFieldValue | Customer's mobile number before updating | [Learn More](https://docs.capillarytech.com/docs/attributes-custom-field-1#previouscustomfieldvalue) |
