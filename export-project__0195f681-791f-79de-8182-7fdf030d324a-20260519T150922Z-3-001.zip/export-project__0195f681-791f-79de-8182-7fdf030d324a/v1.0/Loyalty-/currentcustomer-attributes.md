---
title: "Attributes - Group Primary Customer's Data"
slug: "currentcustomer-attributes"
excerpt: ""
hidden: true
createdAt: "Mon Aug 14 2023 14:25:14 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
## Email

Profile : groupPrimaryCustomer  
Attribute : Email  
Type : String  
Sub-Attributes : NA  
Operator: contains, exists, isEmpty, isNotNull, isNull, matches, notExists, “==”  
Meaning : Primary Customer's email id or checks which organization is in the email of Primary Customer  
Syntax : groupPrimaryCustomer.email[Operators][Value]

[block:parameters]
{
  "data": {
    "h-0": "Attribute",
    "h-1": "SubAttribute",
    "h-2": "Operator",
    "h-3": "Example",
    "0-0": "email",
    "0-1": "NA",
    "0-2": "contains",
    "0-3": "Contains - use to see if the string contains the defined value.  \nExample: groupPrimaryCustomer.email.contains(\"ashish.chelikani\")",
    "1-0": "email",
    "1-1": "NA",
    "1-2": "exists",
    "1-3": "Exists - Some proper value exists for this string (i.e. source passed a value that was not an empty string)  \ngroupPrimaryCustomer.email.exists()",
    "2-0": "email",
    "2-1": "NA",
    "2-2": "isEmpty",
    "2-3": "isEmpty - Similar to notExists  \ngroupPrimaryCustomer.emai.isEmpty(“”)",
    "3-0": "email",
    "3-1": "NA",
    "3-2": "isNotNull",
    "3-3": "isNotNull - checks if the the string is NOT Null i.e. some value was passed from source (even an empty string counts)  \ngroupPrimaryCustomer.email.isNotNull(“”)",
    "4-0": "email",
    "4-1": "NA",
    "4-2": "isNull",
    "4-3": "isNull - checks if the string is Null i.e. it was not passed from source  \ngroupPrimaryCustomer.email.isNull(“”)",
    "5-0": "email",
    "5-1": "NA",
    "5-2": "notExists",
    "5-3": "notExists - The string is either Null or Empty",
    "6-0": "email",
    "6-1": "NA",
    "6-2": "==",
    "6-3": "( == ) returns true if both operands have the same value; otherwise, it returns false . The not-equal-to operator ( != ) returns true if the operands don't have the same value; otherwise, it returns false .  \ngroupPrimaryCustomer.email==\"[shoa17783@gmail.com](mailto:shoa17783@gmail.com)\"",
    "7-0": "email",
    "7-1": "NA",
    "7-2": "matches",
    "7-3": "Matches - this is used to perform regular expression-based matching on the string.  \ngroupPrimaryCustomer.email.matches(\"[santosh@tech.com](mailto:santosh@tech.com)\")"
  },
  "cols": 4,
  "rows": 8,
  "align": [
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


Example 1: Write a condition to check if the Primary customer email contains string “SHR”  
Profile: groupPrimaryCustomer  
Attribute: Email  
Sub-Attribute: NA  
Operator : contains  
Rule: groupPrimaryCustomer.email.contains(“SHR”)

Example 2: Write a rule to check if the Primary customer’s number of visits and Primary group customer email is not null.  
Profile: groupPrimaryCustomer  
Attribute: numberOfVisits and email  
Operator : == & isNotNull  
Rule: groupPrimaryCustomer.numberOfVisits==1&&groupPrimaryCustomer.email.is.NotNull(“”)

## hasInstoreProfile

Profile : groupPrimaryCustomer  
Attribute : hasInstoreProfile  
Type : Boolean  
Meaning : returns True, if the Primary customer is registered and has a instore Profile  
Sub-Attribute: NA  
Syntax: groupPrimaryCustomer.hasInstoreProfile()  
Example: groupPrimaryCustomer.hasInstoreProfile==true

Example1 : write a rule to check if the current has a Instore Profile

Profile: groupPrimaryCustomer  
Attribute: hasInstoreProfile  
Type: Boolean  
Rule: groupPrimaryCustomer.hasinstoreProfile==true

## hasWeChatProfile

Profile : groupPrimaryCustomer  
Attribute : hasWeChatProfile  
Type : Boolean  
Meaning : returns True, if the group Primary customer has a WeChat Profile  
Sub-Attribute: NA  
Syntax: groupPrimaryCustomer.hasWeChatProfile==true

Example1 : write a rule to check if the group Primary customer has a Instore Profile  
Profile: groupPrimaryCustomer  
Attribute: hasWeChatProfile  
Type: Boolean  
Rule: groupPrimaryCustomer.hasWeChatProfile()
