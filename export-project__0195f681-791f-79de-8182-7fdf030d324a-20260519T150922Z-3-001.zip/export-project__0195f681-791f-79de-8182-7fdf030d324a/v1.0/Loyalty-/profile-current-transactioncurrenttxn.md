---
title: "Profile : Current Transaction"
slug: "profile-current-transactioncurrenttxn"
excerpt: "Attributes based on Transaction"
hidden: false
createdAt: "Mon Aug 14 2023 14:23:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
**Profile : Current Transaction(currentTxn)**  
The currentTxn profile returns the details of a transaction. We generally use this profile to write rules on transactions, basket size, custom fields, and so on. Refer to the table below for all the supported attributes of customerTxn.

## Attributes - KPI (Transaction/Basket)

_The below grouping of attributes is based on the key Performance Indicator of transactions/basket._

[block:parameters]
{
  "data": {
    "h-0": "Attributes",
    "h-1": "Description",
    "h-2": "Link",
    "0-0": "basketSum()",
    "0-1": "The sum of value of the items matching the inventory attribute.",
    "0-2": "[Learn More](<>)",
    "1-0": "basketSumRegex()",
    "1-1": "The sum of the value of the items matching the inventory attribute RegEx.",
    "1-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketsumregex)",
    "2-0": "basketQty()",
    "2-1": "The total quantity of items in the bill matches the inventory. ",
    "2-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketqty)",
    "3-0": "basketQtyRegex()",
    "3-1": "The quantity of items in the bill matches the regular expression.",
    "3-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketqtyregex)",
    "4-0": "basketcount()",
    "4-1": "Number of products in the transaction of the given inventory type, irrespective of quantity.",
    "4-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketcount)",
    "5-0": "basketcountRegex()",
    "5-1": "Number of products whose item attribute matches the given regular expression.",
    "5-2": "",
    "6-0": "basketIncludes()",
    "6-1": "Products contained in the transaction.",
    "6-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketincludes)",
    "7-0": "basketExcludes()",
    "7-1": "Products not contained in the transaction.",
    "7-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketexcludes)",
    "8-0": "basketSumIf",
    "8-1": "Returns the sum of the amount of line items that satisfies a specific condition. ",
    "8-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketsumif)",
    "9-0": "basketCountIf",
    "9-1": "Returns the count of line items of the basket that satisfies a specific condition. ",
    "9-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketcountif)",
    "10-0": "basketQtyIf",
    "10-1": "Return the sum of quantities of qualifying line items in the basket. ",
    "10-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketqtyif)",
    "11-0": "basketSize",
    "11-1": "Total number of items in the bill - irrespective of quantity of each item.",
    "11-2": "[Learn More](https://docs.capillarytech.com/docs/a#basket-size)",
    "12-0": "basketSumGross",
    "12-1": "The sum of the gross amount of each line item in a basket with a specific attribute.",
    "12-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketsumgross)",
    "13-0": "basketSumRegexGross",
    "13-1": "The sum of the gross amount of each line item in the basket  \nwhose product attribute values match the given regular expression.",
    "13-2": "[Learn More](https://docs.capillarytech.com/docs/a#basketsumregexgross)"
  },
  "cols": 3,
  "rows": 14,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


## Attribute - Transaction Number

| Attributes | Definition                | Link                                                                                                      |
| :--------- | :------------------------ | :-------------------------------------------------------------------------------------------------------- |
| number     | Transaction number or ID. | [Learn More](https://docs.capillarytech.com/docs/attributes-based-on-customer-identity#attribute--number) |

## Attribute - Date

| Attribute | Definition              | Link                                                                                      |
| :-------- | :---------------------- | :---------------------------------------------------------------------------------------- |
| date      | date of the Transaction | [Learn More](https://docs.capillarytech.com/docs/attribute-date-transactionpurchase-date) |

## Attributes - Custom Field (Transaction)

_The below grouping of attributes is based on custom fields created at the transaction level._

| Attributes               | Definition                                                                   | Link                                                                                                |
| :----------------------- | :--------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------- |
| customFieldValueIncludes | Returns True if input custom field value matches with bill's custom fields.  | [Learn More](https://docs.capillarytech.com/docs/attributes-custom-fields#customfieldvalueincludes) |
| customFieldValueExcludes | Returns False if input custom field value matches with bill's custom fields. | [Learn More](https://docs.capillarytech.com/docs/attributes-custom-fields#customfieldvalueexcludes) |

## Attributes - Transaction Value

| Attributes | Definition                     | Link                                                                          |
| :--------- | :----------------------------- | :---------------------------------------------------------------------------- |
| value      | Total value of the transaction | [Learn More](https://docs.capillarytech.com/docs/attribute-transaction-value) |

## Attributes - Discount

| Attributes | Definition                          | Link                                                                 |
| :--------- | :---------------------------------- | :------------------------------------------------------------------- |
| discount   | Discounted value on the transaction | [Learn More](https://docs.capillarytech.com/docs/attribute-discount) |

## Attributes - Note

| Attributes | Definition                                                              | Link                                                                             |
| :--------- | :---------------------------------------------------------------------- | :------------------------------------------------------------------------------- |
| note       | Transaction level notes specified by the cashier during the transaction | [Learn More](https://docs.capillarytech.com/docs/attribute-using-standard-field) |
