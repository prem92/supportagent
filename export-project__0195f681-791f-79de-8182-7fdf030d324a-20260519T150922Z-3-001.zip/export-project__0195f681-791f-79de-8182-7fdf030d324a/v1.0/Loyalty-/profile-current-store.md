---
title: "Profile : Current Store"
slug: "profile-current-store"
excerpt: ""
hidden: false
createdAt: "Sun Aug 20 2023 14:55:00 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
The currentStore profile is used to check store level details. You can write rules based on the attributes provided in the table below. 

| ATTRIBUTE | DESCRIPTION              | SUB ATTRIBUTES | Link                                                             |
| :-------- | :----------------------- | :------------- | :--------------------------------------------------------------- |
| code      | Unique code of the store | NA             | [Learn More](https://docs.capillarytech.com/docs/attribute-code) |
| name      | Name of the store        | NA             |                                                                  |
