---
title: "Attributes - Name/First Name/Last Name"
slug: "currentcustomer-namefirst-namelast-name-expressions"
excerpt: "Profile - Group Primary Customer"
hidden: true
createdAt: "Mon Aug 14 2023 13:20:13 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
# CurrentCustomer Name/First Name/Last Name Expressions

## **1.currentCustomer (Customer Profile)** :

 Allows you to write conditions based on the properties of the customer who is currently performing the activity

## **2.Attributes on Customer Identity **:

Attributes that are based on customer Identity like Name, first Name and Last Name.

[block:parameters]
{
  "data": {
    "h-0": "Attributes",
    "h-1": "Meaning",
    "h-2": "Data Type",
    "h-3": "Stored in backend",
    "h-4": "Sub- Attributes",
    "0-0": "Name",
    "0-1": "Customer’s Full Name",
    "0-2": "String",
    "0-3": "name = firstName + \" \" + lastName;",
    "0-4": "NA",
    "1-0": "First Name",
    "1-1": "Customer’s First Name  \nstring  ",
    "1-2": "String",
    "1-3": "name = firstName;",
    "1-4": "NA",
    "2-0": "Last Name",
    "2-1": "Customer’s Last Name",
    "2-2": "String",
    "2-3": "name = \" \" + lastName;",
    "2-4": "NA"
  },
  "cols": 5,
  "rows": 3,
  "align": [
    "left",
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


## **3.String Operators**

The basic range of string operations serve to resolve the string attribute into a boolean outcome. These operators are inserted after the string attribute using the . notation e.g. currentCustomer.email.contains(".com")

The following are the string operators:  
**Contains** - used to see if the string contains the defined value  
**Matches** - this is used to perform regular expression based matching on the string  
**isValidDate** - used to check if the string is a proper date field  
**Exists **- Some proper value exists for this string (i.e. source passed a value that was not an empty string)  
**notExists **- The string is either Null or Empty  
**isEmpty** - Similar to notExists  
**isNull** - checks if the string is Null i.e. it was not passed from source  
**isNotNull **- checks if the the string is NOT Null i.e. some value was passed from source (even an empty string counts).

***

## **Attribute “Name”:**

Profile: groupPrimaryCustomer  
Attribute: name  
Meaning: Customer's Full Name [ name = firstName + " " + lastName ]  
Type: String  
Sub-Attribute : NA  
Operators : contains, exists, isEmpty, isNotNull, isNull, isValidDate, matches and notExists  
Format: groupPrimaryCustomer.[(Attribute).(Sub Attribute)].[ Operators ][VALUE]  
Syntax : groupPrimaryCustomer.name[Operator][Value]  
Example : Lets say the primary customer name is “Mudita Sharma”

[block:parameters]
{
  "data": {
    "h-0": "Example 1",
    "0-0": "Write an Expression to check if the Primary customer name has substring “naresh”.  \nExpression: groupPrimaryCustomer.name.matches(“naresh”)  \nHere, Profile -> groupPrimaryCustomer  \nAttribute -> name  \nSub Attributes -> NA  \nString Operators -> matches  \nValue -> naresh"
  },
  "cols": 1,
  "rows": 1,
  "align": [
    "left"
  ]
}
[/block]


[block:parameters]
{
  "data": {
    "h-0": "Example 2",
    "0-0": "Write an Expression to check if the customer name is “Santosh kumar”  \nExpression: groupPrimaryCustomer.contains(\"Santosh kumar\")"
  },
  "cols": 1,
  "rows": 1,
  "align": [
    "left"
  ]
}
[/block]


***

## **Attributes “First Name” & “Last Name”:**

Profile: groupPrimaryCustomer  
Attribute: firstName  
Meaning: Primary customer's First Name [ name = firstName ]  
Attribute : lastName  
Meaning: Primary customer's Last Name [name = " "+lastName]  
Type: String  
Sub-Attribute : NA  
Format: groupPrimaryCustomer.[(Attribute).(Sub Attribute)].[ Operators ][VALUE]  
Syntax for First Name Attribute: groupPrimaryCustomer.firstname[Operator][Value]  
Syntax for last Name Attribute : groupPrimaryCustomer.lastname[Operator][Value]

[block:parameters]
{
  "data": {
    "h-0": "Example 1",
    "0-0": "Example 2: Write a rule to check if the current transaction is done by a primary customer of a group whose first name is Rohan.  \n  \nHere, Profile -> groupPrimaryCustomer  \nAttribute -> firstname  \nSub Attributes -> NA  \nString Operators -> matches  \nValue -> Rohan  \nExpression -> groupPrimaryCustomer.firstname.matches(“Rohan”)"
  },
  "cols": 1,
  "rows": 1,
  "align": [
    "left"
  ]
}
[/block]


[block:parameters]
{
  "data": {
    "h-0": "Example 2:",
    "0-0": "Example 3: Write a rule to check if the current transaction is done by a primary customer of a group whose first name is Yash and the transaction value exceed 1000.  \n  \nOverall Expression : Condition 1 && Condition 2  \nFor Condition 1:  \nProfile : groupPrimaryCutomer  \nAttribute: firstname  \nOperator : ==  \nValue: Yash  \nExpression 1: groupPrimaryCustomer.firstname==”Yash”  \n  \nFor Condition 2:  \nProfile : customerTxn  \nAttribute: value  \nOperator : “>”  \nValue: 1000  \nExpression 1: currentTxn.value>1000"
  },
  "cols": 1,
  "rows": 1,
  "align": [
    "left"
  ]
}
[/block]


## Email

Profile : groupPrimaryCustomer  
Attribute : Email  
Type : String  
Sub-Attributes : NA  
Operator: contains, exists, isEmpty, isNotNull, isNull, matches, notExists, “==”  
Meaning : Primary Customer's email id or checks which organization is in the email of Primary Customer  
Syntax : groupPrimaryCustomer.email[Operators][Value]

[block:parameters]
{
  "data": {
    "h-0": "Attribute",
    "h-1": "SubAttribute",
    "h-2": "Operator",
    "h-3": "Example",
    "0-0": "email",
    "0-1": "NA",
    "0-2": "contains",
    "0-3": "Contains - use to see if the string contains the defined value.  \nExample: groupPrimaryCustomer.email.contains(\"ashish.chelikani\")",
    "1-0": "email",
    "1-1": "NA",
    "1-2": "exists",
    "1-3": "Exists - Some proper value exists for this string (i.e. source passed a value that was not an empty string)  \ngroupPrimaryCustomer.email.exists()",
    "2-0": "email",
    "2-1": "NA",
    "2-2": "isEmpty",
    "2-3": "isEmpty - Similar to notExists  \ngroupPrimaryCustomer.emai.isEmpty(“”)",
    "3-0": "email",
    "3-1": "NA",
    "3-2": "isNotNull",
    "3-3": "isNotNull - checks if the the string is NOT Null i.e. some value was passed from source (even an empty string counts)  \ngroupPrimaryCustomer.email.isNotNull(“”)",
    "4-0": "email",
    "4-1": "NA",
    "4-2": "isNull",
    "4-3": "isNull - checks if the string is Null i.e. it was not passed from source  \ngroupPrimaryCustomer.email.isNull(“”)",
    "5-0": "email",
    "5-1": "NA",
    "5-2": "notExists",
    "5-3": "notExists - The string is either Null or Empty",
    "6-0": "email",
    "6-1": "NA",
    "6-2": "==",
    "6-3": "( == ) returns true if both operands have the same value; otherwise, it returns false . The not-equal-to operator ( != ) returns true if the operands don't have the same value; otherwise, it returns false .  \ngroupPrimaryCustomer.email==\"[shoa17783@gmail.com](mailto:shoa17783@gmail.com)\"",
    "7-0": "email",
    "7-1": "NA",
    "7-2": "matches",
    "7-3": "Matches - this is used to perform regular expression-based matching on the string.  \ngroupPrimaryCustomer.email.matches(\"[santosh@tech.com](mailto:santosh@tech.com)\")"
  },
  "cols": 4,
  "rows": 8,
  "align": [
    "left",
    "left",
    "left",
    "left"
  ]
}
[/block]


Example 1: Write a condition to check if the Primary customer email contains string “SHR”  
Profile: groupPrimaryCustomer  
Attribute: Email  
Sub-Attribute: NA  
Operator : contains  
Rule: groupPrimaryCustomer.email.contains(“SHR”)

Example 2: Write a rule to check if the Primary customer’s number of visits and Primary group customer email is not null.  
Profile: groupPrimaryCustomer  
Attribute: numberOfVisits and email  
Operator : == & isNotNull  
Rule: groupPrimaryCustomer.numberOfVisits==1&&groupPrimaryCustomer.email.is.NotNull(“”)

## hasInstoreProfile

Profile : groupPrimaryCustomer  
Attribute : hasInstoreProfile  
Type : Boolean  
Meaning : returns True, if the Primary customer is registered and has a instore Profile  
Sub-Attribute: NA  
Syntax: groupPrimaryCustomer.hasInstoreProfile()  
Example: groupPrimaryCustomer.hasInstoreProfile==true

Example1 : write a rule to check if the current has a Instore Profile

Profile: groupPrimaryCustomer  
Attribute: hasInstoreProfile  
Type: Boolean  
Rule: groupPrimaryCustomer.hasinstoreProfile==true

## hasWeChatProfile

Profile : groupPrimaryCustomer  
Attribute : hasWeChatProfile  
Type : Boolean  
Meaning : returns True, if the group Primary customer has a WeChat Profile  
Sub-Attribute: NA  
Syntax: groupPrimaryCustomer.hasWeChatProfile==true

Example1 : write a rule to check if the group Primary customer has a Instore Profile  
Profile: groupPrimaryCustomer  
Attribute: hasWeChatProfile  
Type: Boolean  
Rule: groupPrimaryCustomer.hasWeChatProfile()
