---
title: "Loyalty+ settings"
slug: "loyalty-settings-1"
excerpt: "In this, information of the settings present in the Loyalty+ page of CRM will be available."
hidden: false
createdAt: "Fri May 12 2023 09:06:18 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
To go to Loyalty+ settings, 

1. Open the CRM portal by logging in.
2. Go to Loyalty+ module by clicking on the 3\*3 dots symbol present on the left side of the page.
3. Once the Loyalty+ page is loaded, on the right top corner, you can see the settings symbol.
4. Click on that symbol, you will be on Loyalty+ settings page.

## Creation/deletion/editing of custom fields.

First of all, what are custom fields?

Custom fields are the fields which won't be available by default to all organisations unlike the standard fields which will be available by default. As they name suggested, they are meant for customisation as per the brand's needs. 

To understand with an example, a field which is very much required for a diamond brand (like Joyalukkas) might not be necessary for an electronics brand (like Croma).

So for Joyalukkas, a custom field (let's say, diameter of the diamond) need to be created for their activities & actions.  These fields are relatively very easy to create, and have 3 primary actions:

1. Creation of custom field
2. Editing the custom field
3. Deleting the custom field

Following media helps in understanding how to do that:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/875c8f3-Loyalty_-_8_May_2023.gif",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]
