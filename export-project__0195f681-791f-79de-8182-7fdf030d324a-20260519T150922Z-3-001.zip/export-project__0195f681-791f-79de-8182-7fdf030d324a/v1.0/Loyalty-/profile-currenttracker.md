---
title: "Profile : Current Tracker"
slug: "profile-currenttracker"
excerpt: ""
hidden: false
createdAt: "Mon Aug 14 2023 14:25:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
**Profile : currentTracker**  
currentTrackerCondition (Tracker Profile) - Inside the Tracker set, this profile allows you to write conditions based on the properties of that particular tracker case.

**Attributes based on Current Tracker:**

| Profile        | Attribute              | Link                                                                                                      |
| :------------- | :--------------------- | :-------------------------------------------------------------------------------------------------------- |
| currentTracker | trackedValue           | [Learn More](https://docs.capillarytech.com/docs/attributes-tracker#attribute-trackedvalue-tracked-value) |
| currentTracker | trackerConditionName   | [Learn More](https://docs.capillarytech.com/docs/attributes-tracker#attribute-trackerconditionname)       |
| currentTracker | trackerConditionPeriod | [Learn More](https://docs.capillarytech.com/docs/attributes-tracker#attribute-trackerconditionperiod)     |
| currentTracker | trackerCurrAggr        | [Learn More](https://docs.capillarytech.com/docs/attributes-tracker#attribute-trackercurraggr)            |
| currentTracker | trackerName            | [Learn More](https://docs.capillarytech.com/docs/attributes-tracker#attribute-trackername)                |
| currentTracker | trackerInitialPrevAggr | [Learn More](https://docs.capillarytech.com/docs/attributes-tracker#attribute-trackerinitialprevaggr-1)   |
