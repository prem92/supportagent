---
title: "Loyalty+ Promotions"
slug: "loyalty-promotions-basic-and-advanced"
excerpt: ""
hidden: false
createdAt: "Fri Apr 19 2024 18:41:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 26 2024 07:00:35 GMT+0000 (Coordinated Universal Time)"
---
[Getting started](https://docs.capillarytech.com/docs/loyalty-promotions)

[Types of promotions](https://docs.capillarytech.com/docs/advanced-loyalty-promotions)

[Available to Issue loyalty promotion](https://docs.capillarytech.com/docs/available-to-issue-promotion)

[Direct issue loyalty promotion](https://docs.capillarytech.com/docs/direct-issue-loyalty-promotion)

[Enrol & Issue loyalty promotion](https://docs.capillarytech.com/docs/enrol-issue-loyalty-promotion)
