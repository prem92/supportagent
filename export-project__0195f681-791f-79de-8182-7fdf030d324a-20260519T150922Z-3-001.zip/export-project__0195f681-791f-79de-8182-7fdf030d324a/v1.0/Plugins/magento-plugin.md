---
title: "Magento plugin"
slug: "magento-plugin"
excerpt: "You can integrate Capillary with Magento and activate a loyalty program for your website."
hidden: false
createdAt: "Wed Mar 01 2023 10:50:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 13 2023 01:24:30 GMT+0000 (Coordinated Universal Time)"
---
Navigate to [Capillary Magento integration](https://marketplace.magento.com/capillary-module-crmintegration.html) to integrate Capillary plugin into Magento.

For information on how to integrate Capillary plugin into Magento, see [Capillary Magento integration user guide](https://marketplace.magento.com/media/catalog/product/capillary-module-crmintegration-2-2-0-ce/user_guides.pdf).
