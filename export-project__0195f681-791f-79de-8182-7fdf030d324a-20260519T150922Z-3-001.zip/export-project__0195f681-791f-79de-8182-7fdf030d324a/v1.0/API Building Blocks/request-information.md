---
title: "Request Information"
slug: "request-information"
excerpt: ""
hidden: true
createdAt: "Fri May 27 2022 06:11:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Aug 06 2024 12:41:48 GMT+0000 (Coordinated Universal Time)"
---
A host is the server to which the API calls are made, usually the API cluster URL. 

The host URLs are same for both  v1.1, v2 and v3 APIs. However, the v1 APIs mentioned in the documentation have different URLs for each entity. You can see those URLs under the respective section.  

## Host URLs for v1.1, v2 and v3 APIs

| Cluster   | Host URL                                                                       |
| :-------- | :----------------------------------------------------------------------------- |
| **India** | <https://apac.api.capillarytech.com>                                           |
| **APAC2** | <https://apac2.api.capillarytech.com>                                          |
| **EU**    | <https://eu.api.capillarytech.com>                                             |
| **US**    | <https://us.api.capillarytech.com>                                             |
| **China** | <https://cdn-api.capillarytech.cn.com> [or] <https://api.capillarytech.cn.com> |

## Request Headers

[block:parameters]
{
  "data": {
    "h-0": "Header",
    "h-1": "Description",
    "h-2": "Value",
    "0-0": "Accept",
    "0-1": "Request format from the server side",
    "0-2": "`application/json` for JSON format  \n  \napplication/xml for XML format",
    "1-0": "Content-Type",
    "1-1": "Representation of data at the client side.",
    "1-2": "`application/json` for JSON format  \n  \n`application/xml` for XML format",
    "2-0": "User-Agent",
    "2-1": "A characteristic string that lets servers and network peers identify the application, operating system, vendor, and/or version of the requesting user agent.",
    "2-2": "Format {product} / {product-version} {comment}  \n  \nExample: User-Agent: Mozilla/{version} ({system-information}) {platform} ({platform-details})  \n{extensions}",
    "3-0": "CAP-API-ACCESS-TOKEN",
    "3-1": "Unique access token generated with the Key and Secret combination. Applicable for OAuth based authentication.",
    "3-2": "Generated `token` value.",
    "4-0": "X-CAP-API-ATTRIBUTION-ENTITY-TYPE",
    "4-1": "Till or store from which you want to post the data.",
    "4-2": "`TILL`, `STORE_CODE`, `STORE_NAME`, `STORE_EXTERNAL_ID`, `STORE_EXTERNAL_ID_1`, `STORE_EXTERNAL_ID_2`.  \n  \nThe default value is `TILL`.",
    "5-0": "X-CAP-API-ATTRIBUTION-ENTITY-CODE",
    "5-1": "Value of the specified entity type.",
    "5-2": "Example:  If `X-CAP-API-ATTRIBUTION-ENTITY-TYPE` is `STORE_CODE`, then `X-CAP-API-ATTRIBUTION-ENTITY-CODE` is the store code that you want to tag to POST data.  \n  \nBy default, it considers the Till associated with the client key and secret.",
    "6-0": "X-CAP-API-ATTRIBUTION-LOOKUP-TYPE:{name}  \n  \nX-CAP-API-ATTRIBUTION-LOOKUP:{value}",
    "6-1": "**Supported only for v2 APIs**:  \n  \nLets you submit requests on behalf of other TILLs (active TILLs). In db the combination of attribution_lookup and lookup_code are mapped to TILL ids and org ids. When a new POST request is placed with the combination of a lookup name and lookup code, the data will be inserted in the db on behalf of the TILL that is mapped to the specified combination.",
    "6-2": ""
  },
  "cols": 3,
  "rows": 7,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


## Rate Limit

It is the limit configured in the backend to cap the number of API calls per minute. This reduces the load on servers and stop certain fraud activities. 

We have different rate limit for each API and it varies based on the region. You can see the rate the rate limit for an API in the respective section.
