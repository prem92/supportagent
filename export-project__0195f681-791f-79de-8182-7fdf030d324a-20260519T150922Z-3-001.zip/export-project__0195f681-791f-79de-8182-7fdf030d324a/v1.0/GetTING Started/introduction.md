---
title: "Introduction"
slug: "introduction"
excerpt: ""
hidden: false
createdAt: "Fri Apr 08 2022 08:36:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jan 07 2025 10:00:15 GMT+0000 (Coordinated Universal Time)"
---
At Capillary, we offer AI-based cloud-native SaaS products and solutions such as automated loyalty management and consumer data platform. Our diverse product range enables you to manage end-to-end loyalty programs, gain a comprehensive view of your consumers, and offer unified, cross-channel strategies that provide consumers with real-time, omnichannel, personalized, and consistent experience.

- **Loyalty+** - Lets you increase repeat sales with personalized, omnichannel loyalty programs by intelligently rewarding your customers for desired behavior. [Know more details](https://docs.capillarytech.com/docs/loyalty-overview).
- **Engage+** - This allows you to personalize customer engagement with omnichannel retail marketing solutions.
- **Customer Data Platform (CDP)**: An effective platform to ingest data from different sources and platforms. There are several products to help capture brand data from different sources. [Know more details](https://docs.capillarytech.com/docs/integration-hub).
- **Insights+** - Provides you with profitable insights with AI-powered customer analytics. [Know more details](https://docs.capillarytech.com/docs/reports-introduction).

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9f4bd36d3682bf5b18e3f7c48f1153ec90ca90302b7101258c3b104f6441e50d-Overview.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
