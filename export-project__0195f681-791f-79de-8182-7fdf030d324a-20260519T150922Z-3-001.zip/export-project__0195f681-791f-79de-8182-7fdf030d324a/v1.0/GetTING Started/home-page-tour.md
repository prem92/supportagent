---
title: "Home page tour"
slug: "home-page-tour"
excerpt: ""
hidden: false
createdAt: "Fri Apr 08 2022 09:33:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jul 31 2024 05:12:43 GMT+0000 (Coordinated Universal Time)"
---
Post login, you will see a Home page. The Home page consists of several elements to help you find the key information about your products, programs, and links to product pages, tickets, support documentation, Capillary Academy, and much more.

The following sections provide detailed information on each section of the Home Page.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/be30ed6-6Nu6zPqQ2rL262kvUX5XEJYmCR7yNQ4nmw.png",
        "6Nu6zPqQ2rL262kvUX5XEJYmCR7yNQ4nmw.png",
        1427
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Get Started

This section helps you get started with Capillary products. It provides useful links to relevant documentation or support content.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b305fac-FC997pp7KwxEn_J9_wuXn4jXlXfCgQk4PA.png",
        "FC997pp7KwxEn_J9_wuXn4jXlXfCgQk4PA.png",
        1600
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Explore Features

This section provides links to powerful features across Capillary products. They could be major features that were launched recently or even some of the interesting older features.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/44637e9-qHMgiWvZWyhJpLFSBPnbpkV8eXvvnqJipA.png",
        "qHMgiWvZWyhJpLFSBPnbpkV8eXvvnqJipA.png",
        1600
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Loyalty suggestions

This section provides loyalty nudges, which help in taking the right actions for your loyalty programs. These are the same nudges that you see on the Loyalty+ landing page. Having them on the home page provides better accessibility to nudges.

![](https://files.readme.io/854a42f-hmHkogeVqcve-fzz8RjYOdlGQhOkwRSLtw.png "hmHkogeVqcve-fzz8RjYOdlGQhOkwRSLtw.png")

## Performance

This section shows the top level stats of the value delivered from the products. These are the same stats that you would see in the Loyalty+ and Engage+ landing pages.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4565b72-H9Zzl9DBkaD81-xeJ9j6Lx24JYlThyU4qQ.png",
        "H9Zzl9DBkaD81-xeJ9j6Lx24JYlThyU4qQ.png",
        1600
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Quick links

This section provides links to live campaigns, Loyalty Programs, Member Care customer requests, and SMS credits view.

![](https://files.readme.io/cc3e766-0XG3E2q5ty0ThyR2N2BqFbey_ZpeZl1gPA.png "0XG3E2q5ty0ThyR2N2BqFbey_ZpeZl1gPA.png")

## Help links

This section provides links to the support content. You can find links to access support documentation, tickets, and [Capillary Academy](https://academy.capillarytech.com/learn).

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e95c93a-7RPu0tEUXPUhhe7NZ4oQ_f1_ZAgUwXiwWA.png",
        "7RPu0tEUXPUhhe7NZ4oQ_f1_ZAgUwXiwWA.png",
        1600
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Access products/Workbench

You can access all the products like Loyalty+, Member Care, Insights+, and Workbench on the home page. Navigate to _Select Product_ menu and select the desired option.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b0968be-image.png",
        "image.png",
        1893
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
