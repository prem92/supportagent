---
title: "Introduction to Insights+"
slug: "insights-overview"
excerpt: ""
hidden: true
createdAt: "Mon Dec 06 2021 10:32:59 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Feb 21 2024 08:15:40 GMT+0000 (Coordinated Universal Time)"
---
## What is Insights+ and how can you leverage it?

Capillary’s Insights+ is an effective business intelligence tool that offers a 360-degree analysis of an organization's business data. With Insights+ capabilities you can measure metrics such as the revenue impact of your marketing campaigns, loyalty program and much more to effortlessly optimize future performance.

Leveraging such insights can: 

- Help you drive product innovation.
- Track and improve the impact of product launches in real-time.
- Accelerate business outcomes across the lifecycle.
- Drive loyalty
- Make smart, quick and informed decisions with data-driven insights.

## Where does Insights+ lie with respect to Loyalty+, Engage+ and CDP?

Insights+ essentially consumes data from your Loyalty+, Engage+ and CDP platforms to magically transform it into useful data insights. Further, it provides multiple capabilities for you to visualize and analyze your data effectively so that you can take smart, quick and informed decisions to optimize your business performance.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d4816b8-Screenshot_382.png",
        "Screenshot (382).png",
        620
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## What are the building blocks of Insights+?

The nascent data in Insights+ transforms into KPIs, dimensions, charts and then finally into reports. KPIs are**_ Key Performance Indicators _**and gives a **_quantifiable measure of performance_**. Eg Total bill Amount. Now upon the KPI you can apply **_Dimensions _**which are essentially **_attributes _**of the KPIs . Dimensions are used to split the KPI data based on certain attributes and _create charts_. Insights+ is equipped with over 50 predefined charts and 250 key performance indicators (KPIs).

A collection of charts is designated as reports on Insights. Refer to the image below to understand the building block of Insights+

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/013fa16-Screenshot_384.png",
        "Screenshot (384).png",
        710
      ],
      "align": "center",
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


There are two types of reports available in Insights.

**Standard Reports **: These are product wise predefined reports created by Capillary which gives you an overview of each product performance  
**Custom Reports** :  Capillary gives you the provision to create personalized reports as per your requirements.

## What are the advanced features that Insights+ provides?

Apart from reports, Insights+ provides advanced capabilities such as, Customer Segmentation and Data Exports.

**Customer Segmentation  
**  
With Customer Segmentation feature you can segment the customers based on their behavior and demographics. Analytics on these segments will help you to understand the customer’s behavior better and subsequently make more effective business decisions in terms of pricing, offers and retention strategies. An excellent example of the same is RFM segmentation.

** Data Exports  
**  
Data Export helps you export the CRM data available in the Capillary's system to an FTP location or internal server. You can export data related to customers, transactions, coupons, points, Footfall, and campaigns. You can create an export job using templates. Each template is a combination of either KPIs or facts, and dimensions.
