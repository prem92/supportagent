---
title: "Troubleshooting"
slug: "vulcan-troubleshooting"
excerpt: ""
hidden: false
createdAt: "Tue Sep 24 2024 10:41:15 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 07 2024 05:37:27 GMT+0000 (Coordinated Universal Time)"
---
[block:parameters]
{
  "data": {
    "h-0": "Error Code",
    "h-1": "Description",
    "h-2": "Reason",
    "0-0": "100",
    "0-1": "User input validation error",
    "0-2": "This error indicates that the input provided by the user is incorrect in format, missing required fields, or the data does not meet validation criteria.",
    "1-0": "200",
    "1-1": "Identifier validation error",
    "1-2": "This error indicates a problem with a specific identifier, such as an application or deployment ID. It usually means the identifier is invalid or not recognized by the system.",
    "2-0": "300",
    "2-1": "Database failure",
    "2-2": "This error indicates a failure at the database level, often due to connection issues, query failures, or integrity constraints being violated.",
    "3-0": "400",
    "3-1": "Service failure",
    "3-2": "This error indicates a generic service failure, which could mean that an internal service is down, not responding, or has a fault in the service logic.",
    "4-0": "500",
    "4-1": "Utility failure",
    "4-2": "This error indicates a failure in utility functions or operations supporting the main service, such as helper functions or configuration loaders.",
    "5-0": "600",
    "5-1": "Downstream service failure",
    "5-2": "This error indicates a failure in a downstream service that the current service depends on, often due to issues with external API calls, third-party services, or microservices ([Extensions](https://docs.capillarytech.com/reference/introduction-extensions), [Neo Extensions](https://docs.capillarytech.com/reference/api-extension-doc), Shield).",
    "6-0": "700",
    "6-1": "Referrer validation error",
    "6-2": "This error indicates that the referrer, commonly used in HTTP requests to validate the origin of the request, is invalid.",
    "7-0": "800",
    "7-1": "Middleware validation error",
    "7-2": "This error indicates issues within the middleware layer, often related to authentication, authorization, or preprocessing steps before the main service logic is executed.",
    "8-0": "Uncaught Error",
    "8-1": "Remote loaded successfully but `ushc_crm_4000084_membercareDev4000084_MFE`  \ncould not be found! Verify that the name is correct  \nin the Webpack configuration!",
    "8-2": "UAT or Prod mode for the application is not enabled and is currently running on localhost."
  },
  "cols": 3,
  "rows": 9,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


> 📘 Note
> 
> API responses may return combined error codes, which include both an internal error code and an HTTP status code.
> 
> For example an error code `600412` would mean:
> 
> 600: Internal error code.  
> 412: HTTP status code.
> 
> Refer to the [HTTP status code list](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status) for more information.
