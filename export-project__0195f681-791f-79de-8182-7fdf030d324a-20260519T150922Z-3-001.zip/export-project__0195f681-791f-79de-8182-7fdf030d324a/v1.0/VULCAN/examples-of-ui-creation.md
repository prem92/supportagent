---
title: "Examples"
slug: "examples-of-ui-creation"
excerpt: ""
hidden: false
createdAt: "Thu Aug 08 2024 06:19:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Aug 20 2024 11:46:15 GMT+0000 (Coordinated Universal Time)"
---
# Microsite

A microsite is a mini website that brands can use to promote their products or enable a specific functionality. A microsite is independent from the main website, with its own landing page and a separate domain. For example a microsite for a rewards catalog or to highlight a new campaign or offering.

To get started, refer to the documentation on [creating a microsite](https://docs.capillarytech.com/reference/creating-a-microsite-using-vulcan).

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9984775-Frame_5.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "85% ",
      "border": true
    }
  ]
}
[/block]


# Member Care UI Replica

Brands can customize Capillary's Member Care to fit their custom requirements. For example, a custom tab with trackers and graphs.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3c2af14-Frame_4.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "85% ",
      "border": true
    }
  ]
}
[/block]


To get started, refer to the documentation on [customizing the Member Care UI](https://docs.capillarytech.com/reference/customizing-the-member-care-ui).
