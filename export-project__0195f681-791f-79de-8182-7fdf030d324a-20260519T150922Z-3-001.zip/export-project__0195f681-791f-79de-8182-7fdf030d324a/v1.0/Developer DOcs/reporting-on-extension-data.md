---
title: "Reporting on Extension Data"
slug: "reporting-on-extension-data"
excerpt: ""
hidden: true
createdAt: "Thu Aug 08 2024 08:33:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 11:50:56 GMT+0000 (Coordinated Universal Time)"
---
To enable reporting on data stored through extensions, create a schema using [external facts](https://docs.capillarytech.com/docs/external_facts). Once the schema is created, contact the Insights team to enable reporting capabilities.
