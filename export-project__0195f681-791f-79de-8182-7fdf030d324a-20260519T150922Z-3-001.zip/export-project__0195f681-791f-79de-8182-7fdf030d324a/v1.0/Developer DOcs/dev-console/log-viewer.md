---
title: "View API Logs"
slug: "log-viewer"
excerpt: ""
hidden: false
createdAt: "Tue Mar 25 2025 13:19:45 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Apr 01 2025 08:48:47 GMT+0000 (Coordinated Universal Time)"
---
This feature allows you to view and search logs for debugging purposes. 

To use the log viewer, perform the following:

1. Navigate to **Logs and Metrics > Log Viewer **  from the left pane of the Dev Console.
2. From the **Extension** dropdown, select the desired extension for which you want to view logs.
3. In the **Date/Time Range**, specify the time range for the logs you want to retrieve.  
   **Note**: The maximum range is twenty-four hours.
4. Define the **Log limit**   as per your requirement.  
   **Default value**: 1000
5. To search for a specific log, enter a request ID or other keywords in the search bar. The log viewer will filter the logs based on your search query.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/baa832ce2268fbb77439606663b895c38f6201606fcd1cabf68712416f1ef21c-log_view.gif",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
