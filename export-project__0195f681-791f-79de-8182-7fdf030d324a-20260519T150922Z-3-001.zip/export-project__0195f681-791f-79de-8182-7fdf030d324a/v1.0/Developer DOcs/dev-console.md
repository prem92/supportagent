---
title: "Dev Console"
slug: "dev-console"
excerpt: ""
hidden: false
createdAt: "Tue Apr 01 2025 06:14:08 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Apr 01 2025 08:48:47 GMT+0000 (Coordinated Universal Time)"
---
- [Introduction](https://docs.capillarytech.com/docs/introduction-dev-console)
- [Handle Deployment](https://docs.capillarytech.com/docs/handle-deployment)
- [View API Logs](https://docs.capillarytech.com/docs/log-viewer)
- [View API Performance Metrics](https://docs.capillarytech.com/docs/platform-metrics)
- [Save Extension Configurations](https://docs.capillarytech.com/docs/extension-configuration)
- [Connect and Manage DB](https://docs.capillarytech.com/docs/db-management)
