---
title: "Extension"
slug: "extension"
excerpt: ""
hidden: false
createdAt: "Fri Mar 28 2025 11:46:03 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 14:09:00 GMT+0000 (Coordinated Universal Time)"
---
- [Quickstart for Neo Extension](https://docs.capillarytech.com/docs/neo-quick-start)
- [Use Cases](https://docs.capillarytech.com/docs/neo-use-cases) 
- [Introduction](https://docs.capillarytech.com/docs/introduction-to-extension-platform)
- [Core Concepts](https://docs.capillarytech.com/docs/core-concepts)
- [Configuration & Setup](https://docs.capillarytech.com/docs/configuration-setup)
- [Building Block Configuration](https://docs.capillarytech.com/docs/building-block-configuration)
- [Execution & Monitoring](https://docs.capillarytech.com/docs/execution-monitoring)
- [Advanced Features](https://docs.capillarytech.com/docs/advanced-features)
- API Extension Catalogue
- FAQs
