---
title: "Introduction"
slug: "introduction-to-extension-platform"
excerpt: ""
hidden: false
createdAt: "Thu Jan 23 2025 05:04:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 14:04:45 GMT+0000 (Coordinated Universal Time)"
---
- [Overview](https://docs.capillarytech.com/docs/overview-neohttps://docs.capillarytech.com/docs/overview-neo)
- [Enabling & Managing Access to NeoEnabling & Managing Access to Neo](https://docs.capillarytech.com/docs/access-management-neohttps://docs.capillarytech.com/docs/access-management-neo)
- [Introduction to the UI](https://docs.capillarytech.com/docs/introduction-to-the-ui-neohttps://docs.capillarytech.com/docs/introduction-to-the-ui-neo)
