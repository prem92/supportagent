---
title: "Troubleshooting"
slug: "troubleshooting-neo"
excerpt: ""
hidden: true
createdAt: "Wed Aug 07 2024 10:42:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 11:50:43 GMT+0000 (Coordinated Universal Time)"
---
[block:parameters]
{
  "data": {
    "h-0": "**Error**",
    "h-1": "**Reason**",
    "0-0": "API not triggering",
    "0-1": "- Check the API method and URl as defined in the Trigger.  \n- Ensure the dataflow is active.  \n- Ensure the required headers are set.  \n- Authentication tokens are valid.  \n- For APIs that are not Live, ensure the variant ID is correct.",
    "1-0": "Unable to create a dataflow",
    "1-1": "- Ensure you have User permissions - read, write, edit.",
    "2-0": "Incorrect or missing data in Mongo DB",
    "2-1": "- Check the Mongo DB connections.  \n- Validate the input data.",
    "3-0": "API request errors",
    "3-1": "- Check the HTTP status code returned by the API.  \n- Check error messages.",
    "4-0": "Unable to save the dataflow",
    "4-1": "- Check for unconfigured blocks  \n- Missing connectors  \n  **Note**: Error blocks are shown in red."
  },
  "cols": 2,
  "rows": 5,
  "align": [
    "left",
    "left"
  ]
}
[/block]
