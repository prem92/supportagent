---
title: "API Extension Catalogue"
slug: "api_extension_catalogue_intro"
excerpt: ""
hidden: false
createdAt: "Thu Oct 10 2024 09:06:29 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 11:37:34 GMT+0000 (Coordinated Universal Time)"
---
The API extension catalogue displays the applications developed using the Capillary API extensions. Some extensions are brand-specific and some are available for all orgs. Contact the access team for access to the extensions page and contact your CSM to enable specific extensions for your org. You can also create specific extensions for your brand as per your requirements.
