---
title: "Core Concepts"
slug: "core-concepts"
excerpt: ""
hidden: false
createdAt: "Thu Mar 13 2025 13:00:20 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 14:05:39 GMT+0000 (Coordinated Universal Time)"
---
- [Dataflow & Building Blocks](https://docs.capillarytech.com/docs/dataflows)
- [Block Libraries](https://docs.capillarytech.com/docs/block-libraries)
- [Tags & Filters in DataflowTags & Filters in Dataflow](https://docs.capillarytech.com/docs/tags-filters-in-dataflow)
