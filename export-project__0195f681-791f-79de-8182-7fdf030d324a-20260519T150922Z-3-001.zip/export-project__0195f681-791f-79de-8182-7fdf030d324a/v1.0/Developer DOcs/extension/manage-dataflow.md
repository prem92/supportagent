---
title: "Manage Dataflow"
slug: "manage-dataflow"
excerpt: ""
hidden: false
createdAt: "Tue Apr 01 2025 06:01:35 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Apr 01 2025 08:48:58 GMT+0000 (Coordinated Universal Time)"
---
- [Composing a Neo Dataflow](https://docs.capillarytech.com/docs/composing-a-neo_dataflow)
- [Editing a Dataflow](https://docs.capillarytech.com/docs/editing-a-dataflow)
- [Deactivating a Dataflow](https://docs.capillarytech.com/docs/deactivating-a-dataflow)
- [Viewing a Dataflow List](https://docs.capillarytech.com/docs/viewing-dataflow-list)
