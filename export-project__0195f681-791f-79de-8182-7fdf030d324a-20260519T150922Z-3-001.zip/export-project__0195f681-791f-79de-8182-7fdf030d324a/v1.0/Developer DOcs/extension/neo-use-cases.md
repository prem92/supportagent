---
title: "Use Cases"
slug: "neo-use-cases"
excerpt: ""
hidden: true
createdAt: "Thu Sep 26 2024 06:10:32 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 11:56:13 GMT+0000 (Coordinated Universal Time)"
---
[Creating and Customising APIs](https://docs.capillarytech.com/reference/examples-of-api-creation-and-customisation)
