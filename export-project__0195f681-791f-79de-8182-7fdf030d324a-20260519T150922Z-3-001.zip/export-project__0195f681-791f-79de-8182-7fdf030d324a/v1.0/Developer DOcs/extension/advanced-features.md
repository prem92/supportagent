---
title: "Advanced Features"
slug: "advanced-features"
excerpt: ""
hidden: false
createdAt: "Wed Mar 26 2025 13:17:41 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 13:58:27 GMT+0000 (Coordinated Universal Time)"
---
[Access Sensitive Data in Neo Dataflows Using Configuration Manager](https://docs.capillarytech.com/docs/configuration-manager)

[Approval Flow](https://docs.capillarytech.com/docs/approval-flow)
