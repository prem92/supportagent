---
title: "Configuration & Setup"
slug: "configuration-setup"
excerpt: ""
hidden: false
createdAt: "Thu Mar 13 2025 13:04:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 13:55:32 GMT+0000 (Coordinated Universal Time)"
---
[Configuring Conditions](https://docs.capillarytech.com/docs/configuring-conditions)

[Configuring Relations](https://docs.capillarytech.com/docs/configuring-relations)

[Configuring Caching](https://docs.capillarytech.com/docs/configuring-caching)

[Composing a Dataflow](<>)
