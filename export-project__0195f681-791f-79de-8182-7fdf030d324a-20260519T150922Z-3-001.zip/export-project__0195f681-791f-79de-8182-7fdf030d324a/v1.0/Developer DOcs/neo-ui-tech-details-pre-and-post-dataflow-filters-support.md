---
title: "Neo UI Tech Details: Pre- and Post-Dataflow Filters Support"
slug: "neo-ui-tech-details-pre-and-post-dataflow-filters-support"
excerpt: ""
hidden: true
createdAt: "Tue Oct 29 2024 12:53:37 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 28 2025 11:37:30 GMT+0000 (Coordinated Universal Time)"
---
# Introduction

<br />

# Purpose
