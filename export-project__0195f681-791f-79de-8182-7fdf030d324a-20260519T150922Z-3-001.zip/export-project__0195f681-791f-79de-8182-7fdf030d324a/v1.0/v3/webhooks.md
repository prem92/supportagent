---
title: "Webhooks"
slug: "webhooks"
excerpt: "These webhooks are used for event notifications and configuring target loyalty."
hidden: true
createdAt: "Mon Oct 28 2024 07:46:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Nov 26 2024 06:56:23 GMT+0000 (Coordinated Universal Time)"
---
