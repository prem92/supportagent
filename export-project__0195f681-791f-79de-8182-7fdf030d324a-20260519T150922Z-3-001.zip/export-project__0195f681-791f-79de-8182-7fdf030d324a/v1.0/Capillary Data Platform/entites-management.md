---
title: "Entites management (wip)"
slug: "entites-management"
excerpt: ""
hidden: true
createdAt: "Mon Nov 06 2023 05:02:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jan 16 2025 13:01:39 GMT+0000 (Coordinated Universal Time)"
---
# Overview

An entity is a distinct and identifiable object or concept, such as customers, products, or transactions. Each entity is characterized by fields or attributes that provide detailed information about it. These fields capture the properties or characteristics associated with the entity. For instance, an entity named "Customer" has fields such as Customer ID, First Name, and Last Name.

# Advantages

Entities allow standardised and consistent data handling across various applications and services promoting efficient data classification and analysis.

Standardized entities enable to:

- Enhance communication and interoperability by sharing information between different parts of the system.
- Simplify data integration and enhance data analysis, allowing businesses to gain better insights into customer behaviour.

This information allows target marketing, personalized customer interactions, and better decision-making leading to improved customer experiences.

# Supported entity types

The different types of entities in Capillary platform are:

1. **Customer**: A customer is an individual who either buys goods/services or subscribes to the organization’s newsletters. An organization refers to a store, business firm, hospital, or restaurant. See [v2 customer APIs](https://docs.capillarytech.com/reference/customer-1) and [v1.1 customer APIs](https://docs.capillarytech.com/reference/customer).
2. **Transactions**: A transaction represents a purchase or return event. The parameters for transaction APIs are configuration-dependent. See more details [v2 transaction APIs](https://docs.capillarytech.com/reference/transaction-1) and [v1.1 transaction APIs](https://docs.capillarytech.com/reference/transaction).
3. **Store**: The store entity holds information about an organization's stores and hierarchy. This entity provides APIs to manage stores. To know more, see [Store APIs](https://docs.capillarytech.com/reference/store).
4. **Product**: The product entity holds all products of an org and product-related information such as size, color, type, and brand. Product APIs allow you to fetch details of a specific product, modify existing details, change a product's brand name, and create new attributes for a product. See [Product APIs](https://docs.capillarytech.com/reference/product).
5. **Behavioral Events**: Behavioral events help capture customer activities such as registration, forgot passwords, and cart abandonment. You can create custom events, fetch event data, configure event fields, and do more with [Events APIs](https://docs.capillarytech.com/reference/behavioral-events-1).
6. **Card**: Cards are loyalty identifiers and enable orgs t o run card-based memberships. Cards are associated with a card series and each customer can have multiple cards. A card number or an card external ID is a unique identifier of a customer and is used in fetching customer details. See more about [Cards APIs.](https://docs.capillarytech.com/reference/loyalty-cards)
7. **User Group**: The new user group (v2) solves the use cases of both B2B loyalty and B2C loyalty unlike the previous version which was designed for B2C cases. This entity contains APIs to manage user groups. See more about [User Group.](https://docs.capillarytech.com/reference/user-group-v2)
8. **Request**: The requests entity enables solving use-cases where an approval workflow is required for the data ingestion, modification or deletion. For example, a user deletion workflow or a transaction addition workflow where approval is required. 

# Entity structure

Entities contain an object or a collection of objects and fields, which provide structured data representation.  
An object is a collection of key-value pairs, where each key is a string and the value can be a string, number, boolean, array, or another object.  
Fields refer to the keys in key-value pairs that define the structure of the data. There are three types of fields:

1. Standard fields
2. Extended fields
3. Custom fields

# Supported data types

The entities support data types such as integer, string, double, date-time, standard_enum, and custom_enum.

1. **Standard Enum:** Consists of predefined values that are common for any org. In the DB table, an extended field with the type standard_enum is mapped to one or more values.
2. **Custom Enum: **Consists of predefined values for each field and each value is mapped to a specific org. A value can be mapped to different orgs.
