---
title: "Member Care"
slug: "member-care"
excerpt: "The Member Care page provides the complete details of a customer."
hidden: false
createdAt: "Tue Sep 13 2022 05:33:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
# Introduction

Member Care is an application that offers a 360 view of the customer and also acts as a request management portal for support needs. It enables teams to effortlessly access and oversee customer accounts. Member care can be used by both external and internal users.

**External users**:

- Customer support team: They can view customer details, handle service requests such as Identifier Change and Account Merge, and monitor real-time customer events for troubleshooting purposes.
- Marketing team: They can get a 360-degree view of customer data and plan campaigns.

**Internal users**:

- System integrators and Customer Success Managers (CSM): They use Member Care to verify the ingestion of customer-level event data. They can instantly check operations performed for a customer.
- Support team: The Capillary support team utilizes Member Care to troubleshoot and resolve customer tickets, addressing any issues the customer may encounter.

## Searching for a customer or group

You can search for a customer or a group by searching from  **Search** on the Member Care home page or by clicking on the **Search** icon on the details page.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ed6d8d3-Search_customer.gif",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


By default, if enabled, when you open Member Care, the application opens the new Member Care UI.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/dfe3269-1.gif",
        "1.gif",
        1342
      ],
      "align": "center",
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


# Switching to the new UI

To switch to the new Member Care from the old UI <<glossary:CSV>> page, click **Open new Member Care**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e4c005a-Switch_to_new_UI.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


Also, from the old UI, if you click **Customer Search** the customer search opens in the new UI.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7bf007a-3.gif",
        "3.gif",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Sharing new profile link

To share the new Member Care UI, use url _{host URL}/member-care/ui/_.

To share or view the customer page in the new UI, use url _{host URL}/member-care/ui/{userId}_.

For example,  <https://eucrm.cc.capillarytech.com/member-care/ui/172076358>.

# Switching to the old UI

From the **Customer Search** page, click **Open old Member Care** to switch to the old UI.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6c42392-Switch_to_Old_member_care.gif",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


In addition, from the search result page, you can click on the switch icon and switch from the new UI to the old UI.

![](https://files.readme.io/4bad84a-Switch_to_Old_UI.png)

> 📘 Switching behavior is applicable only for **Search** > **Customer** and CSV pages. Once you switch to the old UI, everything else will work as is.

## Sharing old UI profile link

You can share the old UI customer profile link directly. To share, use the url _{host}/memberCare/search/Customer?oldFlow=true_.

For example, <https://eucrm.cc.capillarytech.com/memberCare/search/Customer?id=172076358&oldFlow=true>

> ❗️ You must use oldFlow=true parameter to directly navigate to the old UI search page. If you use the same URL without the oldFlow parameter, you will be redirected to the new Customer Search page.
