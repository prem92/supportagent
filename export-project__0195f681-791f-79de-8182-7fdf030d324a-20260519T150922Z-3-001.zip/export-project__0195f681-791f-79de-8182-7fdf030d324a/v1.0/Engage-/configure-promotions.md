---
title: "Configure Cart Promotions and Gift Vouchers"
slug: "configure-promotions"
excerpt: ""
hidden: false
createdAt: "Fri Jul 29 2022 09:54:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Mar 31 2025 11:04:54 GMT+0000 (Coordinated Universal Time)"
---
