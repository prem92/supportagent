---
title: "Content management"
slug: "content-management"
excerpt: ""
hidden: false
createdAt: "Mon Dec 06 2021 20:02:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:30 GMT+0000 (Coordinated Universal Time)"
---
Content Management lets you manage all the readily available content used for different channels like mobile push, SMS templates, and more. You can also create the content from scratch and save it for future usage.

Content management is the process of collection, delivery, retrieval, governance, and overall management of information in any format. The term is typically used in reference to the administration of the digital content lifecycle, from creation to permanent storage or deletion. The content involved may be images, video, audio and multimedia as well as text.
