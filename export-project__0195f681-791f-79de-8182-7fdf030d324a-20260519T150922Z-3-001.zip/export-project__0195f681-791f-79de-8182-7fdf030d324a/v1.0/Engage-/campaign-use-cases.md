---
title: "Use case"
slug: "campaign-use-cases"
excerpt: ""
hidden: false
createdAt: "Tue May 28 2024 09:38:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 29 2024 12:02:37 GMT+0000 (Coordinated Universal Time)"
---
# Creating a birthday campaign

A birthday campaign is a type of campaign that issues coupons to customers to celebrate their birthdays. This can be set up by creating a campaign and filtering customers based on their birthday month to issue the coupon. This helps customers receive a personalized discount or offer as a birthday gift, making them feel valued and appreciated.

Let us understand how to set up a birthday campaign where a brand needs to send out specific coupons to customers whose birthdays are approaching within the next xx days.

To create,

1. On your organization UI, open **Engage+**, and select **New campaign**.
2. Create a [new campaign](https://docs.capillarytech.com/docs/create-a-campaign) and configure the message.
3. On the **Audience** section, create an [audience group](https://docs.capillarytech.com/docs/audience-management).
4. On the **New audience group** window, perform the following:

   a. Select **Apply filter condition**.

   b. Select **Next**.

   c. On the created audience window, select **Filter**.

   d. From the drop-down menu, select **[User Profile](https://docs.capillarytech.com/docs/user-profile-based-filters)** > **Demographic details** > **Birthday**.

   e. In the **no of day** section, enter the number of days you want to send out specific coupons to customers whose birthdays are approaching.

   f. Select **Apply**.

   g. Select **Save group**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/05786ae-Screenshot_2024-05-29_141619.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Select **Continue**.
7. (Optional) On the **Content** section, you can either create or select a configured [creative](https://docs.capillarytech.com/docs/content-management) / [incentive](https://docs.capillarytech.com/docs/incentive-management) to send to the customers.
8. On the ** Schedule** section, schedule your [message](https://docs.capillarytech.com/docs/message-schedule).
9. Select **Send for approval**.

The campaign will be sent to the respective product manager for approval. Once approved, your birthday campaign will be activated.
