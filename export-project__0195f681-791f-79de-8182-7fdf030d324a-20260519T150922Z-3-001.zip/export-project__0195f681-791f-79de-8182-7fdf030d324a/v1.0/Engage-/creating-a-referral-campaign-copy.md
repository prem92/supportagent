---
title: "Creating a Referral Campaign (COPY)"
slug: "creating-a-referral-campaign-copy"
excerpt: ""
hidden: true
createdAt: "Mon Mar 24 2025 07:37:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Mar 24 2025 07:37:56 GMT+0000 (Coordinated Universal Time)"
---
Creating a referral campaign is done through the old campaign manager.

To set up a new referral campaign, follow these steps:

1. On the InTouch portal, select **Home **from the left-hand corner.
2. Select **Engage+ **from the sidebar menu.

   [block:image]{"images":[{"image":["https://files.readme.io/31313fc05c6c0826b9ea98335dbb8c8b278c48425ab21fcb9767ed89fdde26ec-image7.png",null,""],"align":"center","sizing":"75% ","border":true}]}[/block]
3. Select **Open old campaign manager**.

   [block:image]{"images":[{"image":["https://files.readme.io/0186aef6b94081469abfbc530e735357dd41ec546ea8fd19cd37e6f39e63538e-image5.png",null,""],"align":"center","sizing":"75% ","border":true}]}[/block]
4. Select **+New Campaign** from the **Campaigns Home** page.

   [block:image]{"images":[{"image":["https://files.readme.io/f3e1651b98deb5bb1c87e24b3348a0b8e7dff7809b0e5b85e68589dab7162256-image2.png",null,""],"align":"center","sizing":"75% ","border":true}]}[/block]
5. Choose **Referral **as the campaign type from the dropdown menu.
6. Enter the required details for the referral campaign and select appropriate configuration settings.

#### The table below provides descriptions of each field.

[block:parameters]
{
  "data": {
    "h-0": "**Field**",
    "h-1": "**Description**",
    "0-0": "Campaign Name",
    "0-1": "Name of the campaign.",
    "1-0": "Description",
    "1-1": "Brief description of the campaign.",
    "2-0": "Valid between",
    "2-1": "The date range for which the campaign is valid for.",
    "3-0": "[Campaign Objective](https://docs.capillarytech.com/docs/referral-campaign#the-table-below-provides-descriptions-of-each-category-under-campaign-objectives)",
    "3-1": "The primary objective of the campaign.",
    "4-0": "Incentivize Referrer",
    "4-1": "When to incentivize the referrer.  \n  \n- Dynamically as he reached the criteria: To issue incentives dynamically as and when the configured criterion is met.  \n- At the end of the campaign: To issue incentives at the end of the campaign period.",
    "5-0": "Disable Test-Control for this Campaign",
    "5-1": "Enable or disable test control - dividing the audience into test and control groups to evaluate the campaign's effectiveness.",
    "6-0": "Make Default for POS",
    "6-1": "Enable or disable campaign activation on POS.",
    "7-0": "Invite Registered Customers",
    "7-1": "Enable or disable inviting previously registered customers.",
    "8-0": "Register Customer Online",
    "8-1": "Enable or disable registering a customer online using a social app."
  },
  "cols": 2,
  "rows": 9,
  "align": [
    "left",
    "left"
  ]
}
[/block]


#### The table below provides descriptions of each category under Campaign Objectives.

| Category      | Values                              | Help Text                                                                                                                            |
| :------------ | :---------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------- |
| Acquisition   | General                             | Acquire new transacting customers from a given acquisition channel                                                                   |
|               | Referral                            | Acquire new transacting customers through referrals by an existing customer                                                          |
| Delight       | Birthday/Anniversary                | Delight customers with incentives around life events to encourage them to transact by redeeming points or coupons                    |
|               | Feedback/Survey                     | Delight customers with incentives and encourage them to take a survey or provide feedback                                            |
| Informational | Customer Joinee Program             | Encourage new loyalty customers to know more about the program benefits and the brand. Increase in repeat purchase frequency and LTV |
|               | Store Opening (Awareness)           | Inform customers nearby about a new store opening to boost transactions at the store                                                 |
|               | Product Launch                      | Inform potentially interested customers about a new product launch to boost sales for the newly launched product                     |
|               | Season/Arrivals                     | Inform potentially interested customers about new collections/stock in the stores to boost sales                                     |
|               | Brand awareness, Informercial       | Brand building exercise and information sharing with customers to increase overall customer engagement with the brand                |
| Promotional   | Up sell                             | Promotional campaign to encourage people to buy higher volumes of the same SKUs - higher count per SKUs                              |
|               | Cross-Sell                          | Promotional campaign to encourage people to buy different SKUs - higher count of unique SKUs                                         |
|               | Sales Booster                       | Promotional campaign to encourage people to buy more - higher ABS and ABV                                                            |
| Miscellaneous | Heavy Discount Sale (includes EOSS) | Boost sales during any heavy discount periods including festivals and EOSS                                                           |
|               | Frequency Enhancer                  | Encourage lower frequency visitors to transact more frequently                                                                       |
|               | Lapsation                           | Reactivate lapsed customers and encourage them to transact.                                                                          |

8. Select **Create **to create the referral campaign.

## Configuring Incentives

Incentives are rewards or benefits designed to motivate and encourage a customer. Incentives can be used to reward the referrer and referee for a successful referral.

There are two types of incentives supported, coupons and points. Once the campaign is set up, configure the incentives for a successful referral. 

### Issuing Coupons

You can configure issuing coupons for a referral campaign in the old campaign manager.

To add a coupon to a referral, follow these steps:

1. Select **Rewards **to configure the rewards for the referral campaign.
2. Select **Incentives to Referrer **or **Incentives to Referee **to incentivize the referrer or referee respectively.
3. Select **+** beside **On Referee Registration **or** On Referee Transaction **to incentivize registrations or transactions.

   [block:image]{"images":[{"image":["https://files.readme.io/b696f36cf109540a18bc3c92b1e0c371c8a631147143e125867e2248d5a4fbc6-image8.png",null,""],"align":"center","sizing":"75% ","border":true}]}[/block]
4. Enter the number of registrations or transactions required to fulfill the criteria.
5. Select the **Edit **icon to configure the coupon.

   [block:image]{"images":[{"image":["https://files.readme.io/ba78ed42e4c216e4afcedb86e587bc20e4ab3480ca12b2490494e0b06212003e-image9.png",null,""],"align":"center","sizing":"75% ","border":true}]}[/block]
6. Select **Create Coupon Series **to [create a new coupon](https://docs.capillarytech.com/docs/create-offer-1#create-offers), or select **Claim Coupon Series **to add an existing coupon, ensuring the coupon code number is greater than 6.
7. Enable **Notification Settings **for SMS or email if needed.
8. Select **Save **to save the changes.

### Issuing Points

You can configure issuing coupons for a referral campaign through Loyalty+.

To issue points for a referral, follow these steps:

1. Navigate to the edit page of the default loyalty program of the organisation.

> 📘 Note:
> 
> The Award Points to Referee action is available only for [workflows](https://docs.capillarytech.com/docs/workflows) within the default [loyalty program](https://docs.capillarytech.com/docs/features-of-loyalty).

1. Under **[Workflows](https://docs.capillarytech.com/docs/workflows)**, create a new rule to configure issuing points for a referral.

> 📘 Note:
> 
> The following rules can be used to issue points for a referral:
> 
> 1. **referrerCode.refereeRegCount**  
>    Track the number of referrals done by the referrer.  
>    For example, if a referrer successfully refers to an individual, points are issued to the referrer.
> 2. **referrerCode.refereeTxnCount**  
>    Track the number of transactions done by the referee.  
>    For example, if a referee makes a successful transaction, points are issued to the referrer.
> 
> Refer to the documentation on [rule writing](https://docs.capillarytech.com/docs/rule-writing) for more information.

3. Select **Add action** to award points to either the referrer or referee. To award points to the referee select **[Award points to referee](https://docs.capillarytech.com/docs/actions#award-points-to-referee) **. To award points to the referrer select **[Award Points to Referrer](https://docs.capillarytech.com/docs/actions#award-points-to-referrer) **.
4. Select [points earn conditions](https://docs.capillarytech.com/docs/points-1-1#configure-points-earn-conditions) and [points expiry conditions ](https://docs.capillarytech.com/docs/points-1-1#expiry-conditions), then choose the communications channels.
5. Select **Save and Continue** to apply the changes.

## Creating a Broadcast Campaign using the New UI

To create a brand referral campaign using the new UI, you need to first set up a referral campaign in the old UI. Once that's done, you can link the brand referral to the created broadcast campaign in the new UI. Follow the steps below:

1. Create a [Referral Campaign](https://docs.capillarytech.com/docs/referral-campaign#creating-a-referral-campaign-end-to-end-flow) in the Old UI.
2. On the InTouch portal select **Home** from the left-hand corner.
3. Select** Engage+** from the sidebar menu.
4. Select **New Campaign**.
5. Enter the** campaign details **

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fa73b13a54a758ceabe8d5d4ffabc1ef4109920db387e8035bfaa2eface78630-Screenshot_54.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


#### The table below provides descriptions of each field.

| Field             | Description                                          |
| :---------------- | :--------------------------------------------------- |
| Campaign Name     | Name of the campaign (supported upto 50 characters). |
| Campaign Duration | Start date and end date of the campaign.             |

6. Go to **Advanced Settings**.
7. Select  **Attach a Referral Campaign**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/668abe39f9d41eb6f68ccd4b85c9fb5f265dcaab259436ef8bf7a52751e73944-Screenshot_55.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


8. From the **dropdown menu**, select the referral campaign previously created in the Old UI.
9. Select** Save Campaign** to finalize the setup.

The Campaign has been created.

## Creating & Sending a Referral Campaign Message

1. On the InTouch portal select **Home** from the left-hand corner.
2. Select** Engage+** from the sidebar menu.
3. Select a campaign to create a message.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c67991f5da7860fe2030a8a1f85c9f559ccefb539cbb836cd3c6ac9ef8aaac98-Screenshot_59.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. Add the **Audience Group** for the campaign.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c8cf94c68c13bb85d5bc7cea196ac79954c45a8487d72bfbb6d5f901700879cb-Screenshot_61.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Create the campaign content under the **Content** section. Refer to the [Content Management](https://docs.capillarytech.com/docs/content-management) document for more information on creating content.

> 📘 Note
> 
> Ensure to add the **referral unique code** tag.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/17a7a3aeab08d0fcc1940f98f3ab2bc7e0182ae951bfa0fbbb4cf42d57e00aaf-Screenshot_93.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Schedule the campaign as per your requirements and send it for approval. Refer to the [Message Schedule](https://docs.capillarytech.com/docs/message-schedule) document for more information on message scheduling.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/04ae656736dedc1598dfdce2fd33091b94d944fa0a44330f27f63fefc7a7ac43-Screenshot_63.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


Once approved, the message will be successfully created.

## Viewing and Editing a Referral Campaign

1. On the InTouch portal, select **Home** from the left-hand corner.
2. Select **Engage+** from the sidebar menu.
3. Select **Old Campaign Manager ** to view existing campaigns.
4. Select the campaign you want to edit and make the necessary modifications.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/578c30124c32e5a0f0e8ff99d78098713f28cfc5efe2c95762732d7597b6e601-Screenshot_58.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


> 📘 Note
> 
> The token is a unique identifier used for the [Refer Customer API.](https://docs.capillarytech.com/reference/refer-customer)

## Deactivating a Referral Campaign

1. On the InTouch portal, select **Home** from the left-hand corner.
2. Select **Engage+** from the sidebar menu.
3. Select **Old Campaign Manager ** to view existing campaigns.
4. Select the campaign you want to disable.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/607c1d66b9656770ba09c88679f580364413edf96a3f860069d56d865950f048-Screenshot_58.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Select **Stop** to deactivate the Campaign.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aa08ae83d866f271e23434bf1645e4763d7cfe537ab2b9facb484d3e7ae82863-Screenshot_70.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. The campaign is successfully de activated.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aac6ca6d8bb387112083ff47331cac218e74160ea87e735f1cc4633dc4055ae7-Screenshot_71.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Activating a Referral Campaign

1. On the InTouch portal, select **Home** from the left-hand corner.
2. Select **Engage+** from the sidebar menu, then choose **Old campaign manager**.
3. Select **Lapsed** to view the deactivated referral campaigns.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/17dc3646248442ed4763a5953447977d2aa064c49aaa3a048b63175ad44476e5-Screenshot_72.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. Select **start** to activate the campaign.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b312bcdbf3fafb57596f89037742ba5b9c7c8354a96e9e6b3e8073b51d3a4ef6-Screenshot_73.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. The campaign is successfully activated and can be viewed in the **Old Campaign Manager**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3f090420c58f71c9ef7be9407c5ce91d5cb16fcf42f7cc20d4a1cf496300056f-Screenshot_75.png",
        "",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
