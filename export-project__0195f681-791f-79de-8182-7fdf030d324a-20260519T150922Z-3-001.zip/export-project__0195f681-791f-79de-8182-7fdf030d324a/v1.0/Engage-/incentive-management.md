---
title: "Incentive management"
slug: "incentive-management"
excerpt: ""
hidden: false
createdAt: "Mon Dec 06 2021 20:03:14 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:27 GMT+0000 (Coordinated Universal Time)"
---
Incentive manager basically allows you to set up various custom-focused incentives like offers, promotions and gift vouchers and also allows you to select the preferred point strategy that you can set up in Loyalty.

Here you can-

- **Create** incentives that can be audience specific
- The incentive **issual** setting can be configured
- You can also set up the **redeeming conditions** here.
