---
title: "Message Schedule"
slug: "message-schedule"
excerpt: ""
hidden: false
createdAt: "Wed Aug 24 2022 12:40:51 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
## Objective

Set a message delivery schedule. The message will be delivered based on the selected schedule.  
The schedule is a message delivery time frame. The schedule also includes repetitive and periodic delivery of campaign messages.
