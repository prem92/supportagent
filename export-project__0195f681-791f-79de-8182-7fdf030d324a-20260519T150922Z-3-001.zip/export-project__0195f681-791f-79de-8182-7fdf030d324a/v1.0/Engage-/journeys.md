---
title: "Journeys"
slug: "journeys"
excerpt: "Journeys is an engagement automation interface that enables you to create scenario-based flows to nurture your customers throughout their lifecycle."
hidden: false
createdAt: "Tue Jul 19 2022 11:05:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Feb 13 2025 08:47:50 GMT+0000 (Coordinated Universal Time)"
---
It helps marketers identify the right course of action by creating multi-campaign flows, incentivising customers, and engaging them via multi-channel personalized communication, all in one place. It also helps businesses automate their customer engagement flow.

It starts with an entry trigger and diverges into several branches based on the conditions set up. A customer goes through flows which the user sets up.

> 📘 Note
> 
> By default, Journey is not enabled for all the orgs. Raise a ticket to the Capillary Product Support team to enable this feature for your org.

# Use case

A brand wants to promote its new membership program to increase the number of loyal customers. They want to target customers whose lifetime purchase value is greater than 1000$. A marketer wants to nudge the customers to make a purchase and avail of the membership.

**Customer journey plan**

1. Identify the customers whose lifetime purchase is above 1000$.
2. Send an SMS to customers informing them about the ongoing opportunity to become a member of their target segment.
3. Wait for 30 days for customers to make a purchase.
4. If customers have made the purchase, share a congratulations email to the customer along with a 30% off coupon on their next purchase and also share the benefits of membership.
5. If customers have not made the purchase, send them a reminder message about the ongoing membership campaign.  
   Wait for another 15 days and end the campaign.

With Journey, you can use building blocks and configure the above flow at one place

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4e349c1-small-journey_intro.png",
        null,
        "Journey UI depicting a sample workflow"
      ],
      "align": "center",
      "border": true,
      "caption": "Journey UI depicting a sample workflow"
    }
  ]
}
[/block]
