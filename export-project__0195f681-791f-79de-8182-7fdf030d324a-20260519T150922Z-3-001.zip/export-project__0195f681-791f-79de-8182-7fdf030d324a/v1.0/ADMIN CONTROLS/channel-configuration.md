---
title: "Channel configuration"
slug: "channel-configuration"
excerpt: "This page provides you with information on communication/source channels in the Capillary platform."
hidden: false
createdAt: "Tue Dec 05 2023 00:59:51 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 05 2024 05:21:53 GMT+0000 (Coordinated Universal Time)"
---
The following channels are available on the Capillary platform. These can serve as either a source for customer registration, a communication channel to engage with a customer or both.

1. Facebook
2. WEB_ENGAGE
3. WECHAT
4. INSTORE
5. MARTJACK
6. TMALL
7. TAOBAO
8. JD
9. ECOMMERCE
10. WEBSITE
11. LINE
12. XIAOHONGSHU
13. GLOBAL_SCANNER
14. SUNING
15. PINDUODUO
16. KAOLA
17. MOBILE_APP
18. WHATSAPP
19. Linkedin
20. SMS
21. Indiamart
22. VIBER
23. MPUSH_FCM
24. STOREMAX
25. RCS
26. MAPP_SDK
27. OAUTH_EXTERNAL
28. ZALO

# Adding account

1. From the channels list, click on the required channel name.
2. Click **+Add account.**
3. Enter the following details. These fields can differ based on the channel. For adding the details, contact the Gateway team.
4. Click **Submit**.

> 📘 Note
> 
> If any of the channels are unavailable, please contact the Capillary Gateway team for support.
