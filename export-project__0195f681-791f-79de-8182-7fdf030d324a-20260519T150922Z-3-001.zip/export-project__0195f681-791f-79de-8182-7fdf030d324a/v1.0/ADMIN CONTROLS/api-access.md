---
title: "API security"
slug: "api-access"
excerpt: "This section provides you with information on how Capillary handles API security."
hidden: false
createdAt: "Tue Feb 14 2023 09:26:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
Capillary ensures API security through strong authentication and authorization methods. 

**Authentication** verifies that only users with appropriate credentials can access Capillary APIs whereas **Authorization** ensures that authenticated users with the right permissions can use specific APIs or resources. In simpler terms, a user with valid credentials can access APIs according to their allowed permissions, which are managed by authorization.
