---
title: "Set up events tracking"
slug: "set-up-events-tracking"
excerpt: ""
hidden: false
createdAt: "Fri Jun 30 2023 05:13:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Nov 05 2024 11:19:17 GMT+0000 (Coordinated Universal Time)"
---
Capillary SDK allows you to record events using the SDK for information about your app's usage patterns, and segment users based on their actions. For example, events such as signing in, launching an app, viewing a product, etc are used to track individual actions performed by users in your app or website.

There are 2 types of events:

1. **Standard events** - These events are configured in the SDK and cannot be removed.  With Capillary SDK, you can record user-specific information such as their username, first name, last name, email, mobile number, and other custom information, along with system information, in the events. This information can then be used to run campaigns based on user segregation at different levels. 
2. **Behavioural events** - The events resource also allows you to create behavioural events to track any other important user interactions for your business. For example, events such as forgot password, cart abandonment, etc. These events can be further defined by event attributes such as price, quantity, and category. These events need to be configured in your org settings.  
   For behavioural events, you need to do configuration in the Hydraconfig and organisation settings.

# Sending standard events to SDK

The SDK offers four event-tracking APIs for recording for reporting user action events. These APIs enable you to recognize visitors, monitor events, generate events dynamically, and track the activities of users, including any properties that describe their actions. This information can be used to gain insights into user behavior and create campaigns based on user segmentation at different levels. For example, with the user event data, you can send welcome messages to customers through e-mail or offer different offers based on user age, gender, etc.

The SDK has below standard event tracking APIs:

1. Sign In
2. Sign Up
3. User Update
4. Sign Out

***

## Sign In

This API enables reporting of a SignIn event to the SDK.

```swift
public func reportUserSignIn(data: UserSignInGenerator, customData: Attributes)
```

- `UserSignInGenerator`: This object holds the necessary basic information. You can generate this object by organizing the required information into a suitable container or object that adheres to the `UserSignInGenerator` protocol. 
- `customData` (Optional): This allows adding any extra information or custom data associated with the event being reported. The custom data should be added in the format of a`Dictionary<String, Any>`. 

| Parameters | Type       | Description                                                      | Mandatory/Optional |
| :--------- | :--------- | :--------------------------------------------------------------- | :----------------- |
| firstName  | String     | User first name                                                  | Mandatory          |
| lastName   | String     | User last name                                                   | Mandatory          |
| email      | String     | User email address                                               | Optional           |
| phone      | String     | User mobile number                                               | Mandatory          |
| customData | Dictionary | Additional information associated with the event being reported. | Optional           |

**Example 1:** SignIn event with  empty`customData`parameter.

```swift
let userSignInData = UserSignInData(firstName: "first-name", lastName: "last-name", email: "email@goodemail.com", phone: "xxxxxxxx")
hydraCore.reportUserSignIn(data: userSignInData, customData: [:])
```

**Example 2:** SignIn event with `customData`attributes age and gender. This allows for the logging of specific attributes related to the user's age and gender during the user sign-in report.

```swift
let userSignInData = UserDetails(firstName: "first-name", lastName: "last-name", email: nil, phone: "xxxxxxxx")
hydraCore.reportUserSignIn(data: userSignInData, customData: [“Age”: “25”, “Gender”: “Male”])
```

**Example 3:  **SignIn event with `customData`attributes age, gender and email. 

```swift
let userSignInData = UserSignInData(firstName: "first-name", lastName: "last-name", email: "email@goodemail.com", phone: "xxxxxxxx")
hydraCore.reportUserSignIn(data: userSignInData, customData: [“Age”: “25”, “Gender”: “Male”])
```

***

## Sign Up

This API enables reporting of a SignUp (user registration) event to the SDK.

```swift
public func reportUserSignUp(data: UserSignUpGenerator, customData: Attributes)
```

- `UserSignUpGenerator`: This object holds the necessary basic information. You can generate this object by organizing the required information into a suitable container or object that adheres to the `UserSignUpGenerator` protocol. 
- `customData` (Optional): This allows adding any extra information or custom data associated with the event being reported. The custom data should be added in the format of a`Dictionary<String, Any>`.

| Parameters | Type       | Description                                                      | Mandatory/Optional |
| :--------- | :--------- | :--------------------------------------------------------------- | :----------------- |
| firstName  | String     | User first name                                                  | Mandatory          |
| lastName   | String     | User last name                                                   | Mandatory          |
| email      | String     | User email address                                               | Optional           |
| phone      | String     | User mobile number                                               | Mandatory          |
| customData | Dictionary | Additional information associated with the event being reported. | Optional           |

**Example 1:** SignUp event with empty`customData`parameter.

```swift
let userSignUpData = UserSignUpData(firstName: "first-name", lastName: "last-name", email: "email@goodemail.com", phone: "xxxxxxxx")
hydraCore.reportUserSignUp(data: userSignUpData, customData: [:])
```

**Example 2:  **SignUp event with  `customData`attributes age and gender. This allows for the logging of specific attributes related to the user's age and gender during the user sign-in report.

```swift
let userSignUpData = UserDetails(firstName: "first-name", lastName: "last-name", email: nil, phone: "xxxxxxxx")
hydraCore.reportUserSignUp(data: userSignUpData, customData: [“Age”: “25”, “Gender”: “Male”])
```

**Example 3:  **SignUp event with `customData`attributes age, gender and email. 

```swift
let userSignUpData = UserSignUpData(firstName: "first-name", lastName: "last-name", email: "email@goodemail.com", phone: "xxxxxxxx")
hydraCore.reportUserSignUp(data: userSignUpData, customData: [“Age”: “25”, “Gender”: “Male”])
```

***

## User profile update

This API enables reporting of a user details update event to the SDK.

```swift
public func reportUserProfileUpdate(data: UserProfileUpdateGenerator, customData: Attributes, subscriptions: [Any]? = nil)
```

- `UserProfileUpdateGenerator`: This object holds the necessary basic information. You can generate this object by organizing the required information into a suitable container or object that adheres to the `UserProfileUpdateGenerator` protocol. 
- `customData` (Optional): This allows adding any extra information or custom data associated with the event being reported. The custom data should be added in the format of a`Dictionary<String, Any>`.

| Parameters    | Type       | Description                                                      | **Mandatory/Optional** |
| :------------ | :--------- | :--------------------------------------------------------------- | :--------------------- |
| firstName     | String     | User first name                                                  | Optional               |
| lastName      | String     | User last name                                                   | Optional               |
| email         | String     | User email address                                               | Optional               |
| phone         | String     | User mobile number                                               | Optional               |
| customData    | Dictionary | Additional information associated with the event being reported. | Optional               |
| subscriptions | Array      | The subscriptions list for the logged in user.                   | Optional               |

**Example 1:** User profile update event with  empty`customData` parameter.

```swift
let userProfileUpdateData = UserProfileUpdateData(firstName: "first-name", lastName: "last-name", email: "email@goodemail.com", phone: "xxxxxxxx")
hydraCore.reportUserProfileUpdate(data: userProfileUpdateData, customData: [:])
```

**Example 2:** User profile update with `customData`attributes age and gender. This allows for the logging of specific attributes related to the user's age and gender during the user sign-in report.

```swift
let userProfileUpdateData = UserProfileUpdateData(firstName: "first-name", lastName: "last-name", email: "email@goodemail.com", phone: "xxxxxxxx")
hydraCore.reportUserProfileUpdate(data: userProfileUpdateData, customData: [“Age”: “25”, “Gender”: “Male”])
```

**Example 3:** User profile update event with `subscription` parameter.

```swift
var subscriptions: [HydraSubscription] = []
var subscription: HydraSubscription = HydraSubscription(channel: "EMAIL", priority: "BULK", type: "OPTIN")
 subscriptions.append(subscription)
 subscription = HydraSubscription(channel: "PUSH", priority: "BULK", type: "OPTIN")
 subscriptions.append(subscription)
let userProfileUpdateData = UserDetails(firstName: "first-name", lastName: "last-name", email: "email@goodemail.com", phone: "xxxxxxxx")
hydraCoreSDK.reportUserProfileUpdate(data: userProfileUpdateData, customData: [:], subscriptions: subscriptions)
```

***

## Sign Out

This API enables reporting of a sign-out event to the SDK.

```swift
public func reportUserSignOut(customData: [String: Any])
```

To log sign-out events, you can call the API without providing any data. This action removes all the user-related basic information, such as first name and mobile number, that was previously provided in the session.

**Example**

```swift
hydraCore.reportUserSignOut(customData: [:])
```

***

# Sending behavioural events to SDK

These events can be used to track user actions throughout the application. These events are valid only if the SDK receives the `SignIn` or `SignUp `events. Events are Invalid if they are called after a `SignOut` event. In order to track these events, users have to pass event names (NotNull or NonEmpty) and attributes (optional).

The API below enables the application to send the custom events:

```swift
public func reportBehavioralEvent(name: String, customAttributes attributes: Attributes) 
```

| Parameter  | Type       | Description                              | Mandatory/Optional |
| :--------- | :--------- | :--------------------------------------- | :----------------- |
| event_name | String     | Name of the event                        | Compulsory         |
| attributes | Dictionary | The custom attributes map for the events | Optional           |

**Example**:

```swift
hydraCore.reportBehavioralEvent(name: "event-name",
                                                        customAttributes: ["additional-info" : "additional-details",
                                                                                      ["additional-info" : "additional-details"])
```
