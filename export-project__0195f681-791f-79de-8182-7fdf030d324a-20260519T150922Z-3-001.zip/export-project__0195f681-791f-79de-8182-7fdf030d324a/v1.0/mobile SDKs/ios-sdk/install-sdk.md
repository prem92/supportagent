---
title: "Install SDK"
slug: "install-sdk"
excerpt: "This guide provides information on how to integrate your mobile apps with Capillary's iOS SDK."
hidden: false
createdAt: "Thu Jun 29 2023 13:02:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Dec 29 2023 02:08:18 GMT+0000 (Coordinated Universal Time)"
---
> 🚧 The HydraSDK repository is private.
> 
> - To access  [hydra-sdk-ios-packages](https://github.com/Capillary/hydra-sdk-ios-packages) repository, you must either have valid GitHub credentials with access to the repository or you can use your GitHub username and provide a Personal Access Token.
> - If you have a valid GitHub credentials with access to the [hydra-sdk-ios-packages](https://github.com/Capillary/hydra-sdk-ios-packages) repository, you need to add them to the Xcode accounts section to integrate the SDK. Follow [these](https://medium.com/nerd-for-tech/how-to-connect-github-and-xcode-499134c62eac) steps to complete the process.

# Prerequisites

**Access to HydraSDK Repository:**  
Valid GitHub credentials with access to the hydra-sdk-ios-packages repository.  
OR  
GitHub username and a personal access token with access to the repository.

- Using Valid GitHub Credentials:  
  If you are using GitHub credentials, add your GitHub credentials to the Xcode Accounts section. FOr more information, refer to this [documentation](https://medium.com/nerd-for-tech/how-to-connect-github-and-xcode-499134c62eac).
- Using GitHub Username and Personal Access Token:  
  If you are using GitHub username and personal access token, modify the package URL in Swift Package Manager:  
  `https://Username:[PERSONAL_ACCESS_TOKEN@github.com](mailto:PERSONAL_ACCESS_TOKEN@github.com)/Capillary/hydra-sdk-ios-packages.git`

You can install the SDK using Swift Package Manager (SPM) or Xcode. 

# Installing SDK using Swift Package Manager directly

SPM is a tool that helps to manage the distribution of Swift code. For more information, refer to [Swift.org](https://www.swift.org/package-manager/).

To install the Capillary iOS SDK using SPM, define the package and dependencies in the SPM's configuration file. Use the below snippet:

```swift
import PackageDescription
let package = Package(
  name: “<Project-name>”,
  dependencies: [
    .package(url:"https://github.com/Capillary/hydra-sdk-ios-packages",upToNextMajor(from: "1.1.0"))
  ]
)

```

This makes sure that the SPM fetches the Capillary iOS SDK from the specified repository and includes it as a dependency in your project.

# Installing SDK Using Xcode

You can also use Xcode and define the dependencies in SPM. To install the SDK using Xcode, perform the following:

> 📘 Prerequisites:
> 
> - Xcode 14 or later
> - Valid iOS project to integrate Hydra packages
> - Internet connectivity

To install the SDK using Xcode, perform the following:

1. Open the iOS project in Xcode.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6a06ec0-Open_Xcode.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "65% ",
      "border": true
    }
  ]
}
[/block]


2. On the **File **menu, select **Add Packages**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/20bcba9-Add_package.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "65% ",
      "border": true
    }
  ]
}
[/block]


3. In the search field, enter the URL`<https://github.com/Capillary/hydra-sdk-ios-packages>` or `https://Username:PERSONAL_ACCESS_TOKEN@github.com/Capillary/hydra-sdk-ios-packages.git`.You can also select the package from the list of recently added packages.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7a9c41e-Search_package.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "75% ",
      "border": true
    }
  ]
}
[/block]


4. From the **Dependency Rule**, select the version or branch of the package you want to use. To select the latest version of the package automatically, leave the version field blank.  
   Xcode fetches the package’s manifest file and displays its dependencies. Review these dependencies and make sure that they do not conflict with your project’s dependencies.
5. From the **Add to project** combo box, select the appropriate project.
6. Click **Add Package** .  
   A package selection box appears. Select the desired frameworks and click **Add package**.  
   Xcode will automatically update your project’s dependencies and generate an Xcode project file for the package.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ca0fa44-Select_framework.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "75% ",
      "border": true
    }
  ]
}
[/block]


7. Add the import statement at the top of the file where you want to use the package’s functionality and import the package to your project.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/da1762e-Import_package_to_your_work.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "75% ",
      "border": true
    }
  ]
}
[/block]
