---
title: "Overview"
slug: "overview_android-sdk"
excerpt: "This guide provides an overview about Capillary's Android SDK."
hidden: false
createdAt: "Wed Dec 20 2023 15:26:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 10 2024 09:00:16 GMT+0000 (Coordinated Universal Time)"
---
Capillary SDK enables you with essential analytics capabilities and helps you engage better with your users through [events tracking](https://docs.capillarytech.com/reference/track-events), [push notifications](https://docs.capillarytech.com/reference/push-notification) and a [notification center](https://docs.capillarytech.com/reference/configure-notification-center).

# Prerequisites

- Android SDK version V21 or above
- targetSdkVersion 33
- compileSdkVersion 33
- Google Firebase account

# Android SDK Size

| SDK library          | Size   |
| :------------------- | :----- |
| hydra-core-1.0.1     | 258 KB |
| hydra-firebase-1.0.1 | 26 KB  |
| hydra-pushbase-1.0.1 | 83 KB  |

To integrate your mobile apps with Capillary Android SDK, perform the below steps:

1. [Configure Firebase and gateway](https://docs.capillarytech.com/reference/configure-firebase) - Capillary mobile apps team
2. [Set up source account](https://docs.capillarytech.com/reference/set-up-source-account) - CSM/ Project Manager of the project
3. [Install the SDK](https://docs.capillarytech.com/reference/installing-sdk) - 
4. [Initialise the SDK](https://docs.capillarytech.com/reference/sdk-initialisation)
5. [Set up events tracking](https://docs.capillarytech.com/reference/track-events)
6. [Configure push notification](https://docs.capillarytech.com/reference/push-notification)
