---
title: "Create coupon series"
slug: "create-coupon-series-copy-archive"
excerpt: "Lets you create a new coupon series for the org."
hidden: true
createdAt: "Fri Feb 11 2022 07:31:15 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 10:40:57 GMT+0000 (Coordinated Universal Time)"
---
> 📘 Daily Limit on API Calls
> 
> You can make as many API calls as you need to create coupon series each day. But, it is important to be careful and balanced in how many calls you make at once to avoid overloading the system.
> 
> If limits are set for coupon series in the system, these limits will acts as an restriction for creating the number of coupon series per day.

# Body parameter

| Parameter              | Description                                                                                                                  |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| customPropertyMap      |                                                                                                                              |
| description            | Brief description of the card series.                                                                                        |
| discountCode           | Discount code                                                                                                                |
| validTillDate          | Validity of the card series in UTC timestamp. Format: YYYY-MM-DDTHH:MM:SS+/-(time-zone).                                     |
| maxRedeem              | Limit number of coupons to redeem.                                                                                           |
| isTransferrable        | Pass true if the recipient can transfer the coupon to someone else.                                                          |
| anyUser                | Pass true if any customer can redeem the coupon, pass false only if the customer who received the coupon can only redeem it. |
| sameUserMultipleRedeem | Pass true to allow users to redeem the coupon multiple times.                                                                |
| createdBy              | Unique ID of the admin who created the coupon series.                                                                        |
| numIssued              | Number of coupons to be issued from the coupon series.                                                                       |
| numRedeemed            | Number of coupons to be redeemed from the coupon series.                                                                     |
| createdOn              | Date and time of series creation in \`YYYY-MM-DDThh:mm:ssZ",                                                                 |
| seriesCode             | Unique alpha-numeric code of the coupon series.                                                                              |
| smsTemplate            | Message to be sent to issue a coupon from the series. Use predefined tags in the message wherever required.                  |
| isSMSDisabled          | Pass true to disable sending coupon related SMS to audience.                                                                 |
| dvsExpiryDate          | Date and time of                                                                                                             |
| priority               |                                                                                                                              |
| shortSMSTemplate       | Short message to send to users. Pass voucher_code to insert coupon code in the message.                                      |
| redemptionRange        | "{\"dom\" : [1], \"dow\": [1], \"hours\": [1]}"                                                                              |
| minBillAmount          | Minimum transaction amount for which the coupon redemption is applicable.                                                    |
| maxBillAmount          | Maximum transaction amount for which the coupon redemption is applicable.                                                    |
| campaignId             | Unique ID of the campaign associated with the series.                                                                        |
| redeemStoreType        | redeemable_stores",                                                                                                          |

# Response parameter

| Parameter                        | Description                                                      |
| -------------------------------- | ---------------------------------------------------------------- |
| id                               | Unique identifier for the data.                                  |
| orgId                            | Organization identifier.                                         |
| description                      | Brief description of the series.                                 |
| discountCode                     | Discount code associated with the series.                        |
| validTillDate                    | Validity end date of the series in UTC timestamp.                |
| validDaysFromCreation            | Number of valid days from the creation of the series.            |
| expiryStrategyValue              | Expiry strategy value for the series.                            |
| maxCreate                        | Maximum number of series that can be created.                    |
| maxRedeem                        | Maximum number of series that can be redeemed.                   |
| isTransferrable                  | Indicates if the series is transferrable.                        |
| anyUser                          | Indicates if any user can redeem the series.                     |
| sameUserMultipleRedeem           | Indicates if the same user can redeem the series multiple times. |
| isReferralExistingUsersAllowed   | Indicates if referrals for existing users are allowed.           |
| isMultipleUseAllowed             | Indicates if multiple uses of the series are allowed.            |
| isValidationRequired             | Indicates if validation is required for the series.              |
| isValidWithDiscountedItem        | Indicates if the series is valid with discounted items.          |
| createdBy                        | Identifier of the user who created the series.                   |
| numIssued                        | Number of series issued.                                         |
| numRedeemed                      | Number of series redeemed.                                       |
| createdOn                        | Date and time when the series was created.                       |
| lastUsed                         | Last time the series was used.                                   |
| seriesCode                       | Unique code for the series.                                      |
| smsTemplate                      | SMS template used for the series.                                |
| isSMSDisabled                    | Indicates if SMS is disabled for the series.                     |
| info                             | Additional information about the series.                         |
| isMultipleVouchersPerUserAllowed | Indicates if multiple vouchers per user are allowed.             |
| doNotResendExistingVoucher       | Indicates if existing vouchers should not be resent.             |
| mutualExclusiveSeriesIds         | IDs of series that are mutually exclusive to this series.        |
| storeIdsJson                     | JSON representation of store IDs associated with the series.     |
| isDvsEnabled                     | Indicates if DVS is enabled for the series.                      |
| dvsExpiryDate                    | Expiry date for DVS.                                             |
| priority                         | Priority level of the series.                                    |
| shortSMSTemplate                 | Short SMS template for the series.                               |
| maxVouchersPerUser               | Maximum number of vouchers per user.                             |
| minDaysBetweenVouchers           | Minimum number of days between vouchers.                         |
| maxReferralsPerReferee           | Maximum number of referrals per referee.                         |
| discountUpto                     | Maximum discount value for the series.                           |
| discountValue                    | Discount value of the series.                                    |
| dvsItems                         | DVS items for the series.                                        |
| redemptionRange                  | Redemption range for the series.                                 |
| minBillAmount                    | Minimum bill amount for redemption.                              |
| maxBillAmount                    | Maximum bill amount for redemption.                              |
| redeemAtStore                    | Stores where redemption is allowed.                              |
| campaignId                       | ID of the associated campaign.                                   |
| tag                              | Tag associated with the series.                                  |
| maxRedemptionsInSeriesPerUser    | Maximum redemptions per user in the series.                      |
| minDaysBetweenRedemption         | Minimum days between redemptions.                                |
| redemptionValidFrom              | Date from which redemption is valid.                             |
| sourceOrgId                      | Source organization ID.                                          |
| issueToLoyalty                   | Indicates if the series is issued to loyalty.                    |
| redeemStoreType                  | Type of store where the series can be redeemed.                  |
| offlineRedeemType                | Indicates if offline redemption is allowed.                      |
| isOldFlowEnabled                 | Indicates if the old flow is enabled.                            |
| isPreRedeemEventRequired         | Indicates if a pre-redemption event is required.                 |
| termsAndConditions               | Terms and conditions for the series.                             |
| signalRedemptionEvent            | Indicates if a signal redemption event is required.              |
| syncToClient                     | Indicates if the series is synced to the client.                 |
| showPinCode                      | Indicates if a PIN code should be shown.                         |
| targetUserDetails                | Details about the target user.                                   |
| numUploadedNonIssued             | Number of non-issued series uploaded.                            |
| numUploadedTotal                 | Total number of uploaded series.                                 |
| redemptionValidAfterDays         | Number of days after which redemption is valid.                  |
| ownedBy                          | Owner of the series.                                             |
| ownerId                          | ID of the owner.                                                 |
| ownerValidity                    | Validity of the owner.                                           |
| alphaNumeric                     | Indicates if the series is alphanumeric.                         |
| shortCodeLength                  | Length of the short code for the series.                         |
| randomCodeLength                 | Length of the random code for the series.                        |
| fixedExpiryDate                  | Fixed expiry date for the series.                                |
| numTotal                         | Total number of series.                                          |
| latestIssualTime                 | Latest time the series was issued.                               |
| latestRedemptionTime             | Latest time the series was redeemed.                             |
| resendMessageEnabled             | Indicates if resend message is enabled.                          |
| seriesType                       | Type of series.                                                  |
| clientHandlingType               | Type of client handling.                                         |
| expiryStrategyType               | Type of expiry strategy.                                         |
| discountOn                       | The kind of discount applied on.                                 |
| discountType                     | Type of discount.                                                |
| updateProductData                | Indicates if product data should be updated.                     |
| externalIssual                   | Indicates if the series is externally issued.                    |
| warnings                         | Any warnings associated with the series.                         |
