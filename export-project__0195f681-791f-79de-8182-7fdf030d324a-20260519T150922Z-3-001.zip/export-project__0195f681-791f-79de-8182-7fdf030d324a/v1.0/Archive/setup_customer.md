---
title: "Setup Customer"
slug: "setup_customer"
excerpt: ""
hidden: true
createdAt: "Mon Jun 20 2022 06:07:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jan 16 2025 13:00:58 GMT+0000 (Coordinated Universal Time)"
---
# Customer Registration Configuration

This article covers all settings related to customer registration and profile update.

To configure customer registration, follow these steps.

1. On the InTouch home page, navigate to **Profile > Organization Settings > Miscellaneous > Registration Configuration**.
2. Configure the required fields based on the description provided in the following table.

[block:parameters]
{
  "data": {
    "h-0": "OPTION",
    "h-1": "DESCRIPTION",
    "0-0": "CONF_REGISTRATION_PRIMARY_KEY",
    "0-1": "Choose the primary identifier of the customer. This is the unique identifier of the customer required for registration.",
    "1-0": "CONF_ALLOW_REGISTRATION_FROM_ANY_IDENTIFIERS",
    "1-1": "Select this to allow the registration of customers using any of the identifiers.",
    "2-0": "CONF_USERS_IS_EMAIL_REQUIRED",
    "2-1": "Check this if email id is a mandatory parameter to register a customer.",
    "3-0": "CONF_USERS_IS_EMAIL_UNIQUE",
    "3-1": "Check this to make the email ID a unique identifier. If any registered email ID is registered the accounts will be merged automatically.",
    "4-0": "CONF_USERS_USE_EXTERNAL_ID",
    "4-1": "Check this to capture the external ID of customers while registering.",
    "5-0": "CONF_USERS_IS_EXTERNAL_ID_REQUIRED",
    "5-1": "Check this to make the external ID mandatory to register a customer. Not applicable if the external ID is the primary identifier.",
    "6-0": "CONF_USERS_IS_MOBILE_REQUIRED",
    "6-1": "Check this to make the mobile number mandatory to register a customer. Not applicable if mobile is the primary identifier.",
    "7-0": "CONF_ALLOW_MOBILE_UPDATE",
    "7-1": "Check this to allow updating registered mobile numbers of customers.",
    "8-0": "CONF_ALLOW_EMAIL_UPDATE",
    "8-1": "Check this to allow updating registered email IDs of customers.",
    "9-0": "CONF_LOYALTY_ALLOW_EXTERNAL_ID_UPDATE",
    "9-1": "Check this to allow updating registered external IDs of customers.",
    "10-0": "CONF_PRIMARY_IDENTIFIER_STRICT_CHECK",
    "10-1": "Check this to verify if the primary identifier is already registered in a different account.  \nAn error message will be displayed that the secondary identifier match is found in a different account but not the primary identifier.",
    "11-0": "CONF_SKIP_SECONDARY_ID_ON_PRIMARY_MISMATCH",
    "11-1": "Check this to skip account merging if only secondary identifiers match but primary identifiers are different.  \nA new customer will be created with the provided primary identifier. The secondary identifier will be ignored automatically.",
    "12-0": "USE_CRM_REGISTRATION_INFO_FROM_BASE_STORE",
    "12-1": "NA",
    "13-0": "CONF_GIFT_CARD_ENABLED",
    "13-1": "Check this to enable gift card",
    "14-0": "CONF_ORG_CURRENCY_CODE",
    "14-1": "Set the ISO currency code of the org.",
    "15-0": "CONF_ORG_CURRENCY_SYMBOL",
    "15-1": "Set the currency symbol of the org as per the currency code.",
    "16-0": "CONF_MIN_REGISTRATION_DATE",
    "16-1": "Set the minimum date and time from which the registration is valid. Registration fails if the registration date and time is prior to the value set herein ( especially through API or Data Import).",
    "17-0": "SERVER_VALIDATION_PIN_SMS",
    "17-1": "Configure the verification SMS that will be sent to customers to validate the registered mobile numbers. Use the tag {{pin}} to insert the verification PIN in the message.  \nFor example, Please use the code {{pin}} to verify your mobile number.",
    "18-0": "SERVER_VALIDATION_PIN_EMAIL",
    "18-1": "Configure the verification email that will be sent to customers to validate the registered email ID. Use the tag {{pin}} to insert the verification PIN in the message.  \nFor example, Please use the code {{pin}} to verify your email ID.",
    "19-0": "CONF_LOYALTY_REGISTER_CUSTOMER_GENDER",
    "19-1": "Choose the custom field for gender from the drop-down.",
    "20-0": "CONF_LOYALTY_REGISTER_CUSTOMER_AGE",
    "20-1": "Choose the custom field for age from the drop-down.",
    "21-0": "CONF_CLIENT_V2_API_ENABLED",
    "21-1": "Check this if sources other than InStore are supported for the org.",
    "22-0": "CONF_GEN_CARD_NUMBER_AS_EXTERNAL_ID_ENABLED",
    "22-1": "Check this to enable generating external IDs automatically from the Capillary end.",
    "23-0": "SOURCE_ACCOUNTS_EXTERNALID_ENABLED",
    "23-1": "Check this to enable support for external ID capture.",
    "24-0": "CONF_CARD_NUMBER_GENERATION_ENABLED",
    "24-1": "Check this to enable generating card numbers automatically from the Capillary end.",
    "25-0": "CONF_CARD_NUMBER_SUFFIX",
    "25-1": "Specify the suffix you want to have for the external card (supports alphanumeric value).",
    "26-0": "CONF_CARD_NUMBER_PREFIX",
    "26-1": "Specify the prefix for the external card (supports alphanumeric value). For example, BRAND20.",
    "27-0": "CONF_CARD_NUMBER_LENGTH",
    "27-1": "Specify the length of the external card. You can have up to 50 characters.",
    "28-0": "CONF_CARD_NUMBER_OFFSET",
    "28-1": "Specify the card sequence numbers that you want to ignore from the top. For example, if you set 10, the first 10 cards will be considered invalid.",
    "29-0": "",
    "29-1": "Check this to enable primary identifier checks when registering or updating customers.",
    "30-0": "CONF_IDENTIFIERS_SYNC_ENABLED",
    "30-1": "Check this to synchronize identifiers such as mobile numbers, email addresses, and external IDs between Instore profiles and V2 profiles (external profiles such as WebEngage)  within the system.  \n**-**  When the identifier change request is made from Membercare, any changes to identifiers (mobile/email, externalId) will update both the Instore profile and the corresponding V2 profile identifiers.  \n**Note: **The Customer Unique Identifier (CUID) will not change in V2 profiles if this identifier exists.  \n**- ** To make changes to the external profile CUID, the following steps are performed after the identifier change request on Membercare:  \n  \n- \\-Creation of a new payload with updated identifiers and pushing it to an S3 bucket.  \n  --Execution of` v2/integrations/customer/upsert API` with the source set to `WEB_ENGAGE `and the new payload.  The upsert API ensures that the changes are reflected in all instances of the profile, including updating the CUID and communication channels.  \n  **Default value: **False.",
    "31-0": "\\-CONF_CLIENT_DEFAULT_COUNTRYCODE_PASSED",
    "31-1": "Check this to auto select country code to the mobile number entered on the registration screen. The validation sequence will be as follows.  \nvalidates initial letters of mobile numbers for base or supported currency codes.  \ninserts each country code and validates the number. First with base country code, followed by supported country codes."
  },
  "cols": 2,
  "rows": 32,
  "align": [
    "left",
    "left"
  ]
}
[/block]


# External ID configuration

You can use the below configurations to enable the generation of a customised external ID for the customers. Once this configuration is enabled, the external ID in the customer add API payload will be replaced with the generated external ID.

> ❗️ Attention
> 
> There is no UI to enable this configuration. You need to raise a JIRA ticket ([sample ticket](https://capillarytech.atlassian.net/browse/CAP-97635)) to the sustenance team to enable these configurations. Turn around time is five days.

[block:parameters]
{
  "data": {
    "h-0": "Configuration & Description",
    "h-1": "Value",
    "0-0": "CONF_CARD_NUMBER_GENERATION_ENABLED (Mandatory)  \nEnables external ID number generation. ",
    "0-1": "0 - Disable  \n1 - Enable",
    "1-0": "SOURCE_ACCOUNTS_EXTERNALID_ENABLED (Mandatory)  \nEnables external ID generation only for the defined source account in the Customer ADD API.",
    "1-1": "[\"INSTORE:\"] -  Instore  \n  \n[\"web_engage:1234\"] -  \n Webengage where 1234 is the account id  \n  \n[\"INSTORE:\", \"web_engage:1234\"]  -  Both Instore and webengage where 1234 is account id.",
    "2-0": "CONF_CARD_CHECKSUM_DIGIT_ALGO (Mandatory)  \nDefines the algorithm to generate the checksum. The checksum is added as the last digit of the external ID.",
    "2-1": "LUHN_ALGO, MOD7_ALGO, AUTO_INC",
    "3-0": "CONF_CARD_NUMBER_LENGTH (Mandatory)  \nDefines the external ID length. This is the total length of the external id including prefix, suffix, and checksum.  \nNote: Suffix is not applicable for MOD7 and LUHN_ALGO (MOD10) algorithms.  \nExample: If card number length = 12, Prefix = 1234, Suffix = 3401, Offset = 3000, and algorithm = AUTO_INC, then card number can be 123430003401.",
    "3-1": "Integers ranging from 1-50. ",
    "4-0": "CONF_CARD_NUMBER_OFFSET (Optional)  \nDefines the offset value for the external ID. For example for a card number series with offset value 3000, can be 111200000030004, 111200000030015 etc.",
    "4-1": "Any integer value",
    "5-0": "CONF_CARD_NUMBER_PREFIX  (Optional)  \nDefines the prefix for the external ID number.",
    "5-1": "Any integer value but prefix + suffix + system-generated number should not be more than 50.",
    "6-0": "CONF_CARD_NUMBER_SUFFIX  (Optional)  \nDefines the SUFFIX for the external ID number. This is only applicable for AUTO_INC alogrithm. ",
    "6-1": "Any integer value but prefix + suffix + system-generated number should not be more than 50.",
    "7-0": "CONF_VALUES_TO_INCLUDE_FOR_CHECKSUM_DIGIT  (Optional)  \nSpecifies whether the prefix should be considered when generating the checksum value.",
    "7-1": "PREFIX - Prefix is considered  \nNONE - Prefix is not considered"
  },
  "cols": 2,
  "rows": 8,
  "align": [
    "left",
    "left"
  ]
}
[/block]


# Customer ingestion restriction configuration

> ❗️ There is no UI to enable this configuration. You need to raise a JIRA ticket ([sample ticket](https://capillarytech.atlassian.net/browse/CAP-97635)) to the sustenance team to enable these configurations. Turn around time is five days.

`CONF_RESTRICT_ORPHAN_V2_PROFILE` - This configuration prevents the ingestion of a WebEngage profile into the Capillary platform for a specific customer if they do not already have an existing Instore profile.

# Managing customer lifecycle with customer status

A customer status defines the relationship between a brand and a customer. For example, a customer who interacts often with the brand can be defined as an active customer. Further, these statuses can be used to run the loyalty program and assign coupons, reward points etc accordingly. For example, more offers can be offered to a customer to make an inactive customer to active customer..

## Activating customer status

To activate customer status for your organisation, navigate to **Organisation settings> Miscellaneous> Customer Status configuration** and select the  **Enable customer status** check box.

On enabling the customer status, the existing fraud status will be replaced by the customer status function. 

## Types of customer statuses

The various customer statuses available in the Capillary platform that you can configure are:

1. Active
2. Suspended
3. Deleted
4. Fraud suspected
5. Fraud confirmed
6. Internal
7. Pending deletion

## Creating a custom label

You can click the **Create new label** option in the customer label and enter a new label name to assign a custom name for the status. You can add multiple labels if required. The first status label that you create is set as the default status value.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e70b5ed-H3fEa_kClhg1C9buCL58znQ3t4tvnHcb2g.png",
        "H3fEa_kClhg1C9buCL58znQ3t4tvnHcb2g.png",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Active customer status

The active status can be used to indicate that the customer is active. 

> 📘 NOTES:
> 
> - There are no restrictions for customers with Active status.
> - All customers are marked Active by default.

## Suspended, Fraud suspected, Fraud confirmed, and Internal customer status

You can restrict the following operations for the users with Suspended, Fraud suspected, Fraud confirmed or Internal status.

[block:parameters]
{
  "data": {
    "h-0": "Restriction",
    "h-1": "Description",
    "0-0": "Block coupons redemption",
    "0-1": "Restrict from redeeming coupons.",
    "1-0": "Block issual of loyalty promotions",
    "1-1": "Restrict from receiving points.",
    "2-0": "Block identifier change and account merge",
    "2-1": "Restrict from account merging and identifier change requests.",
    "3-0": "Block issual of badges",
    "3-1": "This is a future development feature.",
    "4-0": "Block issual of coupons",
    "4-1": "Restrict from providing coupons.",
    "5-0": "Block enrollment into loyalty promotions",
    "5-1": "This is a future development feature.",
    "6-0": "Block points allocation",
    "6-1": "Restrict from providing points.  \n  \nWhen this restriction is added on any label, then the points allocation from any points-related action (like transaction point allocation, allocation points, target point allocation, issue to the referrer, issue to referee, goodwill points, import profile) will be blocked for the customer. ",
    "7-0": "Block points redemption",
    "7-1": "Restrict from redeeming points.",
    "8-0": "Block tier upgrade",
    "8-1": "Restrict from tier upgrade.",
    "9-0": "Block transaction",
    "9-1": "Restrict future transactions.",
    "10-0": "Mark transaction outlier",
    "10-1": "Mark the transactions made by the selected label(s) as outliers."
  },
  "cols": 2,
  "rows": 11,
  "align": [
    "left",
    "left"
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/26017c9-2oLSMndjRj6idYt5qgadRWypjOT0H0uy4g.png",
        "2oLSMndjRj6idYt5qgadRWypjOT0H0uy4g.png",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


To restrict access, select the individual status labels or all the created status labels from the desired restriction drop-down. Click **Select**, and then click **Update**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ccef7e2-lb5ZVDRSQL_JkADaNE0G9ONiVhqtT0GynQ.png",
        "lb5ZVDRSQL_JkADaNE0G9ONiVhqtT0GynQ.png",
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## Deleted customer status

The deleted status allows you to block every action for customers with this status. To configure restriction, from the **Block everything** drop-down, select the individual custom labels or select all labels created for Deleted. Click **Select ** and then click **Update**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a198377-Delete_customer_status.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "35% ",
      "border": true
    }
  ]
}
[/block]


## Pending deletion customer status

This status is used to indicate the status of customers for whom a deletion request is raised. For **Pending Deletion**, whenever a PII deletion request is triggered, a label Deletion_pending is automatically created and assigned to the customer, regardless of any other label that may have been created and set as default.
