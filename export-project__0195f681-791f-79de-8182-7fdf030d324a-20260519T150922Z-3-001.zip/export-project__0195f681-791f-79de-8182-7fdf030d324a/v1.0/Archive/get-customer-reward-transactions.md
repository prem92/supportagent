---
title: "Get customer reward transactions"
slug: "get-customer-reward-transactions"
excerpt: ""
hidden: true
createdAt: "Tue May 07 2024 04:33:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 21 2024 05:42:08 GMT+0000 (Coordinated Universal Time)"
---
This API allows you to retrieve all reward transactions of a customer.

<br />

Example: If a reward is issued to a customer and they make a transaction using that reward, you can use this API to retrieve all transactions where the customer has used the reward.

> 👍 Note
> 
> - For detailed information about our APIs and for hands-on testing, refer documentation in [API overview](https://docs.capillarytech.com/reference/apioverview) and  step-by-step guide on making your first API call in [Make your first API call](https://docs.capillarytech.com/reference/make-your-first-api-call) .

# Prerequisites

- [ ] Authentication: Basic authentication 
- [ ] Default access group

# Resource information

|                        |                                                                      |
| :--------------------- | :------------------------------------------------------------------- |
| URI                    | api_gateway/rewards/core/v1/management/customer/{customerId}/issuals |
| HTTP Method            | GET                                                                  |
| Pagination             | Yes                                                                  |
| Batch support          | No                                                                   |
| Rate limit information | None                                                                 |

# API endpoint example

`https://crm-nightly-new.cc.capillarytech.com/api_gateway/rewards/core/v1/management/customer/383428154/issuals`

# Request path parameters

| Parameter    | Data type | Description                |
| :----------- | :-------- | :------------------------- |
| customerId\* | Integer   | Unique ID of the customer. |

```curl
https://crm-nightly-new.cc.capillarytech.com/api_gateway/rewards/core/v1/management/customer/383428154/issuals
```

# Response parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Datatype",
    "h-2": "Description",
    "0-0": "success",
    "0-1": "Boolean",
    "0-2": "Indicates whether the specific API call was successful.",
    "1-0": "code",
    "1-1": "Integer",
    "1-2": "The status code related to the specific part of the transaction.",
    "2-0": "message",
    "2-1": "String",
    "2-2": "A descriptive message regarding the status of the transaction.",
    "3-0": "rewardTransactionId",
    "3-1": "String",
    "3-2": "Unique identifier for the reward transaction.",
    "4-0": "rewardIssueRefId",
    "4-1": "String",
    "4-2": "Reference identifier for the reward issue transaction.",
    "5-0": "rewardTransactionDate",
    "5-1": "Long",
    "5-2": "Timestamp indicating when the transaction took place.",
    "6-0": "success",
    "6-1": "Boolean",
    "6-2": "Indicates the success of the reward transaction specifically.",
    "7-0": "code",
    "7-1": "Integer",
    "7-2": "Status code associated with the reward transaction.",
    "8-0": "message",
    "8-1": "String",
    "8-2": "Description of the reward transaction status.",
    "9-0": "rewardId",
    "9-1": "Integer",
    "9-2": "Unique identifier of the reward.",
    "10-0": "languageCode",
    "10-1": "String",
    "10-2": "Language code for the reward details.",
    "11-0": "name",
    "11-1": "String",
    "11-2": "The name of the reward.",
    "12-0": "description",
    "12-1": "String",
    "12-2": "Description of the reward.",
    "13-0": "termNConditionsId",
    "13-1": "String",
    "13-2": "ID for the terms and conditions associated with the reward",
    "14-0": "termNConditionsUrl",
    "14-1": "String",
    "14-2": "URL to the terms and conditions document",
    "15-0": "imageId",
    "15-1": "String",
    "15-2": "Identifier for the reward's image.",
    "16-0": "imageUrl",
    "16-1": "String",
    "16-2": "URL of the reward's image.",
    "17-0": "enabled",
    "17-1": "Boolean",
    "17-2": "Boolean flag to indicate if the reward is enabled or not.",
    "18-0": "success",
    "18-1": "Boolean",
    "18-2": "Indicates if the points redemption was successful.",
    "19-0": "code",
    "19-1": "Integer",
    "19-2": "Status code related to the points redemption.",
    "20-0": "message",
    "20-1": "String",
    "20-2": "Description of the points redemption status.",
    "21-0": "ownerType",
    "21-1": "Enum",
    "21-2": "The module claimed by the badge.  \nSupported values: Loyalty program, Milestones, Campaigns, Journeys, Goodwill.",
    "22-0": "ownerId",
    "22-1": "String",
    "22-2": "Identifier of the owner of the transaction, here shown as an empty string."
  },
  "cols": 3,
  "rows": 23,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


```json
{
    "status": {
        "success": true,
        "code": 200,
        "message": "Reward issue transactions fetched successfully"
    },
    "rewardIssueTransactions": [
        {
            "rewardTransactionId": "91893",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714642058000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 63307,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91892",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714642042000,
            "status": {
                "success": false,
                "code": 8004,
                "message": "fail to issue reward as  points are not redeemable"
            },
            "rewardDetails": {
                "rewardId": 63307,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91891",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714641969000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 63307,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91890",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714641755000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 63306,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91889",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714641749000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 63306,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91888",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714641728000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 63306,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91887",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714640471000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91821",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714639214000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91820",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714638343000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91520",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714587653000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91519",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714585472000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91518",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714585295000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91517",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714585211000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91516",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714585036000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91515",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584875000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62781,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91514",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584633000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62780,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91513",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584382000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62779,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91512",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584193000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62778,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91511",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584176000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62778,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91510",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584169000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62778,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91509",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584058000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62777,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91508",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714584017000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62777,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91507",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714583961000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62777,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91506",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714583889000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62777,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91505",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714583560000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 62773,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "91504",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714583551000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 62773,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "90170",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1714374713000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 61345,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86201",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713251364000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 57441,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86200",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713251256000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 57441,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86197",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713251201000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 57441,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86190",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713250989000,
            "status": {
                "success": false,
                "code": 8004,
                "message": "fail to issue reward as  points are not redeemable"
            },
            "rewardDetails": {
                "rewardId": 57378,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86138",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713248110000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 57378,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86136",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713248072000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 57378,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86127",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713246188000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 57365,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86126",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713246080000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 57365,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "86125",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1713246046000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 57365,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84806",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712796346000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 56037,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84644",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712747190000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 55860,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84641",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712747141000,
            "status": {
                "success": false,
                "code": 12016,
                "message": "Invalid payment mode passed."
            },
            "rewardDetails": {
                "rewardId": 55860,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84630",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712744014000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 55837,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84563",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712738457000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 55771,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84534",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712734415000,
            "status": {
                "success": true,
                "code": 200,
                "message": "Reward issued successfully"
            },
            "rewardDetails": {
                "rewardId": 55724,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84530",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712734211000,
            "status": {
                "success": false,
                "code": 12005,
                "message": "Reward constraint evaluation failed. Request failed. Max limit for the DAYS is reached. Allowed limit is 5 For Level CUSTOMER_REDEMPTION_TYPE"
            },
            "rewardDetails": {
                "rewardId": 55724,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        },
        {
            "rewardTransactionId": "84525",
            "rewardIssueRefId": "2344s4",
            "rewardTransactionDate": 1712733897000,
            "status": {
                "success": false,
                "code": 12005,
                "message": "Reward constraint evaluation failed. Request failed. Max limit for the DAYS is reached. Allowed limit is 5 For Level CUSTOMER_REDEMPTION_TYPE"
            },
            "rewardDetails": {
                "rewardId": 55724,
                "languageCode": "en",
                "name": " INTOUCH Enabled",
                "description": "Description",
                "termNConditionsId": "EXDR12987R",
                "termNConditionsUrl": null,
                "imageId": "EXDR12987U",
                "imageUrl": null,
                "thumbnailId": "EXDR12987T",
                "thumbnailUrl": null,
                "enabled": true
            },
            "ownerType": null,
            "ownerId": ""
        }
    ],
    "pagingDto": {
        "last": true,
        "totalElements": 44,
        "totalPages": 1,
        "numberOfElements": 44,
        "first": true,
        "size": 100,
        "number": 0
    }
}
```
