---
title: "Add Customer"
slug: "add_customer"
excerpt: "Lets you register customers in the org’s loyalty program or just register their identifiers across sources such as InStore, Facebook,Webengage, WeChat, Martjack, TMall, Taobao, JD, ecommerce, Line, Website, and Mobile app. You can also add customer-level extended and custom field details.\n\nYou can also issue loyalty card to the customer using this API."
hidden: true
createdAt: "Thu Dec 16 2021 07:30:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 24 2024 13:04:51 GMT+0000 (Coordinated Universal Time)"
---
The API functions as follows -

- If you try registering an identifier that exists in a different source, a new source account is added to the existing account. Details of each source account will be maintained separately.

- In a source account, identifiers should be unique - no two customers can have a same identifier.

- You cannot update existing customer details with this API. To update customer details, use customer update API; and to update identifiers, use the Update Identifier API.

#### Rate Limit

| Region               | Default Limit (RPM) |
| :------------------- | :------------------ |
| Asia-2 (Singapore)   | 100                 |
| Asia-1 (N. Virginia) | 600                 |
| EMEA (Ireland)       | 100                 |

### Prerequisites

Following are the prerequisites to use customer registration API:

- Different sources (FACEBOOK, WEB_ENGAGE, WECHAT, INSTORE, MARTJACK, TMALL, TAOBAO, JD, ECOMMERCE, WEBSITE, LINE) supported by your organization

- Account ids in which you want to register customers(for sources with multiple accounts such as WeChat, Line and Facebook) 

> 📘 Extended Fields are proposed fields used to standardize input values and keys across organizations (unlike custom fields that have no control in input values). Platforms back-end team controls the field names, data-types, enum values, and scopes of extended fields. Extended Fields are created at customer level, transaction level, and transaction line-item level. Examples of customer level extended fields are age_group, preferred_store, gender, and nationality. Extended fields are either associated to verticals or to a generic category (available for all orgs). To know the list of extended fields enabled for an org, use GET v2/extendedFields API.

## Request Body Parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "loyaltyType",
    "0-1": "enum",
    "0-2": "Loyalty status of the customer.  \nValue: `loyalty`, `non_loyalty` .",
    "1-0": "profiles",
    "1-1": "list",
    "1-2": "Meta information of the customer",
    "2-0": "   Firstname",
    "2-1": "string",
    "2-2": "First Name of the customer",
    "3-0": "   Lastname",
    "3-1": "string",
    "3-2": "Last name of the customer",
    "4-0": "   identifiers",
    "4-1": "list obj",
    "4-2": "identifiers of the customer in type and value.",
    "5-0": "      type",
    "5-1": "enum",
    "5-2": "Type of the customer identifier.  \nValues: `mobile`, `email`, `externalId`, `wechat`, `martjackId`, `fbId mobile`, `tmall_uname`, `cuid`, `ali_uname`, `jd_uname`, `vip_uname`, `mobilePush`, and `line`, and `card` (to issue loyalty card to the customers through registration).",
    "6-0": "      value",
    "6-1": "string",
    "6-2": "Value of the specified identifier. For the `type` card, `value` is the card number.  \n**Note:** For the mobile numbers, enter the mobile number with the country code",
    "7-0": "   source",
    "7-1": "enum",
    "7-2": "Source in which you want to register a customer.  \nValue: `FACEBOOK`, `WEB_ENGAGE`, `WECHAT`, `INSTORE`, `MARTJACK`, `TMALL`, `TAOBAO`, `JD`, `ECOMMERCE`, `WEBSITE`, `LINE`, `MOBILE_APP`.  \nYou can add customers on different sources.",
    "8-0": "   accountId",
    "8-1": "string",
    "8-2": "For sources that support multiple accounts, For example, FACEBOOK, WEB_ENGAGE, WECHAT, MOBILE_APP.",
    "9-0": "   fields",
    "9-1": "obj",
    "9-2": "Customer or card level custom field details in key-value pairs.",
    "10-0": "activity",
    "10-1": "enum",
    "10-2": "State of the customer's lifecycle (entirety lifecycle). State is auto assigned according to the activity.",
    "11-0": "      seriesId",
    "11-1": "int",
    "11-2": "Card series ID (for card series generated in capillary).  Required for the identifier type: `card`.",
    "12-0": "      seriesCode",
    "12-1": "string",
    "12-2": "Unique series code (for external card series).  \nApplicable for the identifier type: `card`.",
    "13-0": "      statusLabel",
    "13-1": "string",
    "13-2": "User defined card status.  \nRequired for the identifier type: `card`.",
    "14-0": "   commChannels",
    "14-1": "obj",
    "14-2": "Available communication channels of the customer.  \nValue: `mobile`, `email`, `wechat`, `ios`, `android`, `line`, `mobilePush`.",
    "15-0": "      primary",
    "15-1": "boolean",
    "15-2": "Pass `true` if it is the primary identifier of the org (for registration).",
    "16-0": "      verified",
    "16-1": "boolean",
    "16-2": "Pass `true` if the identifier is verified.",
    "17-0": "      subscribed",
    "17-1": "boolean",
    "17-2": "Pass `true` if the identifier is subscribed for the org's newsletters (bulk messages).",
    "18-0": "      meta",
    "18-1": "obj",
    "18-2": "Additional details of the identifier.",
    "19-0": "         lastViewedDate",
    "19-1": "Date",
    "19-2": "Date when the customer last opened the app.  \nApplicable for channel `mobilePush`.",
    "20-0": "      attributes",
    "20-1": "obj",
    "20-2": "Additional Details of the identifier.",
    "21-0": "createDate",
    "21-1": "date-time",
    "21-2": "Create date indicates the time at which the customer enrolled or was registered in the system. ",
    "22-0": "associatedWith",
    "22-1": "string",
    "22-2": "The TILL code associated with the customer registration",
    "23-0": "extendedFields",
    "23-1": "obj",
    "23-2": "Customer or card level extended field details in key value pairs. You can only pass extended fields that are enabled for your org with the respective datatype values.",
    "24-0": "loyaltyProgramEnrollments",
    "24-1": "obj",
    "24-2": "Lets you enroll new customers in the loyalty program.",
    "25-0": "   programId",
    "25-1": "int",
    "25-2": "Unique ID of the loyalty program in which you want to enroll.",
    "26-0": "   tierNumber",
    "26-1": "int",
    "26-2": "Sequence number of the tier that you want to allocate to the customer.  \nFor example, `1` for te lowest tier, `2` for the subsequent tier, and so on.",
    "27-0": "   loyaltyPoints",
    "27-1": "int",
    "27-2": "Loyalty Points to credit in customer's account",
    "28-0": "   tierExpiryDate",
    "28-1": "date-time",
    "28-2": "Expiry date and time of the specified tier.  \nSupported format:YYYY-MM-DDTHH:MM:SS+/-(time-zone).",
    "29-0": "   pointsExpiryDate",
    "29-1": "date-time",
    "29-2": "Expiry date and time of the points issued.  \nSupported format: YYYY-MM-DDTHH:MM:SS+/-(time-zone).",
    "30-0": "   endPointsEnabled",
    "30-1": "array",
    "30-2": "Use this to add dummy customers (for internal or testing purposes) and specify the respective endpoints.  \nValues: `REFERRAL_ENDPOINT`, `DVS_ENDPOINT`, `TIMELINE_ENDPOINT`, `POINTENGINE_ENDPOINT`."
  },
  "cols": 3,
  "rows": 31,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


> 📘 If you try to register a customer that exists in a different source, the accounts will be merged automatically.
