---
title: "Add Referrals"
slug: "add-referrals"
excerpt: "Lets you add customer referral details that contain referees, referred date, and the associated channel."
hidden: true
createdAt: "Thu Jun 02 2022 04:56:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Oct 18 2024 06:59:56 GMT+0000 (Coordinated Universal Time)"
---
