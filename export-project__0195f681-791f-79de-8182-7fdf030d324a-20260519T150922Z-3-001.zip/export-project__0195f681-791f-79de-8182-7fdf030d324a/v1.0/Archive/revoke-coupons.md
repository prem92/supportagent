---
title: "Revoke Coupons"
slug: "revoke-coupons"
excerpt: ""
hidden: true
createdAt: "Mon Jan 17 2022 12:04:30 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Oct 11 2024 10:32:29 GMT+0000 (Coordinated Universal Time)"
---
When a cashier redeems a coupon in case of an internet outage, you can expire such coupons instead of doing a manual cleanup at the backend. 

For a coupon series or offer, you have the following options for expiring coupons.

- All coupons that are not redeemed - from both issued and unissued.
- Only unissued coupons.
- All active coupons of a customer(s) 

> 📘 Notes
> 
> - You cannot revoke redeemed coupons.
> - If a customer has multiple active coupons from the same series, then all active coupons are revoked.

To expire active coupons, follow these steps. 

1. On the Engage+ home page, click **Incentives**.
2. Navigate to the incentive that you want to revoke, hover the pointer over the more options (…) symbol.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e269553-VISipjjmBaIuU4oNxIQW9iQ1BPndD7VhJA.png",
        "VISipjjmBaIuU4oNxIQW9iQ1BPndD7VhJA.png",
        790
      ],
      "align": "center",
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


3. Click **Revoke Coupons**.
4. Select your desired revoking option.

- **All unredeemed coupons (Issued and unissued)**: To expire all coupons that are either not redeemed or issued.
- **Only unissued coupons**: To expire only coupons that are not issued.
- **For specific customers**: To expire all active coupons of particular customers. Create a CSV file with identifiers of customers whose coupons you want to expire, and upload the file using **Upload customer**. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/38c5741-4mfLAo2j6ZpEQjJJ-FRqJ4Q5OIiMMgPJJQ.png",
        "4mfLAo2j6ZpEQjJJ-FRqJ4Q5OIiMMgPJJQ.png",
        622
      ],
      "align": "center",
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


5. Check **I understand that revoking coupons will make them unredeemable**. Expired coupons cannot be redeemed or reversed.
6. Click **Revoke**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3b590bf-veLCjalxsZz6_FTANXWdiebAkWvQ9weEig.png",
        "veLCjalxsZz6_FTANXWdiebAkWvQ9weEig.png",
        465
      ],
      "align": "center",
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


> 📘 - A message is shown that the customer data is successfully uploaded. All the coupons issued to the selected customer are revoked and ready for use.

> 📘 Transfer of Coupon
> 
> You can revoke the coupon and then assign the same coupon code to the intended customer through coupon upload, as transferring a coupon from one customer to another customer is not supported.
