---
title: "Behavioral Events"
slug: "behavioral-events-status-code"
excerpt: "Behavioral events help capture customer activities such as registration, forgot password, and cart abandonment. \n\nThere are standard events that are predefined with name, id, and attributes. \n\nThe events resource lets you create custom events and Webhook account, enable standard events for an org, and map event fields."
hidden: true
createdAt: "Mon Jul 29 2024 05:20:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jul 29 2024 06:43:42 GMT+0000 (Coordinated Universal Time)"
---
**Note**: Behavioral events ingestion is asynchronous and you won't receive an immediate response. When you send data to a webhook, it acknowledges and places the data in a queue for processing, unlike synchronous APIs. To check the status of your events after ingestion, use the [Get Events Log](https://docs.capillarytech.com/reference/get-events-logs) API or the [Search Events](https://docs.capillarytech.com/reference/search-events) API.

## Status Codes

### Success Codes

| Code | Description             |
| ---- | ----------------------- |
| 7300 | Feed added successfully |

### Error Codes

| Code | Description                                             |
| ---- | ------------------------------------------------------- |
| 7301 | Unable to add feed.                                     |
| 7302 | Source is not specified.                                |
| 7303 | Invalid source passed.                                  |
| 7304 | Event is not passed.                                    |
| 7305 | Invalid event passed.                                   |
| 7306 | UUID is not passed.                                     |
| 7307 | Customer ID is not passed.                              |
| 7308 | Invalid customer ID passed.                             |
| 7309 | Invalid SKU passed.                                     |
| 7310 | Invalid store code passed.                              |
| 7311 | Invalid customer details passed. <br>Scan event failed. |
