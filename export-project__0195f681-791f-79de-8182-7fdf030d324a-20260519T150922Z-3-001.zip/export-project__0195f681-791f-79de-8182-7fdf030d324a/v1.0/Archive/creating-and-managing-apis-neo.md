---
title: "Creating and Customising APIs"
slug: "creating-and-managing-apis-neo"
excerpt: ""
hidden: true
createdAt: "Wed Aug 07 2024 10:02:21 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Sep 26 2024 06:57:52 GMT+0000 (Coordinated Universal Time)"
---
The Neo extension is a tool for creating and managing APIs with minimal coding effort. It allows you to perform necessary validations, transformations, and request creation using predefined blocks and executors.

This functionality enables easy creation of new APIs and customisation of existing ones, to meet brand-specific needs without requiring new API versions.

# Create new APIs

You can use the Neo extension to create new APIs with minimal coding. When creating an API, you perform validations, transform data, construct the API request, and validate the API response. The Neo extension simplifies this process using predefined blocks or executors in Neo.  
Neo extension comes in handy when there is a brand-specific requirement to provide additional data over the existing information. You must meet the requirement without affecting other brands using the existing APIs. Creating a new API version is not an option because the requirement is brand-specific.  
Neo extension allows you to create an API response using multiple existing APIs, ensuring the new requirements are met without disrupting others.

# Customise existing APIs

You can enhance the existing APIs to provide more functionalities. Neo extension acts as mini-programs that hook into the core platform's API to modify or extend its functionalities. It also enables seamless communication and data exchange between software platforms. It allows developers to leverage the capabilities of third-party services or integrate with external systems without needing to build everything from scratch.
