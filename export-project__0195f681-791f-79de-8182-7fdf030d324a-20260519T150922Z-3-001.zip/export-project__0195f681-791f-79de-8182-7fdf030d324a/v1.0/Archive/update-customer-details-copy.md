---
title: "Update Customer Details"
slug: "update-customer-details-copy"
excerpt: "Lets you update existing customer details."
hidden: true
createdAt: "Tue Jun 04 2024 12:30:37 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 04:40:48 GMT+0000 (Coordinated Universal Time)"
---
You can update profile information, extended field values, communication details, custom field values, extended field values, and loyalty status (only non loyalty to loyalty) on any source such as `FACEBOOK`, `WEB_ENGAGE`, `WECHAT`, `INSTORE`, `MARTJACK`, `TMALL`, `TAOBAO`, `JD`, `ECOMMERCE`, and `WEBSITE`.

Limitations of the customer update API - 

- Cannot update identifiers with this API
- Cannot modify source type
- Cannot change a loyalty customer to non-loyalty but can change a non-loyalty customer to a loyalty

# Prerequisites

The following are the prerequisites for updating customer details - 

- Unique customer id of the respective customer
- Source in which you want to modify the details
- Account id of the specific source in which you want to modify the customer details 

# Resource information

|                       |                        |
| :-------------------- | :--------------------- |
| URI                   | /v2/promotion/customer |
| HTTP method           | PUT                    |
| Pagination supported? | NA                     |
| Rate limit            | NA                     |
| Batch support         | NA                     |

# API endpoint example

\`<https://eu.api.capillarytech.com/v2/customers/{userId}?{query_parameters}>

# Request path parameters

| Parameter | Type   | Description                                                 |
| :-------- | :----- | :---------------------------------------------------------- |
| userId\*  | string | Unique ID of the customer whose details need to be updated. |

# Request query parameters

| Parameter | Type    | Description                                                                                                                                                                                                       |
| :-------- | :------ | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| source\*  | enum    | Specify the source in which you want to update the customer details - FACEBOOK, WEB_ENGAGE, WECHAT, INSTORE, MARTJACK, TMALL, TAOBAO, JD, ECOMMERCE, WEBSITE, LINE, MOBILE_APP. For sources with multiple account |
| accountId | string  | Account in which you want to update the customer details. (Required only for sources with multiple accounts).                                                                                                     |
| use_async | boolean | Pass `true` to run loyalty activities in the background. Hence, sideEffects are not returned in the response.  Pass `false` to wait for loyalty activities to complete and return the side effects.               |

# Request body parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Data Type",
    "h-2": "Description",
    "0-0": "profiles",
    "0-1": "Object",
    "0-2": "Meta information of the customer",
    "1-0": "- firstName",
    "1-1": "String",
    "1-2": "First Name of the customer.",
    "2-0": "- lastName",
    "2-1": "String",
    "2-2": "Last Name of the customer.",
    "3-0": "- fields",
    "3-1": "Object",
    "3-2": "Associated custom fields.",
    "4-0": "\\-- gender",
    "4-1": "String",
    "4-2": "Gender of the customer.",
    "5-0": "\\-- city",
    "5-1": "String",
    "5-2": "Customer's city of residence. ",
    "6-0": "- commChannels",
    "6-1": "Object",
    "6-2": "Communication channels of the customer.",
    "7-0": "\\-- type",
    "7-1": "String",
    "7-2": "Type of the communication channel.  \nValue: `mobile`, `email`, `wechat`, `ios`, `android`, `line`, `mobilePush`.",
    "8-0": "\\-- value",
    "8-1": "String",
    "8-2": "Based on the channel `type` enter the channel value. For example, mobile number is the value for mobile. **Note:** For mobile numbers, add the mobile number with the country code.",
    "9-0": "\\-- primary",
    "9-1": "String",
    "9-2": "Whether the current identifier of the customer (primary identifier as per the org's configuration).",
    "10-0": "\\-- verified",
    "10-1": "String",
    "10-2": "Whether the current identifier is the primary identifier or not. For example, through OTP.",
    "11-0": "\\-- meta",
    "11-1": "Object",
    "11-2": "Additional details of the identifier.",
    "12-0": "loyaltyInfo",
    "12-1": "Object",
    "12-2": "Object containing the loyalty information of the customer.",
    "13-0": "- loyaltyType",
    "13-1": "String",
    "13-2": "Loyalty status of the customer.  \nValue: `loyalty`, `non_loyalty`.",
    "14-0": "extendedFields",
    "14-1": "Object",
    "14-2": "Extended field details of the customer in key:value pairs. You can only pass extended fields that are enabled for your org with the respective datatypes value.",
    "15-0": "- gender",
    "15-1": "String",
    "15-2": "Gender of the customer.",
    "16-0": "- city",
    "16-1": "String",
    "16-2": "Customer's city of residence.",
    "17-0": "loyaltyProgramEnrollments",
    "17-1": "Object",
    "17-2": "Lets you enroll customers into loyalty programs.",
    "18-0": "- programId",
    "18-1": "Integer",
    "18-2": "Unique ID of the loyalty program in which you want to enrol. You cannot update if the customer is already enrolled in the loyalty program.",
    "19-0": "- tierNumber",
    "19-1": "Integer",
    "19-2": "Sequence number of the tier that you want to allocate to the customer. For example, `1` for the lower tier, and `2` for the next tier, and so on.",
    "20-0": "- loyaltyPoints",
    "20-1": "Integer",
    "20-2": "Loyalty points to credit in customer's account.",
    "21-0": "- tierExpiryDate",
    "21-1": "String",
    "21-2": "Expiry date and time of the specified tier. Supported format:  \nYYYY-MM-DDTHH:MM:SS +/- (timezone).",
    "22-0": "- pointsExpiryDate",
    "22-1": "String",
    "22-2": "Expiry date and time of the points issued. Supported format:  \nYYYY-MM-DDTHH:MM:SS +/- (timezone)."
  },
  "cols": 3,
  "rows": 23,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


<br />

```
curl --location --request PUT 'https://eu.api.capillarytech.com/v2/customers/171891944?source=INSTORE&use_async=false' \
--header 'Content-Type: application/json' \
--header 'Authorization: Basic dGVzdiNmY2OWZmZmRkYg==' \
--data-raw '{
    "profiles": [
        {
            "firstName": "Tom",
            "lastName": "Sawyer",
            "fields": {
                "gender": "Male",
                "city": "Bangalore"
            },
            "commChannels": [
            {
                "type": "mobile",
                "value": "9999000000",
                "primary": "true",
                "verified": "true",
                "meta": {
            "residence": "true"
          }
        },
        {
          "type": "email",
          "value": "tomsawyer@gmail.com",
          "primary": "true",
          "verified": "true",
          "meta": {
            "residence": "true"
          }
        }
      ]
        }
    ],
    
    "loyaltyInfo": {
        "loyaltyType": "loyalty"
    },
    "extendedFields": {
        "gender": "MALE",
        "city": "Bangalore"
    },
    "loyaltyProgramEnrollments": [
    {
      "programId": 699,
      "tierNumber": 1,
      "loyaltyPoints": 0,
      "tierExpiryDate": "2024-07-11T16:36:17+05:30",
      "pointsExpiryDate": "2024-07-11T16:36:17+05:30"
    }
  ]
}'
```

# Response parameters

| Parameter          | Datatype | Description                                          |
| ------------------ | -------- | ---------------------------------------------------- |
| createdId          | String   | Unique ID of the customer whose details are updated. |
| warnings           | Object   | Object containing the warning details, if any.       |
| sideEffects        | Object   | Object containing the information on results.        |
| - entityType       | String   | Entity affected by the API. Example: USER            |
| - rawAwardedPoints | Number   | The raw number of points awarded                     |
| - awardedPoints    | Number   | The awarded points after adjustments                 |
| - type             | String   | Effect of running the API. Example: points           |
