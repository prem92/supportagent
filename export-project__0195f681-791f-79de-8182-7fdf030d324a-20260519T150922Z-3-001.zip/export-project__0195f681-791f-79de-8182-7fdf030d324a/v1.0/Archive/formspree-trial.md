---
title: "Formspree Trial"
slug: "formspree-trial"
excerpt: ""
hidden: true
createdAt: "Mon Sep 02 2024 04:16:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Sep 11 2024 05:20:01 GMT+0000 (Coordinated Universal Time)"
---
You can use the URL `https://docs.capillarytech.com/changelog.rss`and add it to your RSS feeder to subscribe to our release notes. The below screenshot is from an RSS feeder `feeder.co` which is available as an extension on Chrome. You can find similar RSS feeders for Edge, Safari and other popular browsers.

[block:html]
{
  "html": "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <title>Document</title>\n  <style>\n    .subscribe-box {\n      max-width: 300px;\n      margin: 0 auto;\n      padding: 20px;\n      border: 2px solid #ccc;\n      border-radius: 5px;\n      text-align: center;\n      font-family: Arial, sans-serif;\n      background: linear-gradient(135deg, #f5f7fa, #c3cfe2);\n      transition: transform 0.3s ease, box-shadow 0.3s ease;\n    }\n\n    .subscribe-box:hover {\n      transform: scale(1.05);\n      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);\n    }\n\n    .subscribe-box h2 {\n      font-size: 18px;\n      margin-bottom: 15px;\n      color: #333;\n    }\n\n    .subscribe-box input,\n    .subscribe-box button {\n      width: 100%;\n      padding: 10px;\n      border-radius: 5px;\n      font-size: 14px;\n    }\n\n    .subscribe-box input {\n      margin-bottom: 15px;\n      border: 1px solid #ccc;\n    }\n\n    .subscribe-box button {\n      background-color: #4CAF50;\n      color: #fff;\n      border: none;\n      cursor: pointer;\n    }\n  </style>\n</head>\n<body>\n  <div class=\"subscribe-box\">\n    <h2>Subscribe to our release notes</h2>\n    <form action=\"https://formspree.io/f/mgvwbeyd\" method=\"POST\">\n      <label>\n        <input type=\"email\" name=\"email\" required placeholder=\"Enter your email\">\n      </label>\n      <button type=\"submit\">Subscribe</button>\n    </form>\n  </div>\n</body>\n</html>"
}
[/block]


<br />

<br />

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/58e56bb-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
