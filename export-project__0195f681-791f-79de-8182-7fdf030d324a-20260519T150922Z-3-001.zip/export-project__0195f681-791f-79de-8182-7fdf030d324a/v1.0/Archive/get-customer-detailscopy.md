---
title: "Get Customer Details (copy)"
slug: "get-customer-detailscopy"
excerpt: "Retrieves all the details of a customer. Use `embed`  and other parameters to get a specific information as per needed."
hidden: true
createdAt: "Wed Jun 01 2022 07:54:16 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 08 2024 08:47:09 GMT+0000 (Coordinated Universal Time)"
---
This API can fetch the following information - 

- profile information – first name, last name, registered date, registered at TILL
- recent profile updated – details of the recent update in profile information
- registered identifiers, communication channels
- loyalty information – loyalty status, registered date, purchases, etc.
- Multiple Loyalty Program Details: Program wise details if the org has multiple loyalty programs support
- Card level details  
- Alternate currency details with associated program ID and its name.

To fetch customer details from a specific account of a source (source with multiple accounts), you need to provide the respective account id.
