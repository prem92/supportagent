---
title: "Add Till"
slug: "add-till"
excerpt: ""
hidden: true
createdAt: "Wed Jun 05 2024 10:24:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 24 2024 14:26:33 GMT+0000 (Coordinated Universal Time)"
---
This API enables you to create a new Till for your store. 

<br />

> 👍 Note
> 
> - You can also add custom fields to a till. The till level custom fields enables brands to add additional information about the till specially when the brand has multiple tills mapped to a store. For example, till code, till name, description about till etc. You can [add a till with new custom fields](https://docs.capillarytech.com/reference/add-till-with-new-custom-fields), [add a till with existing custom fields attached to it](https://docs.capillarytech.com/reference/add-till-and-attach-custom-field) or can also [add the custom fields while updating a till](https://docs.capillarytech.com/reference/create-custom-field-to-attach-existing-till).
> - For detailed information about our APIs and for hands-on testing, refer documentation in [API overview](https://docs.capillarytech.com/reference/apioverview) and  step-by-step guide on making your first API call in [Make your first API call](https://docs.capillarytech.com/reference/make-your-first-api-call) .

# API endpoint example

<https://eu.api.capillarytech.com/v2/orgEntity/till>

# Prerequisites

- [ ] Authentication; Basic or OAuth authentication details
- [ ] Access group resource - Access to Organisation resource

# Resource information

|               |                   |
| :------------ | :---------------- |
| URI           | v2/orgEntity/till |
| HTTP method   | POST              |
| Rate limit    | Default           |
| Batch support | NA                |

# Request query/body parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter  \n(Parameters marked with \\* are mandatory)",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "name\\*",
    "0-1": "string",
    "0-2": "Name for the till. The Till name specified will be copied to Till code as well in the backend. You can have same till name and store names for tills and stores in different clusters.",
    "1-0": "password\\*",
    "1-1": "string",
    "1-2": "Password for the till",
    "2-0": "storeId\\*",
    "2-1": "long",
    "2-2": "Store ID of the parent Store to in which the Till has to be created.",
    "3-0": "description",
    "3-1": "string",
    "3-2": "Description for the till.",
    "4-0": "billable",
    "4-1": "boolean",
    "4-2": "Specify if the till is used for billing. By default, the value is set as true.",
    "5-0": "storeServerId",
    "5-1": "long",
    "5-2": "Store server ID of the parent Store if available."
  },
  "cols": 3,
  "rows": 6,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


```curl
curl --location 'https://eu.api.capillarytech.com/v2/orgEntity/till' \
--header 'Authorization: Basic cmFuZG9tE6MjAyY2I5NjJhYzU5MDc1Yjk2NGIwNzE1MmQyMzRiNzA=' \
--header 'Content-Type: application/json' \
--data '{
  "description": "Testing description",
  "storeId": 50154731,
  "password": "123",
  "billable": true,
  "name": "new_till2239"
}'
```

# Response parameters

| Parameter | Description          |
| --------- | -------------------- |
| createdId | The till ID created. |
| warnings  | Warnings if any.     |

```json
{
    "createdId": 50157065,
    "warnings": []
}
```

# API-specific error codes

| Error code | Description                                                |
| :--------- | :--------------------------------------------------------- |
| 1207       | TIll name already exists. Use a unique name.               |
| 1214       | The parent store is not valid. Use a valid parent store ID |
