---
title: "API Template"
slug: "api-template"
excerpt: "This is a sample API document."
hidden: true
createdAt: "Tue Oct 17 2023 14:11:44 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Aug 26 2024 15:47:46 GMT+0000 (Coordinated Universal Time)"
---
<Intro about API>

> 👍 Note
> 
> For detailed information about our APIs and for hands-on testing, refer documentation in [API overview](https://docs.capillarytech.com/reference/apioverview) and  step-by-step guide on making your first API call in [Make your first API call](https://docs.capillarytech.com/reference/make-your-first-api-call) .

<br />

# API endpoint example

\`<https://eu.api.capillarytech.com/v2/auditLog/get?entityType=CUSTOMER&entityId=98662653&source=INSTORE>

# Prerequisites

- [ ] Authentication; Basic or OAuth authentication details
- [ ] Access group resource - NA

# Resource information

|                       |                                         |
| :-------------------- | :-------------------------------------- |
| URI                   |                                         |
| HTTP method           | GET                                     |
| Pagination supported? | Other than for GET APIs mark this as NA |
| Rate limit            | \-                                      |
| Batch support         | NA                                      |
|                       |                                         |

# Request query/body parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter  \n(Parameters marked with \\* are mandatory)",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "",
    "0-1": "",
    "0-2": ""
  },
  "cols": 3,
  "rows": 1,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


```curl
Example curl
```

# Response parameters

| Parameter | Description |
| --------- | ----------- |
|           |             |

```json
Example JSON
```

# API-specific error codes

| Error code | Description |
| :--------- | :---------- |
|            |             |
|            |             |

[block:html]
{
  "html": "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <title>Embedded Code Example</title>\n</head>\n<body>\n    <!-- Embedding the code -->\n    <script src=\"https://static.elfsight.com/platform/platform.js\" data-use-service-core defer></script>\n    <div class=\"elfsight-app-1ddc48f7-4948-40a1-93ca-8c71f41dfe5c\" data-elfsight-app-lazy></div>\n</body>\n</html>\n"
}
[/block]
