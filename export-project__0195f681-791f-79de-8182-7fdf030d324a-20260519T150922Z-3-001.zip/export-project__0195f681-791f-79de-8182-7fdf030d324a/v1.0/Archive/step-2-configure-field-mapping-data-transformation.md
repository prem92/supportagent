---
title: "Step 2: Configure field mapping & data transformation"
slug: "step-2-configure-field-mapping-data-transformation"
excerpt: ""
hidden: true
createdAt: "Tue Apr 05 2022 06:49:22 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
After configuring SFTP, you need to configure the customer or transaction block to map the headers of the CSV file with that of the Capillary system and automate data transformations.

According to the type of data of the selected template, you will see configuration options.

1. In InTouch org, select the org ID for which you want to configure data mapping/transformation.
2. In File Delimiter, enter the character used to separate each field in the CSV file - comma or tab. It is usually a comma (,).
3. To convert the date format of date entries of the CSV file, check Format Transaction Date and select your preferred date format in Transaction Date Format.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c04f344-DWX9i1tsjYcdPQcI2ph7JVS8zmX8yg0Ebg.png",
        "DWX9i1tsjYcdPQcI2ph7JVS8zmX8yg0Ebg.png",
        704
      ],
      "border": true
    }
  ]
}
[/block]


4. Configure each tab for the respective field mappings and data transformations.

- **extendedFields**: Contains all transaction and line item level extended fields. Map each of the extended fields with the extended fields in the CSV file.
- **transaction**: Contains all transaction fields. Map each of the transaction fields with the names in the CSV file.
- **attribution**: Contains attribution headers.
- **lineitem**: Contains all transaction line-item fields. Map each of the transaction line item fields with the names in the CSV file.
- **filter**: Available for templates with Filters. For example,  Transaction Add V2 with filter.  
- **customFields**: Contains all transaction and line item level custom fields. Map each of the custom fields with the custom field names of the CSV file. 
- **Transformation**: This is a field that allows you to automate the process or transforming data of the respective field. For example, you can have a net transaction amount which is the gross amount\*quantity-discount. For any such automated computations for a field/entry, you can use the transformation column - To add or update transformation, click on the respective **Edit** icon.  
  To know more about header mapping, data transformation expressions, and filter expressions with examples, navigate to the respective section.

5. Click **Continue** to save and proceed to Step 3 to configure API authentication details. 

## Data Transformation using mapping & expressions

**Attribution Headers**  
File headers mapping to API store or till attribution headers  
**Example 1: Attribute using Till Code **

- Header: Till_IUN 

- identifierType: const(TILL_CODE) 

- identifierValue: Till IUN  
  **Example 2: Attribute using Store Code **

- Header: Store Code 
  - identifierType: const(STORE_CODE) 
  - identifierValue: Store Code 

## Filter Expressions

**Example: Process dataflow only if a transaction is paid or refunded.**

- **Headers**: Financial Status 
- **Filter header mapping (header)**: Financial Status  
  **\* Filter expression: ${header_value:equals('paid')**:or(${header_value:equals('refunded')})} 

## Data Transformation

Header Mapping  
Mapping the API fields_ billAmount_ and _billNumber_ with headers

1. **Header**: BILL AMOUNT;  **Value Mapped**: BILL AMOUNT 
2. **Header**: TRANSACTION ID;** Value Mapped**: TRANSACTION ID  
   Assign a constant value

[block:parameters]
{
  "data": {
    "h-0": "Operator",
    "h-1": "Expression Format",
    "h-2": "Example",
    "0-0": "const",
    "0-1": "const{header name}",
    "0-2": "1. Expression to set the source as INSTORE:  \nconst{INSTORE}  \n2. Expression to set Transaction Type as Not Interested:  \nconst{NOT_INTERESTED}"
  },
  "cols": 3,
  "rows": 1,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


Arithmetic expressions

[block:parameters]
{
  "data": {
    "h-0": "Supported Operators",
    "h-1": "Expression Format",
    "h-2": "Example",
    "0-0": "+  \n -  \n \\*  \n /",
    "0-1": "exp{hdr{header 1} [operator] hdr{header 2}}  \nEnsure the open or close bracket '{' '}'  \nNote: Ensure that the braces are matched properly (opened and closing).",
    "0-2": "Example 1: Compute Net Amount  \n  \nHeaders: LineItem_Amount, LineItem_Discount  \nExpression: exp{hdr{LineItem_Amount} - hdr{LineItem_Discount}}",
    "1-0": "",
    "1-1": "",
    "1-2": "Example 2: Compute net amount based on quantity  \nHeaders: LineItem_Amount, Quantity  \nExpression: exp{hdr{LineItem_Amount} \\* hdr{Quantity}}",
    "2-0": "",
    "2-1": "",
    "2-2": "Example 3: Currency Conversion: INR to DOLLAR  \n  \nHeaders: LineItem_Amount  \nExpression: exp{hdr{LineItem_Amount} / 74}"
  },
  "cols": 3,
  "rows": 3,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


String operations

[block:parameters]
{
  "data": {
    "h-0": "Supported Operators",
    "h-1": "Expression Format",
    "h-2": "Example",
    "0-0": "startsWith  \nendsWith  \nconcat  \nsubstring",
    "0-1": "exp{string expression1.concat(string expression2)}",
    "0-2": "Example 1: Concat two or more headers for Description.  \nHeaders: Item_Name, Item_Purpose  \nExpression: exp{'hdr{Item_Name}'.concat('hdr{Item_Purpose}')}",
    "1-0": "",
    "1-1": "",
    "1-2": "Example 2: Concat two or more headers with fixed info for Item Description.  \nHeaders: Item_Name, Item_Purpose  \nExpression: exp{'hdr{Item_Name}'.concat(' is used for ').concat('hdr{Item_Purpose}')}",
    "2-0": "",
    "2-1": "",
    "2-2": "Example 3: Remove '+' from the mobile number if exists.  \nHeaders: Mobile_No  \nExpression: exp{ ('hdr{Mobile_No}'.startsWith('+')) ? 'hdr{Mobile_No}'.substring(1) : 'hdr{Mobile_No}' }"
  },
  "cols": 3,
  "rows": 3,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


Conditional Operations

[block:parameters]
{
  "data": {
    "h-0": "Operator",
    "h-1": "Expression Format",
    "h-2": "Example",
    "0-0": "? :",
    "0-1": "exp{(conditional expression) ? expression1 : expression2}",
    "0-2": "Example 1: Check if the length of MOBILE number is 10, add country code '+91' otherwise return the existing value.  \nHeaders: Mobile_No  \nExpression:  exp{('hdr{Mobile_No}'.length() == 10) ? '+91'.concat('hdr{Mobile_No}') : 'hdr{Mobile_No}' }",
    "1-0": "",
    "1-1": "",
    "1-2": "Example 2: Check if an item is returned: if yes, set transaction type value 'RETURN' else 'REGULAR'  \nHeaders: Is_Returned (Possible values 'true' / 'false')  \nExpression: exp{ ('yes'.equalsIgnoreCase('hdr{Is_Returned}')) ? 'RETURN' : 'REGULAR' }"
  },
  "cols": 3,
  "rows": 2,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


Complex expressions

[block:parameters]
{
  "data": {
    "h-0": "Operator",
    "h-1": "Expression",
    "h-2": "Example",
    "0-0": "",
    "0-1": "",
    "0-2": "Example 1: Compute Non-fraction Qualified quantity based on Product Category.  \nif Product Category is any of FUEL, JEWEL, METAL then qualified quantity would be the difference of LineItem_Amount and LineItem_Discount divided by LineItem_Rate else it would be LineItem_Qty  \nHeaders: Product_Category, LineItem_Discount, LineItem_Amount, LineItem_Rate, LineItem_Qty  \nExpression: exp{ ({'FUEL','JEWEL','METAL'}.contains('hdr{Product_Category}') ) ? T(Math).floor( (hdr{LineItem_Amount} - hdr{LineItem_Discount}) / hdr{LineItem_Rate}) : T(Math).floor(hdr{LineItem_Qty}) }"
  },
  "cols": 3,
  "rows": 1,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]
