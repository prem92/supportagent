---
title: "Get Org Events"
slug: "get-event-details"
excerpt: "Retrieves all events configured for the org. This includes both standard and custom events.\n\nYou can also use the query parameter to fetch details of a specific event."
hidden: true
createdAt: "Thu Jun 09 2022 05:37:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 24 2024 12:58:46 GMT+0000 (Coordinated Universal Time)"
---
