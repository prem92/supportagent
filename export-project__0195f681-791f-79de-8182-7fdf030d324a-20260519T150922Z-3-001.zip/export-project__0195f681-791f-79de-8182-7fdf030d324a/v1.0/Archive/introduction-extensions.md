---
title: "Introduction"
slug: "introduction-extensions"
excerpt: ""
hidden: true
createdAt: "Tue Aug 06 2024 12:44:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jan 23 2025 05:37:33 GMT+0000 (Coordinated Universal Time)"
---
Capillary Extension Platforms are a family of **No/Low Code Tools** and **Frameworks** that enable developers to extend core product capabilities. Extensions let you incorporate your business logic into an API or UI, enhancing the capabilities of existing Capillary APIs and UI components. This customization helps meet brand-specific requirements. There are different types of Extensions, which cater to varying types of use cases. 

# Types of Extensions

Capillary has two types of extensions:

[block:html]
{
  "html": "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<style>\n  .grid {\n    display: flex;\n    gap: 20px;\n    flex-wrap: wrap;\n  }\n\n  .tile {\n    flex: 1;\n    min-width: 200px; /* Adjusted for better text fitting */\n    background-color: #f0f0f0;\n    padding: 20px;\n    border-radius: 10px;\n    text-align: center;\n    transition: background-color 0.3s ease, transform 0.3s ease;\n    box-sizing: border-box; /* Ensures padding does not affect box width */\n    position: relative; /* Ensure position for relative positioning of text */\n    border: 1px solid #ccc; /* Add border to the tile */\n    overflow: hidden; /* Ensure the background color covers the content */\n    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Subtle drop shadow */\n  }\n\n  .tile a {\n    display: block;\n    text-decoration: none !important; /* Force removal of underline */\n    color: inherit; /* Text color inherits from its parent */\n    height: 100%;\n    width: 100%;\n    position: relative; /* Ensure the link covers the entire tile */\n    z-index: 1; /* Ensure the link is below the text */\n  }\n\n  .tile:hover {\n    background-color: #f0f0f0; /* Default background color for non-hover state */\n    transform: scale(1.05);\n  }\n\n  /* Specific hover background colors for each tile */\n  .tile[data-tile=\"api-extensions\"]:hover {\n    background-color: rgba(100, 149, 237, 0.4);\n  }\n\n  .tile[data-tile=\"ui-extensions\"]:hover {\n    background-color: rgba(255, 153, 102, 0.4);\n  }\n\n  .tile p {\n    margin: 0; /* Removes default margin for paragraphs */\n    line-height: 1.4; /* Improves readability */\n    z-index: 2; /* Ensure text is above the link */\n    position: relative; /* Ensure text is above the link */\n    text-align: left; /* Left-align paragraph text */\n  }\n\n  .tile span {\n    display: block;\n    font-weight: bold;\n    font-size: 1.3em; /* Adjust font size here */\n    text-align: left;\n    margin-bottom: 10px;\n  }\n</style>\n</head>\n<body>\n\n<div class=\"grid -col-2\">\n  <div class=\"tile\" data-tile=\"api-extensions\">\n    <a href=\"https://docs.capillarytech.com/reference/api-extension-doc\">\n      <span>API Extensions</span>\n      <p>Enhances and chains existing APIs to develop applications that meet brand-specific requirements.</p>\n    </a>\n  </div>\n  <div class=\"tile\" data-tile=\"ui-extensions\">\n    <a href=\"https://docs.capillarytech.com/reference/ui-extension\">\n      <span>UI Extensions</span>\n      <p>Enhances the capabilities of existing UIs, such as Member Care to meet brand-specific requirements.</p>\n    </a>\n  </div>\n</div>\n\n</body>\n</html>\n"
}
[/block]
