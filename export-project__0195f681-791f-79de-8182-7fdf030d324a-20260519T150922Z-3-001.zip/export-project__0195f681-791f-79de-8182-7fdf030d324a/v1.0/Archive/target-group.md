---
title: "getUserTargets API"
slug: "target-group"
excerpt: "This API returns user related information for Milestones/Streaks, by taking a user-ID as the input."
hidden: true
createdAt: "Thu Apr 27 2023 06:24:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 07 2024 13:23:58 GMT+0000 (Coordinated Universal Time)"
---
This API helps in getting all the details of all the target group the user is associated with. Please note that, user_id is the parameter using which target groups for that user will be fetched. Meaning, that is the mandatory parameter when using this API.

You can see the sample 200 response of this API by clicking on the 200 symbol on the right side.
