---
title: "Create Event (Custom)"
slug: "create-event-custom"
excerpt: "Lets you create a new behavioral event."
hidden: true
createdAt: "Thu Jun 09 2022 04:23:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Aug 30 2024 08:22:40 GMT+0000 (Coordinated Universal Time)"
---
### Request Body Parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "eventName\\*",
    "0-1": "string",
    "0-2": "Name of the event.",
    "1-0": "actions\\*",
    "1-1": "enum",
    "1-2": "Destination of the event. Values: `EMFConsumer` for EMF related events: Loyalty, DVS, and Communication, EIConsumer for Essential Insights.",
    "2-0": "description",
    "2-1": "string",
    "2-2": "Short description for the event.",
    "3-0": "fields",
    "3-1": "obj",
    "3-2": "Configure fields for the current event with attributes: `name`, `type`, and `value`. The various attributes available are:  \n-`addCustomerIfNotExists` - Adds the customer if the customer does not exist.  \n-`isRequired` - Marks the attribute as mandatory  \n-`isUniqueKeyField `- Includes the attribute, to the unique key. Once defined as a unique key field, this attribute becomes mandatory and needs to be marked as `isRequired`. By default, customer identifier and event name are already part of the unique key.",
    "4-0": "name",
    "4-1": "string",
    "4-2": "Specify the name of the field. ",
    "5-0": "type",
    "5-1": "enum",
    "5-2": "Specify the type of the attribute. Values: `tillCode`, `couponCode`, `customer`, `productSku`, `productBrand`, `productCategory`, `string`, `double`.",
    "6-0": "addCustomerIfNotExists",
    "6-1": "obj",
    "6-2": "Set this value to `true` to allow registering new customers in to the loyalty program automatically",
    "7-0": "valueType",
    "7-1": "enum",
    "7-2": "Data-type of the attribute. For example, `Boolean`, `Enum`, `String`.",
    "8-0": "value",
    "8-1": "string",
    "8-2": "Value of the attribute based on its `valueType`.For example, if `valueType` is Boolean, value could be either `true` or `false`.",
    "9-0": "identifierType",
    "9-1": "Object",
    "9-2": "Specify the identifier type and its value",
    "10-0": "value",
    "10-1": "String",
    "10-2": "Supported values: userId, mobile, email, externalId, wechat, martjackId, cuid, fbid, unionId, fcmToken, line, cardnumber, cardExternalId",
    "11-0": "valueType",
    "11-1": "String",
    "11-2": "Value for the identifier type"
  },
  "cols": 3,
  "rows": 12,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


<aside class="notice">All parameters marked by * are mandatory. </aside>

For information on event uniqueness check, see [Event uniqueness check](https://docs.capillarytech.com/docs/behavioral-events-2#enabling-uniqueness-check).
