---
title: "Release Notes"
slug: "release-notes-1"
excerpt: ""
hidden: true
createdAt: "Wed Apr 06 2022 05:04:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
This section contains quarterly release notes for the current year and yearly release notes for the previous years.

Navigate to the respective articles to know what has happened in each quarter.
