---
title: "API Extension Catalogue"
slug: "api-extension-catalogue"
excerpt: ""
hidden: true
createdAt: "Tue Aug 06 2024 12:35:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Aug 07 2024 05:44:35 GMT+0000 (Coordinated Universal Time)"
---
The API extension catalogue displays the applications developed using the Capillary API extensions. Some extensions are brand-specific and some are available for all orgs. Contact the access team for acess to the extensions page and contact your CSM for enabling specific extensions for your org. You can also create specific extension for your brand as per your requirement. Refer
