---
title: "Get Customer Details"
slug: "get-customer-details-"
excerpt: "Retrieves the details of a customer from a specific source. Use `embed` to other parameters to fetch specific details required."
hidden: true
createdAt: "Wed Dec 22 2021 09:48:00 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jul 23 2024 10:45:37 GMT+0000 (Coordinated Universal Time)"
---
Retrieves details of a specific customer such as:

- profile information – first name, last name, registered date, registered at TILL
- recent profile updated – details of the recent update in profile information
- registered identifiers, communication channels
- loyalty information – loyalty status, registered date, purchases, etc.
- Multiple Loyalty Program Details: Program wise details if the org has multiple loyalty programs support
- Customer image

To fetch customer details from a specific account of a source (source with multiple accounts), you need to provide the respective account id.

> 📘 If you attempt to retrieve data of any deleted customer after a successful PII deletion, you will receive the following response:
> 
> ` "message": "Customer is deleted after PII delete request"`

# API endpoint

{host}/v2//customers/{customerId}/{queryparameters}

# Query parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter  \n(Parameters marked with \\* are mandatory)",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "source\\*",
    "0-1": "Enum [INSTORE, MARTJACK, WECHAT, LINE, ALL]",
    "0-2": "Specifies the source of the customer details to be retrieved.",
    "1-0": "accountId",
    "1-1": "String",
    "1-2": "Unique identifier for the account.",
    "2-0": "embed",
    "2-1": "Array of String",
    "2-2": "Details to include in the response. Supported values: `points`, `subscriptions`, `mlp`, `userGroup`, `gapDetails`, `promotionalPoints`, `expirySchedules`, `expiredPoints`, `customerImage`, '`returnedPoints`, '`associatedImages`.  \n  \n**Note:** The associated images parameter retrieves the barcode image details associated with the customer.",
    "3-0": "includedAllUserGroup2",
    "3-1": "Boolean (false)",
    "3-2": "Pass `true` to see the customer details in all user groups.",
    "4-0": "userGroup2Id",
    "4-1": "Long",
    "4-2": "Unique ID of the user group to fetch customer details from.",
    "5-0": "includedUserGroup2LoyaltyDetails",
    "5-1": "Boolean (false)",
    "5-2": "Pass `true` to include loyalty details of user groups.",
    "6-0": "includedFraudDetails",
    "6-1": "Boolean (false)",
    "6-2": "Pass `true` to include fraud details of the customer in the response.",
    "7-0": "includedOnlyCurrentProfile",
    "7-1": "Boolean (false)",
    "7-2": "Pass `true` to fetch details of the current source and hide information from other sources.",
    "8-0": "ug2JoinedStartDate",
    "8-1": "DateTime",
    "8-2": "Start date for filtering customers who joined user groups.",
    "9-0": "ug2JoinedEndDate",
    "9-1": "DateTime",
    "9-2": "End date for filtering customers who joined user groups.",
    "10-0": "ug2Offset",
    "10-1": "Integer",
    "10-2": "Specifies the offset for pagination of user group results.",
    "11-0": "ug2Limit",
    "11-1": "Integer",
    "11-2": "Sets the maximum number of results to retrieve per page for user groups.",
    "12-0": "ug2SortBy",
    "12-1": "String (JoinedDate)",
    "12-2": "Specifies the field by which the user group results should be sorted.",
    "13-0": "ug2SortOrder",
    "13-1": "Enum [ASC, DESC] \\(DESC)",
    "13-2": "Specifies the sorting order for the user group results.",
    "14-0": "ug2PaginationDetails",
    "14-1": "Boolean",
    "14-2": "Pass `true` to include pagination details for user groups."
  },
  "cols": 3,
  "rows": 15,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


# Response parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter  \n(Parameters marked with \\* are mandatory)",
    "h-1": "Description",
    "0-0": "id\\*",
    "0-1": "Unique identifier for the customer.",
    "1-0": "profiles",
    "1-1": "List of customer profiles containing various details such as name, attribution, identifiers, communication channels, source, etc.",
    "2-0": "loyaltyInfo",
    "2-1": "Information related to the customer's loyalty, including loyalty type, attribution, and lifetime purchases.",
    "3-0": "segments",
    "3-1": "Placeholder for customer segments information.",
    "4-0": "associatedWith",
    "4-1": "Code identifying the association of the customer (e.g., till code).",
    "5-0": "ug2Pagination",
    "5-1": "Pagination details for user group results related to the customer.",
    "6-0": "extendedFields",
    "6-1": "Additional extended fields associated with the customer, such as city and gender.",
    "7-0": "cardDetails",
    "7-1": "Details of the card owned by the customer, including card ID, issued date, expiry date, series information, status, and more.",
    "8-0": "warnings",
    "8-1": "List of warnings related to the response."
  },
  "cols": 2,
  "rows": 9,
  "align": [
    null,
    null
  ]
}
[/block]
