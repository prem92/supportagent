---
title: "Get Customer Events"
slug: "get-customer-events"
excerpt: "Retrieves the details of all events of a specific customer."
hidden: true
createdAt: "Thu Jun 09 2022 05:54:31 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Aug 07 2024 13:50:58 GMT+0000 (Coordinated Universal Time)"
---
# Query parameter

| Parameter | Description                                                |
| :-------- | :--------------------------------------------------------- |
| userId    | Unique ID of the customer whose events need to be fetched. |

# Response parameter

| Parameter                | Description                                      |
| ------------------------ | ------------------------------------------------ |
| data                     | A list of event details.                         |
| orgId                    | The organization's identification number.        |
| userId                   | The user's identification number.                |
| date                     | The date and time when the event occurred.       |
| eventName                | Name of the event.                               |
| eventId                  | Unique identifier for the event.                 |
| source                   | Source from which the event originated.          |
| tillCode                 | Code of the till where the event took place.     |
| additonalAttributes      | Additional details associated with the event.    |
| accountid                | Account identification.                          |
| autoUpdateTimeStamp      | Time when the event was automatically updated.   |
| brandname/brand          | Name of the brand.                               |
| browsername/browser_name | Name of the browser where the event took place.  |
| cartid/cartrefkey        | Unique identifier for the cart.                  |
| categoryname/category    | Category under which the product/event falls.    |
| city                     | City where the event took place.                 |
| country                  | Country where the event took place.              |
| device                   | Type of device used during the event.            |
| id                       | Unique identifier.                               |
| ip                       | IP address from which the event originated.      |
| locationname             | Name of the location where the event took place. |
| osname/os_name           | Name of the operating system.                    |
| pageurl/page_url         | URL of the page where the event occurred.        |
| productname/name         | Name of the product.                             |
| region                   | Region where the event took place.               |
| till                     | Till details.                                    |
| variant                  | Variant details of the product.                  |
| warnings                 | A list of warnings related to the response.      |
| errors                   | A list of errors related to the response.        |
