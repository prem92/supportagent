---
title: "Create a Vendor (OLD)"
slug: "createvendor_old"
excerpt: "Creates a new vendor in the rewards system."
hidden: true
createdAt: "Mon Feb 17 2025 12:10:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Feb 27 2025 07:39:24 GMT+0000 (Coordinated Universal Time)"
---
A vendor is an external third-party brand that you can use to fulfil your rewards. This API allows you to define vendor details, add images and videos, and display them in your reward catalogue.

# API Error Codes

| Code | Description           | Reason                                    |
| :--- | :-------------------- | :---------------------------------------- |
| 5007 | Vendor already exists | Vendor with the same name already exists. |
| 3004 | Brand not found       | `brandId` provided is invalid.            |
