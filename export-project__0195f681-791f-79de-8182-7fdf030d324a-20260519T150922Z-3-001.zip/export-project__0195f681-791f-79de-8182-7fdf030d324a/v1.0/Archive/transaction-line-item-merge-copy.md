---
title: "Transaction line item merge (COPY)"
slug: "transaction-line-item-merge-copy"
excerpt: "This page provides you with information on transaction line item merge template."
hidden: true
createdAt: "Wed Sep 27 2023 10:37:37 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
This template enables comparison and merging of transaction data from both the line item file and the bill-level file, then adds the merged data to the platform.

During merging, the template also performs additional calculations, such as determining the bill amount using expressions, and includes the calculated values in the merged file.

## Use case

**Scenario:**

A retail company receives data in two separate Excel files. One file contains bill-level information, including total amounts, dates, and customer details. The other file contains line-level data, such as individual items, quantities, and prices. The retail company wants to create a consolidated dataset that combines bill-level and line-level data. They want to know which items were purchased in each bill and calculate the total cost of each item in every bill. 

**Solution: **

They can use Transaction line item merge template and choose the "Inner Join" option to include only the records that have matching BillNumbers in both data sources.

## Configuring transaction line item merge dataflow

To configure transaction line item merge dataflow, perform the below steps/actions:

1. In the **Connect-to-source** section, enter the source server details where the source data is present and the location for saving the processed file. See [Connect to source](https://docs.capillarytech.com/docs/connect-to-source).
2. In the **Decrypt data** section, if the files are encrypted, enter the details to decrypt the data. See [Decrypt data](https://docs.capillarytech.com/docs/decrypt-data).
3. In the **Join-Data** section, enter the required details and define the conditions to merge the two files and join the data. See [Join Data](https://docs.capillarytech.com/docs/transaction-line-item-merge#join-data).
4. In the **Transform Data**, map the API fields with the source file. For information on how to map the fields, see [Transform data](https://docs.capillarytech.com/docs/transform-data). 
5. In the **Connect-to-destination** section, Enter the API endpoint details.  
   For this template, the API  [/v2/transactions/bulk](https://docs.capillarytech.com/reference/addreturn-transaction-bulk) is used.  
   For information on adding API endpoints in this section,  see [Connect-to-destination API endpoints.](https://docs.capillarytech.com/docs/connect-to-destination#api-endpoint-details)
6. In the **Trigger **section, enter the details to schedule the trigger. See [Trigger](https://docs.capillarytech.com/docs/trigger).

## Join data

In this section, you need to enter the details of files that need to be identified, compared, and merged. Enter the below details:

[block:parameters]
{
  "data": {
    "h-0": "Field",
    "h-1": "Description",
    "0-0": "**Files 1-2 Join Types**",
    "0-1": "Enables you to select the type of SQL join command.  \n1. **Inner join **-  An Inner Join returns only the rows that have matching values in both tables being joined.  \nFor example, suppose you have two tables: \"Line item table\" and \"Bill level table,\" and you want to determine which items were purchased in each bill and calculate the total cost of each item in every bill. When you use the Inner Join option, the merged table will include only the records that have matching BillNumbers in both data sources.  \n  \n2. **Left outer join **- A Left Outer Join returns all the rows from the left table and the matching rows from the right table.  \nFor example, consider two tables: \"Customers\" and \"Orders.\" When you use a Left Outer Join, you retrieve all customer records along with any matching order records. If a customer has no orders, the customer record is still included with NULL values in the order-related columns.  \n  \n3. **Right outer join**- A Right Outer Join returns all the rows from the right table and the matching rows from the left table.  \nFor example, consider two tables: \"Orders\" and \"Customers.\" When you perform a Right Outer Join, you retrieve all order records along with any matching customer records. If an order has no associated customer, the order record is still included with NULL values in the customer-related columns.  \n  \n4. **Outer join** - An Outer Join, also known as a Full Outer Join, returns all rows from both tables, including matching rows and those with no matches.",
    "1-0": "**All Files Delimiter**",
    "1-1": "Enter the file delimiter (comma or tab) to separate fields in the .csv file. By default, the delimiter is a comma (,).",
    "2-0": "**File 1 Regex**",
    "2-1": "Enter the name of your first file here in the format** filename\\_.\\*.fileformat**. The asterisk represents the wildcard.  \n  \nFor example, for the system to search for files that begin with the name \"BILL_LEVEL_MERGE\" followed by any sequence of characters you can enter the file name as \"BILL_LEVEL_MERGE.\\*.csv\". This will enable the system to locate files that match this pattern.  \n  \n**NOTE:** The file works in an FCFS manner. The files that are uploaded first and second are merged first.",
    "3-0": "**File 2 Regex**",
    "3-1": "Enter the name of your second file in the format: **filename.\\*.fileformat**. The asterisk represents the wildcard.  \n  \nFor example, for the system to search for files that begin with the name \"BILL_LEVEL_MERGE\" followed by any sequence of characters you can enter the file name as \"BILL_LEVEL_MERGE.\\*.csv\". This will enable the system to locate files that match this pattern.  \n**NOTE **: The file works in an FCFS manner. The files that are uploaded first and second are merged first.",
    "4-0": "**File 1 Headers**",
    "4-1": "Enter the column header name of File 1 that needs to be compared.  \n  \nThis is compared with the column headers in the File 2.  \nTo match columns based on multiple headers, enter the header names separated by a comma.",
    "5-0": "**File 2 Headers**",
    "5-1": "Enter the column header name of File 2 that needs to be compared.  \n  \nThis is compared with the column headers in the File 1.  \nTo match columns based on multiple headers, enter the header names separated by a comma.",
    "6-0": "**File Join Use Case**",
    "6-1": "From the dropdown, select TRANSACTION_LINE_ITEM.  \nThis is an inner join operation where one row in the bill maps to multiple line items.  \n  \n\\*\\*NOTE:\\*\\*The option None is not applicable.",
    "7-0": "**Output Filename**",
    "7-1": "Enter the output filename.  \n  \nBy default, the filename format is merge_yyy-mm-dd, where merge is the file name, yyyy-mm-dd is the year month, and date on which the file is created.",
    "8-0": "**Alphabetical Sort**",
    "8-1": "Select this check box to ensure accurate sorting of the files in alphanumerical order. By default, this is always enabled.  \n**NOTE: It is recommended to always select the checkbox before proceeding further.**",
    "9-0": "**Merge based on common Name**",
    "9-1": "Make sure that this check box is always selected.  \n  \nThis makes sure that the system identifies the correct files to be merged.",
    "10-0": "**Merge based on common name Template File One**",
    "10-1": "Enter the filename using the <common> tag.  \n  \nFor example, if there are files with names **TktABC.dat**_, and **TktDocument_ABC.dat**, and if you enter the value as TktDocument_<common>.dat, the system looks for the file and selects TktDocument_ABC.dat for merging.  \nABC is the common tag among the files.",
    "11-0": "**Merge based on common Name Template File Two**",
    "11-1": "Enter the filename using the <common> tag.  \n  \nFor example, if there are files with names **TktABC.dat**_ and **TktDocument_ABC.dat**, and if you enter the value as TktDocument_<common>.dat, the system looks for the file and selects TktDocument_ABC.dat for merging.  \nABC is the common tag among the files.",
    "12-0": "**File One is Headerless**",
    "12-1": "Select the check box if the columns in file one do not have a header.",
    "13-0": "**File Two is Headerless**",
    "13-1": "Select the check box if the columns in file two do not have a header.",
    "14-0": "**File One Mention Header names**",
    "14-1": "Define the heading order of the columns in fIle one separated by commas.",
    "15-0": "**File Two Mention Header names**",
    "15-1": "Define the heading order of the columns in fIle two separated by commas.",
    "16-0": "**Match All Regex**",
    "16-1": "Select **True **from the dropdown to keep only the matching files in the server and delete the files that are not matched. By default, the value is set as **False**.",
    "17-0": "**All Unique Match**",
    "17-1": "Select **True **to identify and delete duplicate files."
  },
  "cols": 2,
  "rows": 18,
  "align": [
    "left",
    "left"
  ]
}
[/block]


## FAQ

**Q:** Is it mandatory to enable **Merge based on common Name** checkbox?  
**A:** Yes, It is mandatory to **Merge based on common Name** checkbox to make sure the correct files are merged together.

**Q:** How to view the transaction details in Memebercare against the customer?  
**A:** You can view the customer details in Membercare by clicking on Transactions under the Events tab.

**Q: **Is it mandatory to enable the **Alphabetical sort** checkbox?  
**A:** Yes, it is highly recommended to enable the **Alphabetical sort** checkbox to ensure accurate sorting of the files in alphanumerical order.
