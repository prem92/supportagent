---
title: "Update Customer Details"
slug: "update-customer-details"
excerpt: "Lets you update existing customer details."
hidden: true
createdAt: "Fri Dec 17 2021 08:00:10 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 04:42:04 GMT+0000 (Coordinated Universal Time)"
---
You can update profile information, extended field values, communication details, custom field values, extended field values, and loyalty status (only non loyalty to loyalty) on any source such as `FACEBOOK`, `WEB_ENGAGE`, `WECHAT`, `INSTORE`, `MARTJACK`, `TMALL`, `TAOBAO`, `JD`, `ECOMMERCE`, and `WEBSITE`.

Limitations of the customer update API - 

- Cannot update identifiers with this API
- Cannot modify source type
- Cannot change a loyalty customer to non-loyalty but can change a non-loyalty customer to a loyalty

### Prerequisites

The following are the prerequisites for updating customer details - 

- Unique customer id of the respective customer
- Source in which you want to modify the details
- Account id of the specific source in which you want to modify the customer details 

### Request URL

## Request Query Parameters

| Parameter  | Type    | Description                                                                                                                                                                                                       |
| :--------- | :------ | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| customerId | string  | Unique Id of the customer whose details need to be updated.                                                                                                                                                       |
| source     | enum    | Specify the source in which you want to update the customer details - FACEBOOK, WEB_ENGAGE, WECHAT, INSTORE, MARTJACK, TMALL, TAOBAO, JD, ECOMMERCE, WEBSITE, LINE, MOBILE_APP. For sources with multiple account |
| accountId  | string  | Account in which you want to update the customer details. (Required only for sources with multiple accounts).                                                                                                     |
| use_async  | boolean | Pass `true` to run loyalty activities in the back ground. Hence, sideEffects are not returned in the response.  Pass `false` to wait for loyalty activities to complete and return the side effects.              |

## Request Body Parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "loyaltyType",
    "0-1": "enum",
    "0-2": "Loyalty status of the customer.  \nValue: `loyalty`, `non_loyalty`.",
    "1-0": "profiles",
    "1-1": "list",
    "1-2": "Meta information of the customer",
    "2-0": "   Firstname",
    "2-1": "string",
    "2-2": "First Name of the customer.",
    "3-0": "   Lastname",
    "3-1": "string",
    "3-2": "Last Name of the customer.",
    "4-0": "   commChannels",
    "4-1": "obj",
    "4-2": "Communication channels of the customer",
    "5-0": "      type",
    "5-1": "enum",
    "5-2": "Type of the communication channel.  \nValue: `mobile`, `email`, `wechat`, `ios`, `android`, `line`, `mobilePush`.",
    "6-0": "      value",
    "6-1": "string",
    "6-2": "Based on the channel `type`  enter the channel value. For example, mobile number is the value for mobile. **Note:** For mobile numbers, add the mobile number with the country code.",
    "7-0": "      primary",
    "7-1": "boolean",
    "7-2": "Whether the current identifier of the customer (primary identifier as per the org's configuration).",
    "8-0": "      verified",
    "8-1": "boolean",
    "8-2": "Whether the current identifier is the primary identifier or not. For example, through OTP.",
    "9-0": "      meta",
    "9-1": "obj",
    "9-2": "Additional details of the identifier.",
    "10-0": "         lastViewedDate",
    "10-1": "date-time",
    "10-2": "Date when the customer recently opened the app. Applicable for the channel `mobilePush`.",
    "11-0": "extendedFields",
    "11-1": "obj",
    "11-2": "Extended field details of the customer in key:value pairs. You can  only pass extended fields that are enabled for your orgwith the respective datatypes value.",
    "12-0": "loyaltyProgramEnrollments",
    "12-1": "obj",
    "12-2": "Lets you enroll customers into loyalty programs.",
    "13-0": "   programId",
    "13-1": "int",
    "13-2": "Unique Id of the loyalty program in which you want to enroll. You cannot update if the customer is already enrolled in  the loyalty program.",
    "14-0": "   tierNumber",
    "14-1": "int",
    "14-2": "Sequence number of the tier that you want to allocate to the customer. For example, `1` for the lower tier, and `2` for the next tier, and so on.",
    "15-0": "   loyaltyPoints",
    "15-1": "int",
    "15-2": "Loyalty points to credit in customer's account.",
    "16-0": "   tierExpiryDate",
    "16-1": "date-time",
    "16-2": "Expiry date and time of the specified tier. Supported format:  \nYYYY-MM-DDTHH:MM:SS +/- (timezone).",
    "17-0": "   pointsExpiryDate",
    "17-1": "date-time",
    "17-2": "Expiry date and time of the points issued. Supported format:  \nYYYY-MM-DDTHH:MM:SS +/- (timezone)."
  },
  "cols": 3,
  "rows": 18,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]
