---
title: "Get Promotion Details"
slug: "get-promotion-details-1"
excerpt: "Retrieves the promotion details."
hidden: true
createdAt: "Fri Jun 17 2022 10:42:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Feb 27 2025 15:40:06 GMT+0000 (Coordinated Universal Time)"
---
