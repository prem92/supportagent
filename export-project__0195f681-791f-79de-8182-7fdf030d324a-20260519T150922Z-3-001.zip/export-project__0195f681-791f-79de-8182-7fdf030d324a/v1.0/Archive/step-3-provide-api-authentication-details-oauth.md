---
title: "Step 3: Provide API authentication details (OAuth)"
slug: "step-3-provide-api-authentication-details-oauth"
excerpt: ""
hidden: true
createdAt: "Tue Apr 05 2022 07:37:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Dec 06 2023 01:26:29 GMT+0000 (Coordinated Universal Time)"
---
API authentication is org specific and is required to authenticate APIs to capture data from the FTP server and save it to the Capillary database.

To configure OAuth credentials, follow these steps.

1. On the data flow configuration page, navigate to the OAuth block.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/29a4fc4-FdrBG83Mk8pHNO3ZtWJUyquwZjJIHpT3KQ.png",
        "FdrBG83Mk8pHNO3ZtWJUyquwZjJIHpT3KQ.png",
        735
      ],
      "border": true
    }
  ]
}
[/block]


2. In **Client Key**, enter the client key of the org.
3. In **Client Secret**, enter the secret generated for the org.
4. In **API Endpoint**, altering the endpoint of the API is required. By default, it takes the endpoint according to the selected template.
5. In **API Base URL**, enter the host URL according to the org's cluster.
6. In** API Method**, select the HTTP method for the API. Supported values:  POST, PUT.
7. In **Response Key**, enter the response status key.
8. Click **Continue** to save and proceed to the final step to configure [Frequency of triggering the Dataflow](https://docs.capillarytech.com/docs/step-4-configure-dataflow-execution-frequency).
