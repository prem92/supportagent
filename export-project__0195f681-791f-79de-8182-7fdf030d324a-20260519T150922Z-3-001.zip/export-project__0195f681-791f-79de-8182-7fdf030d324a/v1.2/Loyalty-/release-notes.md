---
title: "Release Notes"
slug: "release-notes"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Jan 19 2022 00:57:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jul 05 2022 12:16:05 GMT+0000 (Coordinated Universal Time)"
---
This section contains quarterly release notes for the current year and yearly release notes for the previous years.

Navigate to the respective articles to know what has happened in Loyalty+ each quarter.
