---
title: "FAQs"
slug: "faqs"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Dec 09 2021 16:24:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jul 25 2022 09:14:07 GMT+0000 (Coordinated Universal Time)"
---
## Loyalty Programs (Single & Multi-Loyalty)

<details>
<summary>If I have two loyalty programs running simultaneously, how I do know which one is active for stores and which one is being used for point allocation?
</summary>
Every org will have a default program (org level). When you have multi-loyalty programs configured for the org, points are issued from the program mapped to the TILL. 

However, this depends on the configuration. For example,  if a customer is enrolled in all the programs then the logic will run for all the programs but if the customer is only in one program then he will be evaluated for the rules written in that program and the points will be given for that program only. When it comes to an MLP kind of structure than one customer could be part of multiple programs or just one program and each program can have a different allocation strategy so all this is evaluated when the ‘add transaction’ call comes to us and whatever they are mapped to allocation happens as per that.  
In the case of MLP, there are 2 programs that are always evaluated one is the default program for that ORG, and the other is where they are enrolled.

</details>

<details>
<summary>Can I use a single loyalty program for multiple stores?</summary>
Yes, you can achieve this by applying scope to your rule in workflows.
</details>

<details>
<summary>Is there a concept of equivalent tiers in loyalty programs? How is a single card which is used for different events mapped to the program? Is there a need/ solution for it in the loyalty program?
</summary>
</details>

## Tiers

<details>
<summary>What is the difference between tier expiry and tier downgrade?</summary>
Tier expiry is when you have set a date for expiry and the user is automatically downgraded when the expiration date comes up. But when you are downgraded, you can basically set certain configurations, and depending on those configurations, the user will be downgraded.
</details>

<details>
<summary>What happens to the status of my customer if he/she does not fulfill any of the tier eligibility criteria?
</summary>
By default, the customer will be in the base tier of the program.
</details>

<details>
<summary>Does each of the renewal conditions have to be met or any one of them is enough?
</summary>
As of now, it's an 'or' condition, so either of those conditions will result in a renewal.
</details>

<details>
<summary>Will changing eligibility force the tiers to compute the settings for all users in advanced settings?</summary>
Yes, it depends on the tier evaluation cycle.
</details>

<details>
<summary>Can I set an action in the workflows to send a communication to the customer after I retain the customer tier based on conditions such as at least 10 visits or 1000 points, even if the customer has not met the tier criteria? </summary>
Yes, that action can be set in the workflows.
</details>

<details>
<summary>Is it possible to upgrade tiers by using any other means apart from the usual upgrade conditions like a coupon or passing the points rule?</summary>
As of now, you can do this manually through member care.
</details>

<details>
<summary>When I configure 26K points to upgrade a tier (say Gold), will it consider 26,000 points or 26,001 to qualify?</summary>
When configuring a tier, you will only see upgrade rules greater than or equal to (>=). Hence, a customer with 26000 points or more will be in the Gold tier.
</details>

## Points

<details>
<summary>Can I limit the number of times my customer can earn points?</summary>
You can limit the number of points a customer can earn in the points earning condition. However, there is no option to limit the number of times the points are issued for a customer.
</details>

<details>
<summary>What is the use of proportion and max point allocation?</summary>
Use Proportion lets you issue points based on the line item amount. The Maximum points allocation is to set a threshold value for the number of points a customer can earn.
</details>

<details>
<summary>How is the Transaction Points Allocation action different from Allocate Points?</summary>
**Transactional Points** - Points you earn as per the configured ruleset for making a transaction.

**Allocate Points** - Points you can assign on the transaction amount and custom field values based on the configured ruleset.

</details>

## Trackers

<details>
<summary>What tracking method should I apply to the use case in the tracker?

"Reward a customer on their 10th visit"</summary>  
You could either use Cyclic Windows or Calendar-based Cyclic Window. However, it is recommended to use Cyclic Window in this case.

</details>

<details>
<summary>In a moving window tracking method, if the duration is 365 days and the tracking entity is a customer transaction, will it include the data of the current day also?</summary>
It will include the current date's data. For example, assume you are tracking customer transactions with a moving window tracking method with a duration of 365 days. If a customer does a transaction on  Nov 24, 2021, then the tracking window will be from Nov 23, 2020, to Nov 24, 2021 (including the dates mentioned).
</details>

<details>
<summary>Can I use tracker for actions other than Tier Upgrade?</summary>
You can use trackers for Tier eligibility, tier renewals, customer milestones, incentivization, and other custom activities.
</details>

<details>
<summary>If a tier is upgraded using tracker value, does dynamic point earning work?</summary>
Yes, dynamic points earning will work for tier upgrades based on tracker value.
</details>

<details>
<summary>What type of incentives are supported for tracker conditions?</summary>
You can award points and offers to customers on tracker aggregate.
</details>

<details>
<summary> Can you share an example of a tracker which is used to issue coupons based on line-item purchases?</summary>
In cases where the brand doesn't want to credit the B2B customer every item they purchase (say cigarette/alcohol).
For example, In the case of Metro, if you don't want to incentivize customers on the purchase of cigarettes/alcohol. You can exclude such line item prices from the tracker.
</details>

<details>
<summary>Will the Transaction Return be considered as a visit in a tracker?</summary>
No, Transaction Return will not be considered as a visit in any case.
</details>

<details>
<summary>
Is the Scope applied to the ruleset level or the entire workflow level?
 The scope you apply in Workflow will apply to that particular page (activity).
</summary>

</details>

## Return transactions

<details>
<summary>
What happens when no reference to original bill is passed or the reference bill no. passed in not found? </summary>

The return bill is submitted without storing any reference to the original bill.

</details>

<details>
<summary>
How returns would be handled if there are two bill numbers with same purchase date? </summary>

Error is raised if multiple references are found. But, this is questionable, because the same return bill can be submitted if no reference to original bill is passed.

</details>

<details>
<summary>
What if the line items passed in the return bill do not match with the original bill?</summary>
It depends on the type of return - line item, full or amount. 
Depends on normal or mixed return.

If `type` is line item, the line item will be matched with the line items in the original bill for amount, quantity, code, etc. If any of them do not match, error would be raised.  
If normal return and type is amount, the amount at transaction level will be compared with the amount of original bill. It will also be checked whether any earlier return happened, and if there is any balance left for return.  
If mixed return and type is amount, the amount mentioned in the line item will be compared with the amount in the original bill. 

If type is full, all the line items would be returned.

</details>

<details>
<summary>

What if there are multiple line items with type amount for a mixed transaction?</summary>

For a mixed return transaction,  
1.First line item with return type amount would be considered a return transaction and would be compared with amount of original bill.  
2. Second line item with type amount would be considered another return transaction. The amount would be compared with the balance amount (original amount - first return amount).

</details>

<details>
<summary>

Is it possible to return NI transaction without original bill reference?</summary>

Yes, it is possible. In this case, line level data will not be saved since no validation is possible. Only the amount will be returned.

</details>
