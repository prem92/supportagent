---
title: "Loyalty+ overview"
slug: "loyalty-overview"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 19:56:23 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 09:37:30 GMT+0000 (Coordinated Universal Time)"
---
Loyalty+ is a platform that helps you incentivize your customers on the basis of their enrollment and engagement in the form of coupons and points. It lets you influence your customer lifecycle by rewarding them for different activities including transactions, profile updates, and . Through effective loyalty programs, you can motivate your customers to become more loyal and increase repeat transactions.

Loyalty+ helps you treat your customers differently, track their behavior, and monitor their interactions and incentivize them accordingly creating genuine connections.  Through effective loyalty programs, you can maximize customers' lifetime and maximize ROI.

With Loyalty+, you can grade your customers with loyalty tiers and depending on their purchase value and incentivize them separately by providing better benefits to high loyal customers. It upsurges customer engagement with your brand and drives their interactions. The embedded rule sets with expression editor provides a complete flexibility in creating simple to any complex conditions that you want to evaluate to trigger an action. You can perform several actions such as activity based tier upgrade, points allocation,  communication, issue coupon, renew tier, issue points to referrer or referee and more.

Loyalty programs are beneficial to both customers and brands as it not only provide benefits to customers but also build relationship with them.

## Features

Loyalty+ has a very easy-to-use UI and a powerful rule engine that has the flexibility to create rules based on various parameters such as loyalty type, promotions, customer spending. It provides the flexibility to create context-based loyalty programs.

- **Basic Loyalty Programs** let customers enroll in the loyalty program and get incentivized with points or coupons for every transaction they make.
- **Paid enrollment programs** are also called membership-based loyalty programs which allow customers to buy loyalty status (tier) to enjoy the tier benefits.

#### Loyalty for Conglomerates

Organizations with multiple brands can configure a different loyalty program for each brand while maintaining a single customer profile across the organization using the Multiple Loyalty Programs (MLP) feature in Loyalty+. This feature can also be used to create multi-country loyalty programs.

#### Omnichannel Loyalty

Loyalty+ supports Omni-channel loyalty, i.e., you can configure actions for the selected sources/accounts. The points are earned and burned seamlessly in online/offline platforms. Customers can be notified about the loyalty updates through a number of channels including SMS, email, Mobile Push and WeChat. All cross-channel registrations of a customer have been combined automatically and associated with a single account.

#### Create flexible tiers

Loyalty+ provides you the flexibility to [set up tier upgrade](https://docs.capillarytech.com/docs/tiers#create-tiers-and-configure-tier-upgrade-conditions) and [downgrade conditions ](https://docs.capillarytech.com/docs/tiers#configure-tier-downgrade) based on the customers' frequency of visits. You can also have tier upgrade based on purchases made by group members, customer tagging to customize the loyalty program to suit the brand’s needs.

You can configure conditions to downgrade their tier when they do not make any transaction for a certain period.

For example, assume that a loyalty customer makes frequent purchases in the first month and achieves a higher level tier and during the second month, the frequency of visits is low, you can downgrade the tier based on the recent transaction period. 

#### Support for different incentive types

There are a number of different types of loyalty programs that can be configured using Loyalty+ and you can incentivize your customers in multiple ways, in the form of points, coupons, promotions, etc.

#### Incentivize non-loyalty customers

Moving the non-loyalty customers to loyalty customers can be done through various Loyalty+ drives. For example, Loyalty+ supports issuing coupons to non-loyalty customers on an event. This ultimately increases engagement and strengthens the Loyalty Base.  

#### Incentivization on payment modes

Loyalty+ can be used to incentivize customers based on the payment mode used for a transaction. Loyalty+ supports incentivizing for different card types such as payments through Debit Cards, Credit Cards, Visa, and Mastercard. It also allows incentivizing bonus points based on banks. For example, award 10x points when a customer transacts with an HDFC card.
