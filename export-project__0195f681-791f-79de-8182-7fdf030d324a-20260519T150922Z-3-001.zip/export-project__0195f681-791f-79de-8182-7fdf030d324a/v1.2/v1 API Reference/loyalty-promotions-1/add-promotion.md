---
title: "Add Promotion"
slug: "add-promotion"
excerpt: "Lets you create a promotion for a specific loyalty program."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 17 2022 05:10:30 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 17 2022 05:19:49 GMT+0000 (Coordinated Universal Time)"
---
## Request POST Parameters

| Parameter            | Datatype  | Description                                                                                                                                                                                                                                                                         |
| -------------------- | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| id\*                 | int       |                                                                                                                                                                                                                                                                                     |
| name\*               | string    | Unique name of the promotion.                                                                                                                                                                                                                                                       |
| programId\*          | int       | Unique ID of the loyalty program to associate with the promotion. You can create multiple promotions under a single loyalty program.                                                                                                                                                |
| startDate\*          | date-time | Validity of the promotion. Pass the date range in `startDate` and `endDate` (ISO standard - `yyyy-mm-ddThh:mm:ss.s+z`).                                                                                                                                                             |
| endDate\*            | date-time | Validity of the promotion. Pass the ISO date range in `startDate` and `endDate` (ISO standard - `yyyy-mm-ddThh:mm:ss.s+z`).                                                                                                                                                         |
| allocatePointsOn     | string    | Enter event action name that generates promotional points. For example,  `Bill`.                                                                                                                                                                                                    |
| identifier\*         | string    | Unique identifier of the promotion.                                                                                                                                                                                                                                                 |
| eventName\*          | enum      | Name of the event to associate with the promotion. For example, `TRANSACTIONADD`, `CUSTOMERUPDATE`, `OfferScan`, `spinTheWheel`, and more.                                                                                                                                          |
| metadata             | obj       | Enter meta information of the promotion in key and value.                                                                                                                                                                                                                           |
| allocationActions    | obj       | Allocation attributes like allocation type, expiry days, and more.                                                                                                                                                                                                                  |
| qualifyingConditions | array     | Array of different conditions like KPI, parameters, and more.                                                                                                                                                                                                                       |
| conditionExpression  | string    | Name of the condition that is passed in `qualifyingConditions`.                                                                                                                                                                                                                     |
| allocationRule       | array     | Set the condition to generate the promotional points.                                                                                                                                                                                                                               |
| limits               | obj       | Set the maximum number of promotional points issued to a customer during a specific promotion period. Set the maximum number of times points can be issued to a customer during a promotion period. Set the total number of points that can be generated during a promotion period. |

<aside class="notice"> Parameter marked with * is mandatory. </aside>
