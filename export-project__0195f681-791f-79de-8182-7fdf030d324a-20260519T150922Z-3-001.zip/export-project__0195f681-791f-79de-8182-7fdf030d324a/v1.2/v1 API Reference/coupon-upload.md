---
title: "Coupon Upload"
slug: "coupon-upload"
excerpt: "This resource consists of APIs related to batch coupon operations."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 17 2022 06:16:49 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 17 2022 06:21:29 GMT+0000 (Coordinated Universal Time)"
---
## Host URLs

- **India**: <https://intouch.capillary.co.in>
- **Apac2**: <https://apac2.intouch.capillarytech.com>
- **EU**: <https://eu.intouch.capillarytech.com>
- **China**: <https://intouch.capillarytech.cn.com>
