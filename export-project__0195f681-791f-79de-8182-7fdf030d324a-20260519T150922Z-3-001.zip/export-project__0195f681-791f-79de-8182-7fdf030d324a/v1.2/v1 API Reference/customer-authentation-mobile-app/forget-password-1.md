---
title: "Forget Password"
slug: "forget-password-1"
excerpt: "Lets you set a new password if the customer has lost or forgot password. This is applicable only for brands for which password is enabled. You need to first generate sessionId and then use it in password/forget. After setting a new password, the customer customer needs to authenticate again - \n\n1. Generate token, \n2. Generate OTP, and \n3. Validate OTP."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 10 2022 07:24:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 13:16:29 GMT+0000 (Coordinated Universal Time)"
---
