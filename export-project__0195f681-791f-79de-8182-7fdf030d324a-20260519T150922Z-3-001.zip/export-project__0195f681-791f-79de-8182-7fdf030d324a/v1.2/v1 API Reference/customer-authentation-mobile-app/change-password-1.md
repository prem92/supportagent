---
title: "Change Password"
slug: "change-password-1"
excerpt: "Lets you modify the current password of a customer. This is applicable only for brands for which password is enabled."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 10 2022 07:19:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 13:16:59 GMT+0000 (Coordinated Universal Time)"
---
