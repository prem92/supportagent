---
title: "Regenerate Authentication Token"
slug: "regenerate-authentication-token-1"
excerpt: "Generates authentication token using auth key or expired token generated in `otp/validate` API. By default, a token is valid for 15 minutes. You can use this API only for orgs in which password based authentication is enabled."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 10 2022 07:10:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 13:17:20 GMT+0000 (Coordinated Universal Time)"
---
