---
title: "Generate OTP"
slug: "generate-otp-1-1"
excerpt: "Issues OTP to the customer’s mobile number/email ID using the `sessionId` generated through the `token/generate` API.\n\nThere is a limit in the number of OTPs a customer can generate in a day. If you wish to increase or decrease the limit, contact the Platforms team."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 10 2022 06:33:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 13:18:16 GMT+0000 (Coordinated Universal Time)"
---
