---
title: "Validate OTP"
slug: "validate-otp-2"
excerpt: "Validates the OTP generated through the `/otp/generate` API. Applicable for mobile app."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 10 2022 06:48:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 13:18:00 GMT+0000 (Coordinated Universal Time)"
---
