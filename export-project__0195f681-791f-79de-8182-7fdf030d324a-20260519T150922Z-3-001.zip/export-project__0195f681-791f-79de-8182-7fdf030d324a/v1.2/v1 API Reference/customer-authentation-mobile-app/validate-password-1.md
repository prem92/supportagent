---
title: "Validate Password"
slug: "validate-password-1"
excerpt: "Validates the password of an existing user account and generates the access token and key. The token is valid for 15 minutes by default. You can use the key to regenerate token."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 10 2022 06:51:47 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 13:17:44 GMT+0000 (Coordinated Universal Time)"
---
