---
title: "Get Uploaded Coupons' Status"
slug: "get-uploaded-coupons-status"
excerpt: "Retrieves the status of a coupon upload job."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 17 2022 09:09:29 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 17 2022 09:09:29 GMT+0000 (Coordinated Universal Time)"
---
