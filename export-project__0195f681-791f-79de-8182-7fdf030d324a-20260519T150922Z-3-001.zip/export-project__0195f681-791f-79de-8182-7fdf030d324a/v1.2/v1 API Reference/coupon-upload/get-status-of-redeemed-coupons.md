---
title: "Get Status of Redeemed Coupons"
slug: "get-status-of-redeemed-coupons"
excerpt: "Retrieves the status of the uploaded coupon redeem job a coupon series."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 17 2022 09:10:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 17 2022 09:10:50 GMT+0000 (Coordinated Universal Time)"
---
