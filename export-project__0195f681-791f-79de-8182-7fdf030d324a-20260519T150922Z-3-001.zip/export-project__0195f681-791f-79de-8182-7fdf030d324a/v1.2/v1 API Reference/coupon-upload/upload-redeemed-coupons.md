---
title: "Upload Redeemed Coupons"
slug: "upload-redeemed-coupons"
excerpt: "Lets you upload coupons that are redeemed for a coupon series in bulk. \n\nYou can also import coupons (Capillary CRM) that are redeemed externally using an endpoint."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 17 2022 07:09:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 17 2022 08:49:12 GMT+0000 (Coordinated Universal Time)"
---
### Request Body Parameters

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Datatype",
    "h-2": "Description",
    "0-0": "customerIdentifier\\*",
    "0-1": "enum",
    "0-2": "Unique identifier of the customer to update redeemed coupons. Values: `MOBILE`, `EXTERNAL_ID`, `EMAIL`, `USER_ID`.",
    "1-0": "couponIdentifier\\*",
    "1-1": "enum",
    "1-2": "Coupon identifier used. Value: `COUPON_ID`, `COUPON_CODE`.",
    "2-0": "file\\*",
    "2-1": "file",
    "2-2": "The CSV file that contains information of redeemed coupons. Each row in CSV file can contain following fields(columns marked with \\* are mandatory).<br/><br/> -  **Customer identifier\\*** : Field used to identify the customer, it can be userId, mobile, email or externalId. (userId will have more preference over the other customer identifiers, in case of multiple values)<br/> - **Coupon identifier\\*** : Field used to identify the redeemed coupon, It can be couponId, couponCode. (couponId has more preference over couponCode in case of multiple values)<br/> - **Redeemed date in milliseconds\\*** : Coupon redeemed time in Epoch<br/> - **Redeemed at\\*** : Coupon redeemed till’s Id<br/> - **Bill Id** : Transaction Id<br/> - **Bill Number** : Transaction Number Details.<br/><br/>**Sample file content:**<br/> - _File content sample 1_:<br/>       redeemed date in millis, redeemed at, user id, coupon id, bill id, bill number, details<br/>        1603128622000,50015497,23599838,23456,1603128596000<br/>       luci_auto_15039.<br/> - _File content sample 2_:<br/>       redeemed date in millis, redeemed at, mobile, coupon code ,bill id, bill number, details<br/>       1603128622000,50015497,9876543210,ABCDEF1,1603128596000<br/>       luci_auto_15039",
    "3-0": "uploadHeaders\\*",
    "3-1": "int",
    "3-2": "The sequence (starts from 0) of the columns in the attached csv file. This field accepts stringified JSON. <br>Key name for columns are as follows:<br/><br/>Key name for the columns are as follows<br/> - **Customer identifier\\*** : Key name for this field varies according to the customerIdentifier param.<br/>       MOBILE : mobile<br/>       EXTERNAL_ID: externalId<br/>       EMAIL: email<br/>       USER_ID: userId<br/> - **Coupon identifier\\*** :  Key name for this field varies according to the couponIdentifier param.<br/>       COUPON_ID: couponId<br/>       COUPON_CODE: couponCode<br/> - **Redeemed date in milliseconds\\*** : redeemedDateInMillis<br/> - **Redeemed at\\*** : redeemedAt<br/> - **Bill Id** : billId<br/> - **Bill Number** : billNumber<br/> - **Details** : details<br/><br/>For the above file samples, the uploadHeaders will be -<br/>       _Sample 1_ - {'redeemedDateInMillis': 0, 'redeemedAt': 1, 'billNumber': 5, 'couponId': 3,<br/>       'userId': 2, 'billId': 4, 'details': 6}<br/>       _Sample 2_ - {'redeemedDateInMillis': 0, 'redeemedAt': 1, 'billNumber': 5, 'couponCode': 3,<br/>       mobile: 2, 'billId': 4, 'details': 6}",
    "4-0": "Details",
    "4-1": "string",
    "4-2": "Any additional details or notes to capture for redeemed coupon upload."
  },
  "cols": 3,
  "rows": 5,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


<aside class="notice"> All parameters marked with * are mandatory. </aside>
