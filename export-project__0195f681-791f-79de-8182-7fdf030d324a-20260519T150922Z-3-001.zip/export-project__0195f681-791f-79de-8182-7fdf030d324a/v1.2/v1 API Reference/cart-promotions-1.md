---
title: "Cart Promotions"
slug: "cart-promotions-1"
excerpt: "These are special promotions that are applicable to cart and catalog items - promotion engine. This category contains APIs to manage and retrieve cart and catalog promotions."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 17 2022 06:02:27 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 22 2022 06:19:41 GMT+0000 (Coordinated Universal Time)"
---
To use cart promotions, you need to first generate an authentication token as an admin using the `/arya` API and then use the **BearerToken** authentication to make API calls.

You can also pass the token as header. For example, access token is xyz, then pass the header `AUTH-COOKIE` with value Bearer xyz

Note that only admins can make these promotion API calls.
