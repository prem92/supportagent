---
title: "Create Promotion"
slug: "create-promotion-1"
excerpt: "Lets you create any type of cart/catalog promotion."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 17 2022 08:41:18 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 22 2022 12:30:29 GMT+0000 (Coordinated Universal Time)"
---
## Request Body Parameters

| Parameter                        | Datatype                          | Description                                                                                                              |
| -------------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| name                             | string                            | Unique name of the promotion.                                                                                            |
| orgId                            | int                               | Unique ID of the org associated with the promotion.                                                                      |
| priority                         | int                               | Priority of the promotion. 1 is for have highest priority and the highest value will have the least priority.            |
| active                           | boolean                           | Pass `true` to activate the promotion, `false` to make make it inactive.                                                 |
| messageLabel                     | ; - deascription of the promotion |                                                                                                                          |
| type                             | enum                              | Type of the promotion. Value: `POS`, `CUSTOMER`, `EARNING`, `CODE`, `REWARD`.                                            |
| condition.type                   | enum                              | Type of the condition. Value: `CART`, `PRODUCT`, `COMBO_PRODUCT`, `TENDER`.                                              |
| condition.cartCondition.kpi      | enums                             | Condition defined for the KPI. Value: `SUBTOTAL`, `ITEMCOUNT`.                                                           |
| condition.cartCondition.operator | enums                             | Operator used in the condition. `EQUALS`, `GREATER_THAN`, `GREATER_THAN_OR_EQUAL`, `LESS_THAN`, `LESS_THAN_OR_EQUAL`.    |
| condition.cartCondition.value    | string                            | Value of the condition.                                                                                                  |
| action.type                      | enums                             | Type of the action or reward. Value: `FIXED_PRICE`, `CART_BASED`, `PRODUCT_BASED`, `FREE_PRODUCT`, `TENDER`, `PER_UNIT`. |
| action.cartBasedAction.type      | enum                              | Type of the action or reward. Value: `PERCENTAGE`, `ABSOLUTE`.                                                           |
| action.cartBasedAction.value     | string                            | Value of the action type or reward                                                                                       |
| earnLimitedToSpecificAudience    | boolean                           | Whether the customer needs to be earned before unlock                                                                    |
| mode                             | enum                              | Mode of the promotion created. Values: `DISCOUNT`, `PAYMENT_VOUCHER`                                                     |
| maxIssuancePerCustomer           | float                             | Max promotion that can be issued to a customer                                                                           |
