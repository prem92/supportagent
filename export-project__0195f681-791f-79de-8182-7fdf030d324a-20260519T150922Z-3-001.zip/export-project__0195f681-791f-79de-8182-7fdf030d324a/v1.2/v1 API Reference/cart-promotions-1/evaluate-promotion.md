---
title: "Evaluate Promotion"
slug: "evaluate-promotion"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 17 2022 07:24:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 17 2022 07:29:45 GMT+0000 (Coordinated Universal Time)"
---
## Request Body Parameters

| Parameter         | Datatype  | Description                       |
| ----------------- | --------- | --------------------------------- |
| amount            | double    |                                   |
| customerId        | long      | Unique ID of the customer.        |
| cartItems         | array-obj | Details of the promotion          |
| referenceId       | string    | Reference ID of the promotion.    |
| sku               | string    | SKU of the product.               |
| amount            | double    | Price of the product.             |
| qty               | int       | Quantity of line-items purchased. |
| discount          | double    | Discount applied                  |
| appliedPromotions | array     |                                   |
