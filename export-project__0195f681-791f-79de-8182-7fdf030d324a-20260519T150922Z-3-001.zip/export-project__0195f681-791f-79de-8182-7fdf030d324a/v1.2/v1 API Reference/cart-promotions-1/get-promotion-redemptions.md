---
title: "Get Promotion Redemptions"
slug: "get-promotion-redemptions"
excerpt: "Retrieves all promotion redemptions."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Jun 20 2022 05:06:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 20 2022 05:06:57 GMT+0000 (Coordinated Universal Time)"
---
