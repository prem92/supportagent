---
title: "Get Promotion Settings"
slug: "get-promotion-settings"
excerpt: "Retrieves Cart and Catalog settings configured for the org."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 17 2022 06:22:27 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 17 2022 06:22:27 GMT+0000 (Coordinated Universal Time)"
---
