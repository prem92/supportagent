---
title: "Set Promotion Settings"
slug: "set-promotion-settings"
excerpt: "Lets you configure org level Cart and Catalog settings."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 17 2022 06:20:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 17 2022 06:20:05 GMT+0000 (Coordinated Universal Time)"
---
