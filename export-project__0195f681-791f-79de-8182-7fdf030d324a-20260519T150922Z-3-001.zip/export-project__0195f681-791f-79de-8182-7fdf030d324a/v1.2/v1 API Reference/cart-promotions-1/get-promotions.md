---
title: "Get Promotions"
slug: "get-promotions"
excerpt: "Retrieves all cart and catalog promotions created for the org."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Jun 22 2022 06:21:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 22 2022 06:21:05 GMT+0000 (Coordinated Universal Time)"
---
