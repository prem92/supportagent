---
title: "Get Promotion Details"
slug: "get-promotion-details-1"
excerpt: "Retrieves the promotion details."
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Jun 17 2022 10:42:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 17 2022 10:42:54 GMT+0000 (Coordinated Universal Time)"
---
