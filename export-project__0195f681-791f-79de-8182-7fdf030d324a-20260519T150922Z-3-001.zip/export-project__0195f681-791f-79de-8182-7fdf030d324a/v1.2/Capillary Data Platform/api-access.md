---
title: "API access"
slug: "api-access"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 09 2022 07:27:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 04:54:03 GMT+0000 (Coordinated Universal Time)"
---
InTouch lets you enable or disable Basic Authentication and create API clients for OAuth-based authentications.

## Enable or Disable Basic Authentication for an org

To enable or disable basic authentication for an org, follow these steps. By default, Basic Authentication is enabled for the org. As only Till ID and password are required for Basic Auth, you do not see additional configuration options. For details on how to create till credentials, see set up org hierarchy, and for basic authentication process see authentication.

- Log on to InTouch of your cluster.
- Navigate to the Profile icon > Organization Settings > Tools > Authentication.
- Click Modify to create a new client (token key and secret) for the org.

![](https://files.readme.io/0a1d6d6-orgg.png "orgg.png")

- To enable basic auth, set the Enable Basic Authentication to Yes.\*

## Create API Clients

When you create client accounts, you will get client key and client secret which can be used for OAuth. You can also generate access tokens with the generated client key and secret pair for more secured integrations.

- On the API Client page, click Register.

![](https://files.readme.io/b458f7d-register.png "register.png")

- In Client name, enter a name for the client.

![](https://files.readme.io/70190d6-client.png "client.png")

- In Description, enter a short description of the client.
- In Token expiry duration, set the default expiry (in minutes) for the tokens created for the client. To modify, drag the pointer to the required position on the line.
- In Access Permission, select the desired access that you want to provide for the current client - Target Groups: Related to target loyalty APIs; Transaction: Related to transaction API; All: For all other APIs.

<!---->

- None: To restrict both read and write access to the respective APIs. This is the default value.
- View only: Select this to provide only read access to the respective APIs.
- Modify: Select this to provide both read and write access (add/update) to the respective APIs.

<!---->

- In Select your organization till, choose the Till that you want to associate to all the POST API calls.
- Click Next. You will see the Client key and Client secret generated for the client.

![](https://files.readme.io/11dd3fd-clie.png "clie.png")

- Copy the Client key and client secret and use it for authentication (OAuth). Using these details, you can also generate access token through API as mentioned in the next section (Step 2: Generate Access Token).

![](https://files.readme.io/9ba7864-toktn.png "toktn.png")

- Click Done to close the screen.
- To create more API client accounts, use New API Client.

![](https://files.readme.io/825679d-clienttt.png "clienttt.png")

_After the client key and secret are generated, if you exit the API Credentials page, you cannot access the client secret again for that client._ 

![](https://files.readme.io/916d8e7-demo.png "demo.png")
