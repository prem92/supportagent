---
title: "Member Care Old UI"
slug: "member-care-old-ui"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 10:30:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 08:05:04 GMT+0000 (Coordinated Universal Time)"
---
Member Care helps you manage your customer database in an efficient manner and resolve issues customer issues. It helps you take data driven decisions using a complete data toolkit.

Member Care is a web application that lets you manage and view customer accounts, goodwill requests, identifier change requests, and tickets. You can also view customer activities, behavioral events, and interactions.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5f52750-85iOpHuvOeN2Ivao_ZrUeiaKoUKh_XuLgw.png",
        "85iOpHuvOeN2Ivao_ZrUeiaKoUKh_XuLgw.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


 The module lets you do the following:

- Search for customers using names or identifiers across sources such as InStore, Facebook, WeChat, MartJack, and WebEngage. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/66da19f-hE7a3Ld1W7NEt6dg1HhK8ZMeackeneqduQ.png",
        "hE7a3Ld1W7NEt6dg1HhK8ZMeackeneqduQ.png",
        446
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e9670cd-uXi5NTOr3kBIKQLdNHSCaPz_qtvuSe-80w.png",
        "uXi5NTOr3kBIKQLdNHSCaPz_qtvuSe-80w.png",
        1263
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- Register a new customer - Add the registration page configured for your microsite on Member Care to register and update customers through Member Care. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/73f9c9d-UIKoQZr9MJWR0BPNAtn01IE0zKKDzOs3eA.png",
        "UIKoQZr9MJWR0BPNAtn01IE0zKKDzOs3eA.png",
        948
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- View a customer's activity and interaction information such as transactions, points, coupons, and communications. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/001897b-fRQKOlHE0qvwnuvilgtiix8OGm8FLndfMA.png",
        "fRQKOlHE0qvwnuvilgtiix8OGm8FLndfMA.png",
        1105
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- Manage identifier change and account merge requests - Create identifier change requests such as for change in mobile number/email ID/external ID, account merge, and mobile number reallocation.  Also, process change requests on Member Care. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b13c7eb-WtSRnBi-6E9w5zdAcgU6tOk2gHSyVMiLfg.png",
        "WtSRnBi-6E9w5zdAcgU6tOk2gHSyVMiLfg.png",
        1316
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ee9794a-POVKgwy6kn5W5cF_ALrYxG_-u-gkdUrMsw.png",
        "POVKgwy6kn5W5cF_ALrYxG_-u-gkdUrMsw.png",
        1077
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- Ensures better safety for identifier change requests with OTP-based verification. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1a1b4e6-My_F110TQgWC9sc7TSW21rzU5QhqNb8ebA.png",
        "My_F110TQgWC9sc7TSW21rzU5QhqNb8ebA.png",
        387
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- Manage customers' subscriptions and fraud status. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/762ff32-88gnnzj3E99UYBBl4SSP7_uenSzgJtn0Qg.png",
        "88gnnzj3E99UYBBl4SSP7_uenSzgJtn0Qg.png",
        779
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- Issue cards from an active card series to a customer. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c609b4d-iWYqxH3SsAyqc3r8R8prKu5KNKFntfVo8Q.png",
        "iWYqxH3SsAyqc3r8R8prKu5KNKFntfVo8Q.png",
        1102
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- View details of cart and catalog promotions of a customer. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c5e5ef7-fVh7qINGcTArLt50wQFz17re14zQt_0ytw.png",
        "fVh7qINGcTArLt50wQFz17re14zQt_0ytw.png",
        1070
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- View loyalty events that are pending or failed and re-initiate the process through Member Care. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/75a4793-8SJT8sX6CRPxKSQEeXZ1xGQLQNF_kiYuVg.png",
        "8SJT8sX6CRPxKSQEeXZ1xGQLQNF_kiYuVg.png",
        1103
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- Issue Goodwill points and coupons to loyalty program customers. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/28c9704-zNo5IHqkCWrIN-NmmwI87I9fNQrMeH_yrw.png",
        "zNo5IHqkCWrIN-NmmwI87I9fNQrMeH_yrw.png",
        1097
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


- Search the details of coupons issued to customers. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/083aee1-pKnmmG_XEa9FkQjBJlY_rLYnnDGHI6ybUA.png",
        "pKnmmG_XEa9FkQjBJlY_rLYnnDGHI6ybUA.png",
        501
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]
