---
title: "Feedback Management"
slug: "feedback-management"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Apr 07 2022 16:48:11 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu May 12 2022 10:52:44 GMT+0000 (Coordinated Universal Time)"
---
## Introduction

Capillary's Feedback Management(CFM) system helps their clients in managing customer feedback. CFM is a process that is based on the systematic collection of customer feedback data, the analysis of the data, and defined dissemination and follow-up actions. With the CFM in place, it becomes easier for the business owners with insight that further can be used to improve their business, products, and/or overall customer experience.

To access Feedback Management System, log in to **InTouch** and navigate to the **Workbench** page. Click on **Feedback Management** in the left panel. You can see the following options:-

- Add Ticket
- Search Ticket
- Upload Ticket
- Reports
- CCMS reports 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b8f04ab-fm1.png",
        "fm1.png",
        1347
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


## Add Ticket

1. To add a ticket, click on **Feedback Management** (**InTouch Workbench** page). Click the **Add Ticket** option, the following page appears

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ff69783-u2yj8ZYiG-OGSmcyvamxAv_Hmascb0_V6w.png",
        "u2yj8ZYiG-OGSmcyvamxAv_Hmascb0_V6w.png",
        1372
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


2. Clients can add a new ticket for their customer feedback. This ticket can be used for future references and also can be used by customers in checking the status of their raised ticket. Few fields are mandatory that need to be filled and the remaining are custom fields, for example, **feedback_anniversary**, **the purpose of visit**, etc. Once all fields are filled, click on **Submit**.

Find below the description of the mandatory fields:

| Mandatory Field Name | Description                                                                         |
| :------------------- | :---------------------------------------------------------------------------------- |
| Status               | Select from the drop-down the required options (OPEN, PARTIAL, CLOSE)               |
| Department           | Select from the drop-down the department (APPARELS, BOOKS, HOME-NEEDS)              |
| Priority             | Select either low, medium, or high priority from the drop-down.                     |
| Subject              | The issue of the complaint is the subject for example Wrong Size, Fade Colour, etc. |
| Details              | Write a description giving specific of the complaint raised.                        |
| Mobile Number        | Enter the customer's registered mobile number.                                      |
| Customer Name        | Enter the name of the customer.                                                     |
| Email Id             | Enter registered email id.                                                          |
| Assigned To          | Assign it to respective department heads or person concerned.                       |
| Due Date             | Provide a due date for the complaint to be resolved.                                |

## Search Ticket

1. To **SearchTicket**, click on **Feedback Management** (InTouch **Workbench**). Click the **Search Ticket** option, the following page appears:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1c631e2-fm3.png",
        "fm3.png",
        1345
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


2. The fields are shown above in the screenshot need to be filled(**Status**, **Priority**, **Department**, **Due Date till-from**, **Created Date**, etc.) to search for a particular ticket of a customer. Search can further be done by selecting the custom field option. You can also view and edit the ticket using the **Search Issue Download** option. See the figures below for better clarity.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4684e64-fm4.png",
        "fm4.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cf17d3b-fm5.png",
        "fm5.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


3. The tickets can further be edited. Click on the ticket and you will be navigated to the following page:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/302ff13-fm6.png",
        "fm6.png",
        512
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


## Upload Ticket

1. Tickets can be uploaded either using CSV or by adding **customer attributes**. To Upload a ticket using either of the options, go to **Upload Ticket** under **Feedback Management**, the following page appears:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d9bdfc7-fm7.png",
        "fm7.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


## Reports

1. To access **Reports**, go to InTouch Workbench > **Feedback Management**. 
2. Click the **Reports** option, the following page appears:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cca7df3-fm8.png",
        "fm8.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


On the Reports page, you need to do the following:

- Enter the **Last Updated Date Between \_And**
- Enter the **Created Date Between_And**
- Select from the drop-down whom to assign under **Assigned to**
- Select **Yes/No** under **Include Inactive**
- Check the box either for **Download as CSV** or **Download Revision Log as CSV**
- Select **Custom Fields**  
  On the Reports page, you can further see the **Master Table** as well as **Revision Logs** for a complete analysis of the tickets raised. See the following figures for better clarity:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5370859-fm9.png",
        "fm9.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/47a19c7-f10.png",
        "f10.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


## CCMS Reports

To see **Customer Complaint Management Reports**(CCMS), click on **Feedback Management** which is located on the left panel of the Intouch **Settings** page. Click on the **CCMS** option, the following page appears:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c12f8e8-f11.png",
        "f11.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


In CCMS reports, you can view the status, department, dates, etc. with regards to the ticket. It will also give an overview of the issue and its related details. Further, you can also get details about the overall escalation in the **Overview Escalation**. See the figure below:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b117190-f12.png",
        "f12.png",
        1368
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]
