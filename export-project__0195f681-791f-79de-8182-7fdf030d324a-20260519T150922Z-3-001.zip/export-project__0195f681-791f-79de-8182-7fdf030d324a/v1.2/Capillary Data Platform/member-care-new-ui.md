---
title: "Member Care New UI"
slug: "member-care-new-ui"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Apr 08 2022 06:29:59 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 24 2022 05:24:15 GMT+0000 (Coordinated Universal Time)"
---
## Introduction

We put some fresh paint to Member Care, starting with the most frequently used component - the Customer Single View (CSV) page. The new design of the CSV page offers a cleaner, and better organized view of customer information providing an intuitive user experience.

### Improvements

The new UI brings in consistency with other Capillary products with the following improvements.

- Reduced cognitive load as information is presented in an organized, progressive manner.
- Designed with the view of enabling customization in the future.
- A persistent left side bar highlighting key aspects of a customer's profile such as sources, identifiers, loyalty slab information and recent events.
- New, easy to access pages for viewing loyalty information, customer events, incentives and interactions.
- Better visualization of points data using the recently launched [Ledger API](https://docs.google.com/document/d/1VyKPazJ-hzOWIxP-PA4bz0UrzRI5-LOaQcwfiwGIcbk/edit?usp=sharing)-driven points data.
- Useful additions including slab renewal, slab upgrade, cards and other widgets.

### Limitations

As this is the first step in the Member Care refresh journey, we would keep adding components in phases. Hence, you might not see all features of the previous version.

- Actions - Identifier change, goodwill points/coupons issual, mobile reallocation, account merge, tag transactions, fraud status change, customer status change, subscription status change, test and control status change, card linking/delinking, target value change and card status change.
- From the More Information section in the current UI, the following will not be present in the first release of the new CSV UI - Leads, Audit Trails, B2B Loyalty, Points > Slab Change Log, Points > Expiry Schedule, Points -> Historical Points Log 
- User Groups v1 and v2 information and events.
- Request management, Tickets management, coupons search and other items in Member Care that are not related to the CSV.

## Switching from old UI to new UI

#### 1. Default Behavior when Member Care new UI is enabled for an org -

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/dfe3269-1.gif",
        "1.gif",
        1342
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


#### 2. Switching to old UI from new Customer Search page -

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f03ebf1-2.gif",
        "2.gif",
        1345
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


#### 3. Clicking on **Search **> **Customer **from the Old UI will take you back to new Customer Search page -

![](https://files.readme.io/7bf007a-3.gif "3.gif")

If you want to access the old **Search **> **Customer **page, you will have to go to the new **Customer Search** page and switch back. 

You can use this URL: {host}/memberCare/search/Customer?oldFlow=true

_Example_: <https://eucrm.cc.capillarytech.com/search/Customer?oldFlow=true>

> 📘 You have to use oldFlow=true parameter to directly land on the old UI search page. If you use the same URL without the oldFlow parameter, you will be redirected to the new Customer Search page.

#### 4. We have also implemented seamless switching at Customer Single View (CSV) as well. You can switch to old CSV by clicking on the switch icon on top right as shown below -

![](https://files.readme.io/6976170-4.gif "4.gif")

#### 5. You can switch back to new CSV from old CSV as well -

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ada5a00-5.gif",
        "5.gif",
        1349
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


#### 6. If you want to share a profile link with someone and  want to point to the old UI, the oldFlow=true parameter has to be used again -

For example:

<https://eucrm.cc.capillarytech.com/memberCare/search/Customer?id=172076358>

This is the URL for the old CSV of a BUKL_T customer. When you open this, it will automatically take you to the new CSV even though the URL points to the old UI.

However, if you add oldFlow=true to the same URL, you will be taken to the old CSV directly:

<https://eucrm.cc.capillarytech.com/memberCare/search/Customer?id=172076358&oldFlow=true>

#### 7. To access the new UI URL directly, just enter

{host URL}/member-care/ui/

To see customer details, it would be {host URL}/member-care/ui/{userId}

Example: <https://eucrm.cc.capillarytech.com/member-care/ui/172076358>

#### 8. This switching behavior is applicable only for Search > Customer and CSV pages. Once you switch to the old UI, everything else will work as is.
