---
title: "Message management"
slug: "message-management"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 20:02:14 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 05:17:14 GMT+0000 (Coordinated Universal Time)"
---
There are conglomerate orgs that operate different verticals that will have a separate loyalty program for each org unit.  There are also orgs that run loyalty programs based on card series.  An org may also partner with various other companies and have different partner-loyalty programs with different partners.

In such instances, a customer could be part of one or more loyalty programs.

Engage+ allows segmenting customers of a particular loyalty program and then targeting them by creating personalized communications. This will help you to drive KPIs such as cross-vertical sales, and boost average transaction value, and transaction frequency.

A message consists of title, scope, and purpose. As you can create multiple messages for a campaign, it is recommended to use appropriate and different titles for each message for future references.

To create a new message, follow these steps. 

1. Add a Message
2. Add audience
3. Add Creative
4. Add Incentive
5. Add schedule
6. Send for approval

> 📘 The scope selected while creating a new message is auto-applied to the filters.
