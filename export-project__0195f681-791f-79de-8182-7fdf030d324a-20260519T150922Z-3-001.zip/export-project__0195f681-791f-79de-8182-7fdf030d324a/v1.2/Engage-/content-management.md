---
title: "Content management"
slug: "content-management"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 20:02:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 05:21:15 GMT+0000 (Coordinated Universal Time)"
---
Content Management lets you manage all the readily available content used for different channels like mobile push, SMS templates, and more. You can also create the content from scratch and save it for future usage.

Content management is the process of collection, delivery, retrieval, governance, and overall management of information in any format. The term is typically used in reference to administration of the digital content lifecycle, from creation to permanent storage or deletion. The content involved may be images, video, audio and multimedia as well as text.
