---
title: "Referral campaign"
slug: "referral-campaign"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jul 26 2022 06:07:07 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jul 26 2022 07:22:33 GMT+0000 (Coordinated Universal Time)"
---
The Referral Campaigns help you to acquire new customers by utilizing your existing customers' network. The existing customers can refer their friends and contacts to visit your store. You can configure your referral campaigns to reward both the referrer (the existing customers who had provided the email IDs or phone numbers of their friends) and the referrals (the friends of existing customers to whom the invitation to visit the store had been sent) when the referrals enroll into your loyalty program or make transactions.

## Create referral campaign

To create referral campaigns, follow these steps-

1.On the Campaigns Dashboard, click the **+ New Campaign** button.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ca632db-CampaignDashboard.png",
        "CampaignDashboard.png",
        1368
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


2. On the **New Campaigns **screen, do the following: 

   1. In **Campaign Type**, choose _Referral_. 
   2. In **Campaign Name**, type a name for the new campaign.
   3. In **Description**, type a short description of the campaign.
   4. In** Valid Between**, using the Calendar option, set the campaign duration - start date and end date of the campaign.
   5. In **Campaign Objective**, select the objective from the drop-down list. See figure below.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9f804a0-ReferralCampaign2.png",
        "ReferralCampaign2.png",
        668
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


The table below provides descriptions of each category of  Campaign Objective.

| Category      | Values                              | Help Text                                                                                                                            |
| :------------ | :---------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------- |
| Acquisition   | General                             | Acquire new transacting customers from a given acquisition channel                                                                   |
|               | Referral                            | Acquire new transacting customers through referrals by an existing customer                                                          |
| Delight       | Birthday/Anniversary                | Delight customers with incentives around life events to encourage them to transact by redeeming points or coupons                    |
|               | Feedback/Survey                     | Delight customers with incentives and encourage them to take a survey or provide feedback                                            |
| Informational | Customer Joinee Program             | Encourage new loyalty customers to know more about the program benefits and the brand. Increase in repeat purchase frequency and LTV |
|               | Store Opening (Awareness)           | Inform customers nearby about a new store opening to boost transactions at the store                                                 |
|               | Product Launch                      | Inform potentially interested customers about a new product launch to boost sales for the newly launched product                     |
|               | Season/Arrivals                     | Inform potentially interested customers about new collections/stock in the stores to boost sales                                     |
|               | Brand awareness, Informercial       | Brand building exercise and information sharing with customers to increase overall customer engagement with the brand                |
| Promotional   | Up sell                             | Promotional campaign to encourage people to buy higher volumes of the same SKUs - higher count per SKUs                              |
|               | Cross-Sell                          | Promotional campaign to encourage people to buy different SKUs - higher count of unique SKUs                                         |
|               | Sales Booster                       | Promotional campaign to encourage people to buy more - higher ABS and ABV                                                            |
| Miscellaneous | Heavy Discount Sale (includes EOSS) | Boost sales during any heavy discount periods including festivals and EOSS                                                           |
|               | Frequency Enhancer                  | Encourage lower frequency visitors to transact more frequently                                                                       |
|               | Lapsation                           | Reactivate lapsed customers and encourage them to transact                                                                           |

6. In** Incentivize Referrer**, choose when to incentivize the referrer: 

   - Dynamically as he reached the criteria: To issue incentives dynamically as and when the configured criterion is met.
   - At the end of the campaign: To issue incentives at the end of the campaign period. 
7. Select other additional options:

   - Select **Disable Test-Control** to include all the customers eligible for this campaign. (Normally every campaign will have a control group (for example 10% of the eligible members who are randomly selected) to whom the marketing communication is not sent. The control group is essential to measure profits.)
   - Select **Make Default for POS **to make this campaign default in PoS. When you enable this option, also choose how to send the referrals (by email or SMS).
   - Select Invite Registered Customer to invite referrals who had already registered. 
   - Select Register Customer Online to enable registering customers online using the Social App and provide the registration link in Link to Microsite.  
     4 . Click **Create Campaign**. After saving the Campaign, you need to configure the SMS or Email message.

***

## Configure SMS & email messages

### Configure Email Message

1. In Messages, navigate to the Email tab.
2. Select a template from the available template list.
3. Click Edit Message to customize the content of the message.
4. Click Review and Save. A Review screen appears.
5. Click Save after reviewing the message.

### Configure SMS

1. In Messages, navigate to the SMS tab.
2. Create the text message using the available tags. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/556a117-SMS.png",
        "SMS.png",
        1368
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


2. After creating the message, click Review and Save. A Review screen appears.
3. Click Save after reviewing the message.
4. Proceed to the Rewards section.

***

## Configure incentives

### Coupon Rewards

1. In the Rewards Settings page, define the rewards for both the referrers and the referrals. 
2. Click Incentives to Referrer to define the rewards for the referrer - the existing customers who had provided the referrals (the email IDs or phone numbers of their friends). 
3. Click Incentives to Referee to define the rewards for the referees - the friends of existing customers to whom the referral had been sent.

#### Incentives to Referee

Referees are the friends of existing customers to whom the referral had been sent. 

- In Actions, define whether you want to reward the referee for registering to the loyalty program or on completing a transaction in the store.

#### Incentives to Referrer

Referrers are the existing customers who had provided the referrals (the email IDs or phone numbers of their friends). In Actions, define when to reward the referrer (when their friends register or complete a transaction). You can also choose the number of registrations or transaction that have to be done before you reward the referrer.

#### Configuring Coupons

After configuring reward settings, attach the coupons to the referral campaign. To know how to create coupons, see [Create coupons](doc:create-coupons).

### Points rewards

You need to configure Points Rewards using Loyalty. First, create a points allocation strategy, with Module using the strategy as Campaign. For more details, see [Points strategy].

***

## Configure events

You then need to configure loyalty rules (EventsView) as explained in the following - 

- Events supported: CustomerRegistration, TransactionAdd, and pointsAllocation.

   In rulesets, navigate to the set to configure the rule expression and define your rule expression and action.

#### Rule expression

- To incentivize on referee registration count use the attribute

   referrerCode.refereeRegCount

- To incentivize on referee transaction count

   referrerCode.refereeTxnCount

#### Actions:

- Award points to referrer: Choose to issue points to the referrer on satisfying the configured condition. Then, choose the points allocation and expiry strategy accordingly.
- Award points to referee: Choose to issue points to the referee on satisfying the configured condition. Then, choose the points allocation and expiry strategy accordingly. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/87012dd-referrer.png",
        "referrer.png",
        190
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/55fdc98-referrer2.png",
        "referrer2.png",
        779
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]
