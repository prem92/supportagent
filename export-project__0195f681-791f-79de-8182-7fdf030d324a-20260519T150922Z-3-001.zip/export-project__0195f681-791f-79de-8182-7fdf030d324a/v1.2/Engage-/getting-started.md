---
title: "Getting started"
slug: "getting-started"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 10:32:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 05:10:56 GMT+0000 (Coordinated Universal Time)"
---
## Engage+ Overview

Capillary Engage+ is a marketing automation solution that helps to create significant and personalized multi-channel marketing campaigns. You can create a campaign for different marketing objectives, such as Sales promotion, New Store opening, Brand anniversary, Birthday, and many others.

Engage+ lets you reach out to your customers over direct channels such as email, SMS, WhatsApp, Line and social media channels such as Facebook. You can also trigger messages to InStore outlets. It is equipped with AI powered filters for a more personalized and smart targeting.

This guide describes how to get started with Engage+.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f365277-OU_FIlter.png",
        "OU FIlter.png",
        1064
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


1. **Campaign overall performance dashboard**: Shows the overall performance of campaigns for the last 7 days, 1 month, 3 months, and 6 months.
2. **Search Campaign**: Enter the **campaign name** in the search box.
3. **Filters campaigns by duration**: Click the calendar icon to enter the duration in **Start date** and **End date**.
4. **OU Filter**: Filter campaigns created for different org units.
5. **Filter campaigns by status, marketing objective, and/or created by**: Click on the **filters** icon for advanced filters, choose the desired options, and click **Apply**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5652045-FIlterCampaigns.png",
        "FIlterCampaigns.png",
        340
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


1. **Campaign status**: Select Campaign status and choose from the following options.

- Live Shows: ongoing campaigns.
- Upcoming: Shows future campaigns.
- Lapsed: Shows the past or inactive campaigns. 

2. **Marketing Objective**: The marketing objective is an option to define the purpose of your campaign. For example, Boost sales, Acquire customers, Promote specific products, and so on. To know more about marketing objectives, see [Marketing Objective](https://docs.capillarytech.com/docs/marketing-objective).
3. **Created by**:  This option allows you to filter campaigns created by a specific user. Select the user in the drop-down box.

## Role-based access

We can provide access to org users based on their access to each of the following actions or components.

- [Create Campaign](doc:create-campaign)     
  - Set campaign name and duration
  - Add message - this includes audience, incentives, message content
  - Schedule message 
- Get the message approved
- View campaign reports post execution

## Key Social Media KPI Definitions

### Match Count

Count of customers who are available on Facebook with the same mobile or email, as present in our target list. (Approximated to the nearest 10)

- **Reach**: Unique users reached through the campaign.
- **Impressions**: Total number of exposures to your advertisement.  One person can receive multiple exposures over time.
- **Clicks (All)**: Total number of clicks received on the links, buttons, etc.
- **Amount spent**: Amount charged by Facebook for running the ad campaign
- **ROAS**: Return on Ad Spend. Number of times the ad spend amount was recovered through Responder Sales.

### Derived KPIs

- **Frequency**: Average number of times an Ad was served to a reached customer. (Impressions / Reach)
- **Cost per Click (CPC)**: Amount Spend / Clicks
- **Cost per mille (CPM)**: Cost per thousand impressions : Amount Spend / Impressions / 1000
