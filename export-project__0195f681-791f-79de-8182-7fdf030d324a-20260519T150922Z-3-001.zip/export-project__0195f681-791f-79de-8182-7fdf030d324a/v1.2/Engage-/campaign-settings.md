---
title: "Campaign settings"
slug: "campaign-settings"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 20:04:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 05:12:19 GMT+0000 (Coordinated Universal Time)"
---
Campaign setting lets you play with all the details of your campaign. You can check delivery, integrate different platforms, track messages, create custom labels and much more. It helps you make your campaign more effective and effecient. To know more, explore following detailed sections.
