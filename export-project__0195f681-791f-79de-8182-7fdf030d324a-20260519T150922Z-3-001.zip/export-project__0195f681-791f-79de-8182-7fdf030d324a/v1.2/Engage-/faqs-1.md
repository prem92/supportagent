---
title: "FAQs"
slug: "faqs-1"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Jun 13 2022 11:50:51 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 08 2022 05:19:11 GMT+0000 (Coordinated Universal Time)"
---
## Messages

<details>
<summary>
Can I get the delivery status for bulk SMSs?</summary>

The Delivery Rate is lower than normally expected OR Delivery Rate shows 0% for Promotional message or Delivery Rate shows 0% for messages with Numeric Sender ID.

- The delivery statuses for Promotional SMS (SMS sent from Numeric Sender IDs) are not shared by Gateway Partner, hence are not used to calculate any metrics in Message Performance. For more details, click [here](https://economictimes.indiatimes.com/industry/telecom/telecom-news/telcos-stop-issuing-delivery-reports-on-bulk-smses-companies-fret/articleshow/78680111.cms?from=mdr).
  </details>

<details>
<summary>Can we reach out to NDNC customers with a template with optout tag?</summary>

- Reaching out to NDNC customers is directly handled by Telecom Operators - Airtel/ Vodafone, Jio etc. The customers are directly applying for NDNC to these operators. These are some extra settings for example customer can apply for NDNC but can wish to be reached out on certain days or time period. All this will be unknown to Capillary/ Gateway Partner/ Brand. So adding optout tag or not adding is irrelevant for NDNC. We can send entire customer list to operators and they can filter NDNC by their own. Screen reader support enabled.
  </details>

<details>
<summary>
 In general practice users copy and paste the templates from vendor portal to excel where space issues may occur. How to handle this? Screen reader support enabled.</summary>

- We can't handle space issues with static text. If space in coming in {#Var} field or just before or after it it will be taken as 1 character. It is advisable that the excel downloaded from DLT portal is uploaded directly to Engage+. Copy/ pasting templates in excel or manual creation of DLT template upload excel is not advisable as error can occur not only in Template content but Template id etc. as well. Screen reader support enabled.
  </details>

<details>
<summary> How can I target NDNC users?</summary>
  * NDNC targeting can happen as explained here. Suppose Person1 is NDNC customer. No brands can reach out to Person1 and this will be handled directly by Operators as Person1 would have applied for DND with operators. But Brand-A collected Person1 consent against service explicit or promotional messages. Consent can be collected via microsite signup/ missed call/ manual signing consent form etc. Then Brand A will upload Person1's name and Phone number in "consent customer details" to DLT. This list will overwrite the DND status DLT has for Person1 and is valid only for 6 months. Consent need to be refreshed after 6 months. DLT will then send me messages from Brand A only (for rest brands i remain DND). Screen reader support enabled.
</details>

<details>
<summary>
As a single SMS will be sent to both DND & non DND users, If a customer has chosen not to receive SMS from brands, would the SMS be triggered & failed at delivery? </summary>
Yes, SMS will be triggered but fail at delivery if customer is in DND. 
</details>

<details>
<summary>
Do you charge clients for such SMS failed at delivery? </summary>
Yes, we charge the same amount to Orgs (Gateway or operators have the same charge for delivered or non delivered).
</details>

<details>
<summary>
How do we know the counts of customers who have not received SMS?</summary>
You will know the count from the delivery rate. 
</details>

<details>
<summary>
Whether the delivery rates shown on campaign pages are accurate?</summary>
Delivery rates shown on campaigns are accurate. We are also doing product enhancement to tell reasons for non delivery -should be live in next 1 month. Delivery rates for Promotional messages (numeric sender id) will be unknown as these are not shared by gateway partners after DLT regulation.
</details>

<details>
<summary>
Suppose a client doesn't want to target customers who have not opted to receive SMS from the brand, is there a provision to do so? Do we get such customer details from telecom operators?</summary>
  * DND works at Category/ Industry level - not at brand level. So a customer will be in the NDNC list for retail and not for brand X. We get a DLR stating that the customer is DND - this happens only after we have tried to reach out to the customer but the delivery failed. There is no proactive system/ data in the public domain by which Capillary/ brand can know which customer is DND. We are thinking of making a reactive system by adding DND status to the customer after getting the DLR, but for this also we will have to trigger the message once to the customer. The enhancement is not confirmed and depends on tickets we get on this.
</details>

<details>
<summary>
If we are not sending an opt out tag to the DND users, how will they opt out? Suppose I'm a DND customer and if I don't have an option to opt out I might raise a complaint which will result in bad customer service.</summary>

Capillary can't make a change to the template registered for the Org in DLT. If the Marketer created a template with a #var where optout can be added, they can add the same from creative Labels as before.

</details>

<details>
<summary>
 Can we directly sync templates from the DLT portal without having to upload it on Engage+?</summary>
  * The respective APIs are not provided by the DLT portals and hence you cannot access these templates from the portal directly as of now.
</details>

<details>
<summary>Does a template have an expiry associated with it post approval?</summary>
  * A template is expired after 3 years post approval. However, the provision of deleting a template before 3 years is provided by both DLT portal and Engage+.

</details>

<details>
<summary>
Will the template overrides based on the template name?</summary>
  * No, the template override is based on the template ID which is the unique ID. If the template name is same, you will be asked to change it to make the search easier.
</details>

<details>
<summary>
Why is there a limit of 500 rows per CSV file?</summary>
  * This is to provide a real-time experience to the customer and to reduce the load on the system, since the upload happens in real time. Also, if the customer wants to upload, say 1000 rows, he can always upload 2 CSV files containing 500 rows each. There is no limit on the number of CSV files to be uploaded.
</details>

<details>
<summary>Some templates which were active at the time of upload have become inactive now, will it affect the delivery of SMS?</summary>
  * If the status is inactive, the operator will not broadcast the message to any customer even if the status was active at the time of upload. Therefore, it will affect the delivery of SMS.

</details>

## Offer

<details>
<summary>Can we have more than one series per offer?</summary>
Currently, our system supports only one series per offer. However, we have taken this as a feature request.
</details>

<details>
<summary>Does the system support 100 % as discount value?</summary>
Currently, the system accepts only 2 digit values (supporting up to 99%). But considering some special cases we came across yesterday, we will get this to 100%.
</details>

<details>
<summary>Can I tag customers to auto-generated coupon codes?</summary>
Yes, you can enable Issue to specific customers only in Coupons details and upload your customer list with any one of their identifiers (mobile no./email id, external id, user id). The auto-generated coupons are then tagged only to these customers.
</details>

<details>
<summary>Can I configure the WeChat template for resending the coupon templates through POS?</summary>
Currently, we support only the SMS template.</details>

<details>
<summary>How can I see no. of uploaded coupons?</summary>
When you upload coupons, you will see the uploaded count. We will also make this available on the dashboard page.
</details>

<details>
<summary>Can we change the discount once created?</summary>
Currently, you can change the discount value or discount type of an existing offer. However, we are still evaluating this feature.
</details>

<details>
<summary>How can I get the series id of a coupon through coupon/issue API? </summary>
You can get the series id through an API call. You can use series id, and Point of Sale (POS) identifier to consume an offer through API call.
</details>

<details>
<summary>What happens if the expiry date of an offer is after the campaign expiry date?</summary>
After the expiry date of a campaign, the offer is still valid but in campaign reporting, you will get details only till the campaign end date.
</details>

<details>
<summary>What if my coupon expiry is after my Offer expiry?</summary>
The expiry of a specific offer coupon cannot go beyond the Offer expiry. Hence, irrespective of the expiry set for the coupons, the validity expires along with the associated offer.
</details>

<details>
<summary>Do we have test vs. control in Loyalty?</summary>
No. We do not have a test vs. control check for the loyalty program.
</details>

<details>
<summary>Do we need to reconfigure the loyalty program if we make any change in the Offers tab of Loyalty?</summary>
No, it is not required to reconfigure the loyalty program.
</details>

<details>
<summary>Will there be any change in the isRedeemable get call nodes?</summary>
We will add an additional node - Max Discount. Rest everything will remain the same.
</details>

<details>
<summary>Can we have the same offer names?</summary>
Yes, you can have duplicate offer names. But, it is highly recommended not to keep duplicate names, at least within a module.
</details>

## DLT

<details>
<summary>Does DLT templates stored in Capillary allow special characters and regional language text?</summary>
  * Special Characters and Regional language are allowed even in Capillary templates. These need to be less than 30 characters if added in place of {{#var}} or it can be part of the static text approved from DLT. The 'Allow unicode characters' feature takes care of this. It is turned on by default. Screen reader support enabled. 
</details>

<details>
<summary>How will a brand be onboarded for DLT compliance from an Engineering perspective? </summary>

For a detailed answer, click on this [link](https://capillarytech.atlassian.net/wiki/spaces/CAM/pages/3172040747/Brand+Onboarding+Notes).

</details>

<details>
<summary>Can we reach out to NDNC customers with a template with optout tag?</summary>
  * Reaching out to NDNC customers is directly handled by Telecom Operators - Airtel, Vodafone, Jio etc. The customers directly apply for NDNC to these operators. There are some extra settings, for example, customer can apply for NDNC but can wish to be reached out on certain days or time period. All this will be unknown to Capillary/ Gateway Partner/ Brand. So adding optout tag or not adding is irrelevant for NDNC. We can send entire customer list to operators and they can filter NDNC by their own. Screen reader support enabled. 

**_In general, users copy and paste the templates from vendor portal to excel where space issues may occur. How to handle this?_** 

- We cannot handle space issues with static text. If space in coming in {#Var} field or just before it or after, it will be taken as 1 character. It is advisable that the excel downloaded from DLT portal is uploaded directly to Engage+. Copy/ pasting templates in excel or manual creation of DLT template upload excel is not advisable as error can occur not only in the template content but also other properties like template ID. 
  </details>

<details>
<summary>How can we target NDNC users?</summary>
  * NDNC targeting can happen in the following way now. Suppose, Person1 is an NDNC customer. No brands can reach out to Person1 and this will be handled directly by operators as Person1 would have applied for DND with operators. But Brand A collected Person1 consent against service explicit or promotional messages. Consent can be collected through microsite signup/ missed call or manual signing consent form etc. Then, Brand A will upload Person1's name and Phone number in 'consent customer details' to DLT. This list will overwrite the DND status DLT has for Person1 and is valid only for 6 months. Consent need to be refreshed after 6 months. DLT will then send messages from Brand A only (for rest brands it remain DND). </details>

<details>
<summary>Is the order of column header names the same for all the DLT service providers?</summary>
  * No, the header names and column order can differ with different DLT providers. However, Engage+ understands which header name means what and hence the order does not really matter. Even the header names can vary from portal to portal (say, Template ID can be Temp ID for some service providers), but all such the cases will be handled by the product itself.
</details>

<details>
<summary>
I am not able to see sender IDs in the Delivery settings section even after sharing the sender IDs with the Gateway team?</summary>
  * Capillary has enabled DLT compliance with three gateways namely Kaleyra, ICS, and Karix. If the Org is integrated with any other gateway the DLT feature will not work for that Org.
</details>

<details>
<summary>
Does Capillary stored DLT templates allow special characters and Regional Language text?</summary>

- Special Characters and Regional language are allowed even in Capillary templates. These need to be less than 30 character if added in place of {{#var}} or it can be part of the static text approved from DLT. The 'Allow Unicode characters' feature takes care of this. It is turned on by default is on. Screen reader support enabled.
  </details>

<details>
<summary>
Is the optout tag mandatory for DLT messages?</summary>

- Optout tag is not mandatory. If a brand wants to add it they need to add a #var in the content while getting it registered in DLT portal. 
  <details>
