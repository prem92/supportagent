---
title: "Journeys"
slug: "journeys"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Jul 19 2022 11:05:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jul 19 2022 11:38:32 GMT+0000 (Coordinated Universal Time)"
---
## Introduction

Journeys is an engagement automation interface that enables you to create scenario based flows to nurture your customers throughout their lifecycle. It helps marketers identify the right course of action by creating multi-campaign flows, incentivising customers, and engaging them via multi-channel personalized communication, all at one place. It helps businesses automate their Customer engagement flow.

A Journey is an engagement flow that drives your interaction with customers towards a certain marketing objective. It starts with an entry trigger and diverges into several branches based on the conditions set up. A customer goes through flows which are set up by the user. 

## Components of Journeys

Capillary Journey product is composed of different components that decide how the user will move in the Engagement flow -

### Entry Triggers: Entering a Journey

These are the points where customers enter the journey. Triggers are basically a set of rules that decide which customers to enter the Journey. A Trigger sets the context of a Journey. 

Entry Triggers are further classified into User initiated triggers and 

#### 1. User Initiated Triggers

These are the entry triggers or conditions that are based on many user properties such as user events, audience list etc. When a user satisfies the conditions set, he/she will enter the Journey. Events are evaluated in real time.   

User Initiated triggers are further classified into user events and audience list -

- **User Events**: This Entry trigger is defined based on the user events. Marketers can set up upon which customer event a customer enters the journey. This includes transactional events such as purchase, transaction discount, points redeemed etc. 

   Example: Include customers in the journey whose transactional value is greater than $10,000.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/27e0af2-GT10REj5BMHXrcxbv6rQCn-C3pAhaI6Bcg.png",
        "GT10REj5BMHXrcxbv6rQCn-C3pAhaI6Bcg.png",
        1003
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


- **Audience list**: Brands can upload a list of users or create an Audience Group using filters and and initiate a journey for them.  
   A customer enters a journey through these Entry triggers and then follows certain conditions to personalize the engagement flow. These can be set up by the Building blocks of Journeys 

### Building Blocks

These are customizable in-built logic variables that you define while creating a Journey. 

- **Engagements**: The engagement block contains different types of channels that can be used to engage with your customers. A marketer can add an engagement block (of a particular channel) and can configure the content in that block (specific to that channel) to reach out to users. 

   It is a Multi-channel engagement block which supports Email and SMS. It's easy to set up multiple communications with a simple drag & drop of the channels. You can set the content in the same block.

   Example: Include customers whose transactional value is greater than $10,000 in the Journey. Furthermore, communicate the discounts availed by these customers via SMS. 

- **Flow control**: It helps you control the flow by applying conditions to user events or preferences. 

   This Building Block controls the customer experience and Journey flow by configuring conditions on the behavior or preferences of the user in the Journey

   These are differentiating conditions set by the marketer to define a flow for the user who entered a journey. It is an extra point of decision making where the user is pushed into a different or the same flow based on certain conditions on Time or Event based preferences.  

   Flow Control is further divided into **Wait**, **Wait till event**, and **Decision split**.

#### 1. Wait

   The Wait blocks lets the users wait for a defined amount of time before they continue a journey. Basically the user awaits its Journey flow for some time defined by you to achieve the desired objectives. The wait can be for X amount of Days/Months/weeks, before the user can proceed in the flow.

   Example: 

- Include customers whose transactional value is greater than $10,000 in the Journey. 
- Furthermore, communicate the discounts availed by these customers via SMS channel. 
- Wait for customers to avail these discounts and send a follow back communication after waiting for a specific period of time

#### 2. Wait till event

   This block waits for the user from proceeding in the Journey flow until the user has performed the desired User events or actions. 

   Basically you set up certain conditions on the events performed by the customer. If these event conditions fit with the user actions, the user proceeds along the path. If not, then the user Waits for a specific amount of time before entering the next block 

   Example:  

- Include customers whose transactional value is greater than $ 10,000 in the Journey. 
- Furthermore, communicate the discounts availed by these customers via SMS channel. 
- Wait for the customer to avail these discounts and send a follow back communication after waiting for a period of time, let’s say 5 days. 
- Incentivise the customers who have redeemed the coupon after 5 days but have customer points more than 150. If this condition is not followed, the user waits another 3 days before proceeding to the next block. 

#### 3. Decision Split

   The Decision split divides the flow into different  paths. If the user actions or attributes match with the conditions specified, User goes to the former path. If not then go to other paths.
