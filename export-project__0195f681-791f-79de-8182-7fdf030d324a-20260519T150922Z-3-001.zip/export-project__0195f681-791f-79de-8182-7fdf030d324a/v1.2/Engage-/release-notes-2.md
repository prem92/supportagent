---
title: "Release Notes"
slug: "release-notes-2"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon May 30 2022 06:54:32 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jul 11 2022 11:42:48 GMT+0000 (Coordinated Universal Time)"
---
This section contains quarterly release notes for the current year and yearly release notes for the previous years.

Navigate to the respective articles to know what has happened in each quarter.
