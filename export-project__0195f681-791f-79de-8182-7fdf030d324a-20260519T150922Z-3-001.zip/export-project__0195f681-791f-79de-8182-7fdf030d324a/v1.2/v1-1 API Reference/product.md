---
title: "Product"
slug: "product"
excerpt: "The product entity holds all products of an org and product related information such as size, color, type, and brand. Product APIs allow you to fetch details of a specific product, modify existing details, change brand name for a product and create new attributes for a product."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jun 16 2022 10:31:23 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jun 16 2022 11:23:57 GMT+0000 (Coordinated Universal Time)"
---
## Status Codes

### Success Code

| Code | Description                    |
| ---- | ------------------------------ |
| 2100 | Product retrieved successfully |

### Error Code

| Code | Description                                        |
| ---- | -------------------------------------------------- |
| 2101 | Unable to retrieve product details                 |
| 9102 | Item SKU not passed                                |
| 9103 | Product Price not passed                           |
| 9100 | Product added successfully                         |
| 9106 | Product price is not numeric                       |
| 9108 | Trying to add product with an already existing EAN |
