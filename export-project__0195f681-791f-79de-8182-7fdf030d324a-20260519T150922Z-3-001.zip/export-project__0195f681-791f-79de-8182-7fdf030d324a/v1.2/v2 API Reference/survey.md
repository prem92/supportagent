---
title: "Survey"
slug: "survey"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 24 2022 16:20:45 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 25 2022 06:55:37 GMT+0000 (Coordinated Universal Time)"
---
## Status codes

| Code | Description                                               |
| ---- | --------------------------------------------------------- |
| 9001 | Invalid survey id                                         |
| 9002 | Invalid survey question id                                |
| 9003 | No surveys found                                          |
| 9004 | No survey questions found                                 |
| 9005 | No survey responses found                                 |
| 9006 | Invalid survey external reference id passed               |
| 9007 | Unable to add survey questions                            |
| 9008 | Survey external reference id already exists               |
| 9010 | Question external id {x} already exists                   |
| 9011 | Invalid survey question external id {0} passed for lookup |
| 9012 | Duplicate survey question external id {0} in request      |
