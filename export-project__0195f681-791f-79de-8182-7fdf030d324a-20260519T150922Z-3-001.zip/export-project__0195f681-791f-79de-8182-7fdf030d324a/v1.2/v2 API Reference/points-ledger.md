---
title: "Points Ledger"
slug: "points-ledger"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 24 2022 11:41:36 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 24 2022 15:13:22 GMT+0000 (Coordinated Universal Time)"
---
Points as incentives are treated as currency within an org and its affiliates. The multitude of credits, debits, and adjustments impact the pool of points in the customer account. When points issued from different programs of the org can be redeemed across the org units or loyalty programs, it is important to understand the debit and credit history. Ledger APIs help you retrieve the points debit and credit details across the programs of the org.

## Response Parameters

| Parameter            | Datatype  | Description                                                                                                                                                                                   |
| -------------------- | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| customerDetails      | obj       | Details of the current customer.                                                                                                                                                              |
| firstName            | string    | Name of the customer.                                                                                                                                                                         |
| lastName             | string    | Last name of the customer.                                                                                                                                                                    |
| userId               | long      | Unique ID of the customer.                                                                                                                                                                    |
| externalId           | string    | External ID of the customer.                                                                                                                                                                  |
| entityType           | enum      | Whether the points are issued to an individual (`CUSTOMER`), or group  (`FLEET`).                                                                                                             |
| pageNumber           | int       | Current page number. Default value - `0` (first page).                                                                                                                                        |
| pageSize             | int       | Number of entries shown on the current page.                                                                                                                                                  |
| totalEntries         | int       | Total number of ledger entries available for the customer.                                                                                                                                    |
| pageCount            | int       | Total number of pages according to the page size.                                                                                                                                             |
| eventLogId           | int       | Unique log ID of the current event.                                                                                                                                                           |
| eventName            | string    | Name of the event associated with the points. Example - `TransactionAdd`, `PointsRedemption`, `DelayedAccrual`, `PointsExpiry`, `CustomerRegistration`, `ReturnBill`.                         |
| ledgerCreatedDate    | date-time | Date and time when the points ledger entry was created.                                                                                                                                       |
| entryDetails         | obj       | Details of the points ledger.                                                                                                                                                                 |
| ledgerClosingBalance | array-obj | Details of closing ledger balance on a specific date.                                                                                                                                         |
| pointsCategory       | enum      | Category from which points are issued. Supported values: `Main` (redeemable account), `DelayedAccrualPointCategory` (promised points), `ExternalTriggerBasedPointCategory` (promised points). |
| programName          | string    | Name of the loyalty program associated with points.                                                                                                                                           |
| programId            | int       | Unique ID of the loyalty program.                                                                                                                                                             |
| closingBalance       | float     | Available closing balance on that particular end date.                                                                                                                                        |
| netPointsOnEvent     | float     | Net points in the current event (by adding credits and subtracting debits).                                                                                                                   |
| transactionDetails   | obj       | Transaction details of the current points. Applicable for transaction related events.                                                                                                         |
| transactionId        | long      | Transaction ID associated with the points.                                                                                                                                                    |
| transactionNumber    | string    | Transaction number associated with the points.                                                                                                                                                |
| date                 | date-time | Date of the transaction.                                                                                                                                                                      |
| amount               | float     | Net transaction amount.                                                                                                                                                                       |
| store                | string    | Name of the store associated with the points.                                                                                                                                                 |
| storeCode            | string    | Unique code of the store associated with points.                                                                                                                                              |
| tillCode             | string    | Unique TILL code associated with points.                                                                                                                                                      |

## Status Codes

| Code  | Description                                                                                                                 |
| ----- | --------------------------------------------------------------------------------------------------------------------------- |
| 11001 | This combination of request parameters is not supported. Try removing parameters.                                           |
| 11002 | This customer has pending events, hence the ledger may be incomplete. Please retry after some time to get a complete ledger |
| 11003 | There are no ledger entries present for the given parameters. Try removing parameters to widen the search                   |
| 11004 | Invalid tillId passed in request                                                                                            |
| 11005 | Invalid programId passed in request                                                                                         |
| 11006 | Limit cannot be greater than 10                                                                                             |
| 11007 | Invalid ledgerEntryType passed in request                                                                                   |
| 11008 | Invalid pointCategoryType passed in request                                                                                 |
| 11009 | Startdate is after endDate                                                                                                  |
| 11010 | Time interval between startDate and endDate is greater than 60 days                                                         |
| 11011 | The date format used is not supported. Enter the date in (yyyy-MM-ddTHH:mm:ss) format                                       |
| 11012 | Invalid userId passed in request                                                                                            |
| 11013 | identifierName, identifierValue, source can not be empty                                                                    |

### EMF Errors

9003 | Error fetching points ledger data : {x}
