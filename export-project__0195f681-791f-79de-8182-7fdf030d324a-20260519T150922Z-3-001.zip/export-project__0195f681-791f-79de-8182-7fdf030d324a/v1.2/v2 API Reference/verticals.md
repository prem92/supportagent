---
title: "Verticals"
slug: "verticals"
excerpt: "Vertical represents the type of business. For example, apparel, jewelry, and e-commerce. An org can have one or more verticals."
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Fri May 27 2022 07:10:20 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 27 2022 07:36:39 GMT+0000 (Coordinated Universal Time)"
---
## Response Codes

| Code  | Description                                          |
| ----- | ---------------------------------------------------- |
| 91027 | Unable to find vertical                              |
| 91028 | Invalid vertical                                     |
| 91029 | Unable to add vertical. Invalid vertical name passed |
| 91030 | Unable to add org vertical                           |
| 91031 | Unable to disable the vertical                       |
| 91032 | Org is already mapped to the specified vertical id   |
