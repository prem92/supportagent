---
title: "Customer Labels"
slug: "customer-labels"
excerpt: "Customer labels are used for tagging customers based on their activities or loyalty histories. Tags are used in loyalty, campaigns and Essential Insights. You can add new labels and tag labels to customers using APIs of organization and customers mentioned here."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed May 18 2022 07:18:11 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 24 2022 11:30:13 GMT+0000 (Coordinated Universal Time)"
---
## Status codes

| Code  | Description                     |
| ----- | ------------------------------- |
| 33000 | {x} label not found             |
| 33001 | User labels not found           |
| 33002 | Org labels not found            |
| 33003 | Label {x} already exists in org |
| 33004 | Org max Label config not set    |
| 33005 | Org max Label count exceed      |
| 33006 | Org labels empty post payload   |
