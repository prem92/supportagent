---
title: "Staff"
slug: "staff"
excerpt: "A Staff is an org employee who deals with selling items to end-users. This concept is introduced mainly for B2B marketing. This resource contains APIs related to managing staff accounts. The staff user will have the properties of both Admin and TILL user."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri May 27 2022 08:29:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 27 2022 10:23:52 GMT+0000 (Coordinated Universal Time)"
---
## Status Codes

### Error Codes

| Code | Description                                                                                                       |
| ---- | ----------------------------------------------------------------------------------------------------------------- |
| 401  | Invalid authentication. Please check your username, password or authentication token                              |
| 1001 | Password not set                                                                                                  |
| 1005 | The identifier already exits                                                                                      |
| 1007 | Username or identifier (email/mobile) is not set                                                                  |
| 1009 | Invalid identifier details passed                                                                                 |
| 1010 | Invalid OTP type passed                                                                                           |
| 1011 | Inactive user passed                                                                                              |
| 1012 | Unable to send OTP to the new identifier                                                                          |
| 1215 | Invalid ParentZoneId/External Id/ParentConceptId specified. The the specific id will be set to the default values |
| 1700 | Invalid OTP or OTP expired                                                                                        |
