---
title: "Access"
slug: "access"
excerpt: "This article provides the different ways of accessing InTouch."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Jan 27 2022 04:59:13 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 08 2022 09:51:46 GMT+0000 (Coordinated Universal Time)"
---
InTouch is deployed in different clusters. Before accessing InTouch, you need to know the cluster of your org and login credentials provided by Capillary. 

The following are the links to different clusters of InTouch: 

- **EU**: <https://eucrm.cc.capillarytech.com/>
- **India**: <https://incrm.cc.capillarytech.com/>
- **APAC2**:[ https://apac2.intouch.capillarytech.com/](https://apac2.intouch.capillarytech.com/)
- **SG**: <https://sgcrm.cc.capillarytech.com/>
- **CN**:[ http://intouch.capillarytech.cn.com/](http://intouch.capillarytech.cn.com/)
- **US**: <https://us.intouch.capillarytech.com/>

You can access InTouch in three different ways:

Using Capillary InTouch email Id and Password  
Using Capillary's Official Google account credentials  
Using SSO 

## Login with Capillary Credentials

Get Started with Capillary InTouch! InTouch is a cloud-based platform that contains the entire product modules including Organization settings and Workbench. InTouch can be accessed by all authorized users and brands. There are several user roles on InTouch and access is managed at the page level. Not everyone will have write access or access to all modules. Super Admins will provide access to users based on their role and scope.

Enter the credentials provided by Capillary in Email Id and Password then click on Sign in.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cbba100--kxszggvWKsXxYFPfK6kP3YRTjdVmbUa3g.png",
        "-kxszggvWKsXxYFPfK6kP3YRTjdVmbUa3g.png",
        502
      ],
      "border": true
    }
  ]
}
[/block]


## Login with Capillary Google account

You can now sign in to InTouch using your Capillary Google Workspace account.  
That means:

- No need to remember your Intouch password anymore
- No more Intouch password reset every month
- Convenience and security

### Prerequisite

You should have a Capillary Google Workspace account (e-mail address with domain capillarytech.com)

### Login with Google Credentials

1. In a browser, open the URL of your cluster.

- EU Cluster - <https://eu.intouch.capillarytech.com/auth/login>
- SG Cluster - <https://apac2.intouch.capillarytech.com/auth/login> 
- India Cluster - <https://intouch.capillary.co.in/auth/login> 

2. Click on **Sign in with Google **as shown below.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0e375a7-GoogleSignIn.png",
        "GoogleSignIn.png",
        685
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


3. Enter the email ID your Capillary Google Workspace account and click **Next**.
4. Enter your password and click **Next**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b1f07d4-Password.png",
        "Password.png",
        696
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


You will see Intouch Workbench. If you have already signed in to your Capillary Google Workspace account, you will directly see the Workbech page.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/303472d-Workbench.png",
        "Workbench.png",
        1920
      ],
      "sizing": "80"
    }
  ]
}
[/block]


## Login with SSO

Sign in with a single set of credentials used for multiple applications provided by third party like Microsoft ADFS, G Suite SAML. It allows brand users to login to Capillary Intouch using their Identity Provider (IdP).

Setup SSO with Okta  
We have partnered with Okta for the integration. SSO setup requires configuring a connection for Capillary in Org’s IdP and setting up Org’s Identity in Okta Admin Console. 

To set up SSO with Okta, follow these steps.

**Step 1 - Set up a connection for Capillary in Org’s IdP**

1. Capillary PoC has to send an email to the Capillary access team with a request to set up SSO for the organization providing the following information.

- Organization name and ID

- Email domain of the organization. For example, the domain is org.com if the Email Id is [abc@org.com](mailto:abc@org.com)

2. Capillary Access team will share the following information, which should be shared with the org PoC

- Assertion Consumer Service (ACS) URL.

- Service Provider (SP) Entity ID or Audience URL or Entity ID.

- User profile attributes need to be passed as SAML assertion - email, first name, and last name. Email ID mandatory.

- [Optional] Attribute that defines if the user has access to Capillary. For example, group, organization. This is required if the org wants to define which employees have access to Capillary.

3. Org PoC will use the above information to create a connection for Capillary in their IdP and respond with the following information.

- Identity Provider SSO URL.

- Identity Provider Entity ID.

- Identity Provider Certificate signature.

To know about the SAML terminologies, read How SAML works?

**Step 2 - Setting up Identity Provider in Capillary**

1. Capillary or Org PoC will share the information provided in step 1.3 (above) with the Capillary Access team.

2. Capillary Access team will add an Identity Provider in Okta Admin Console and respond with setup confirmation.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4611040-YcZE7z1u94dsCfdrLsaNl3MHQv3dLLoLXw.png",
        "YcZE7z1u94dsCfdrLsaNl3MHQv3dLLoLXw.png",
        898
      ],
      "border": true
    }
  ]
}
[/block]


**Step 3 - Provide Capillary application’s access to Org users  
**  
Use Data Import to add Org users to the Capillary application with the appropriate access level. 

- When you add users on InTouch, a verification email is sent along with the password setup link. The required change to disable the step is in progress and will be released soon. Until then, only Data Import to add Org users.

**Step 4 - Authenticate with Single Sign-on  **

Once setup is completed, the org users can authenticate using SSO as explained in the following steps.

1. On the new sign-in page, click Sign in with SSO.

![](https://files.readme.io/04214ed-FSyNzHUAPJ5SY3uvldwDimwB-z1re6BNbw.png "FSyNzHUAPJ5SY3uvldwDimwB-z1re6BNbw.png")

2. In **Username**, enter a valid email address and click **Next**.  
   You are redirected to the Identity provider’s page to complete authentication.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fc06d3a-JbFVF8IG9WAPHdhx0jG6_7ZWTVzYp65YmQ.png",
        "JbFVF8IG9WAPHdhx0jG6_7ZWTVzYp65YmQ.png",
        598
      ],
      "border": true
    }
  ]
}
[/block]


3. On the Identity Provider’s page, enter your registered email address, password, and click **Sign in**.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/58636b9-Dkn_2OjHNw_Om0sRCt_LIOk6jdl9UctSSQ.png",
        "Dkn_2OjHNw_Om0sRCt_LIOk6jdl9UctSSQ.png",
        671
      ],
      "border": true
    }
  ]
}
[/block]


When the login is successful, you will see the InTouch home page.
