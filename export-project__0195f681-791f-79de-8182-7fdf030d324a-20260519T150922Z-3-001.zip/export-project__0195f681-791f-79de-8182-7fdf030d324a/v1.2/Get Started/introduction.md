---
title: "Introduction"
slug: "introduction"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Apr 08 2022 08:36:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 08 2022 09:51:23 GMT+0000 (Coordinated Universal Time)"
---
At Capillary, we offer AI-based cloud-native SaAS products and solutions such as automated loyalty management and consumer data platform. Our diverse product range enables you to manage end-to-end loyalty programs, gain a comprehensive view of your consumers, and offer unified, cross-channel strategies that provide consumers with real-time, omnichannel, personalized, and consistent experience.

- **Loyalty+** - Lets you increase repeat sales with personalized, omnichannel, loyalty programs by intelligently rewarding your customers for desired behavior. [Know more details](https://docs.capillarytech.com/docs/getting-started-1).
- **Engage+** - Allows you to personalize customer engagement with omnichannel retail marketing solutions.
- **Customer Data Platform (CDP)**: An effective platform to ingest data from different sources and platforms. There are several products to help capture brand's data from different sources. [Check out more details](https://docs.capillarytech.com/docs/integration-hub).
- **Insights+** - Provides you with profitable insights with AI-powered customer analytics. [See more details](https://docs.capillarytech.com/docs/reports-introduction).
- **Smart Store+** - Lets you maximize conversions using personalized in-store experiences.
- **Anywhere Commerce+** - Offers a connected experience with enterprise-ready omnichannel e-commerce solutions. [See more details](https://anywhere-commerce.readme.io/docs).
