---
title: "Standard templates"
slug: "standard-templates"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 20:06:41 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 06:31:03 GMT+0000 (Coordinated Universal Time)"
---
