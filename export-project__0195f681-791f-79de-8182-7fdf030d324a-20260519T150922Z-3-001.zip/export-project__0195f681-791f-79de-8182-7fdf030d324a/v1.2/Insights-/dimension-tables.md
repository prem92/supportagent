---
title: "Dimension tables"
slug: "dimension-tables"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Apr 06 2022 04:52:22 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 06:14:31 GMT+0000 (Coordinated Universal Time)"
---
## Points Promotion

| column name             | column type | Description                                                                          |
| ----------------------- | ----------- | ------------------------------------------------------------------------------------ |
| id                      | integer     | Unique identifier of a promotions id in the table                                    |
| name                    | String      | promotion's name for the points that are awarded                                     |
| type                    | String      | Type of the promotion ex:- Bill level,Customer level                                 |
| auto\_update\_promotion | integer     | Date and time when the points\_promotions table is recently updated (Unix timestamp) |
| identifier              | String      | \-                                                                                   |

## Points Awarded Type

| id      | ENUM                                | description                                                           |
| ------- | ----------------------------------- | --------------------------------------------------------------------- |
| \-10003 | NOT-APPLICABLE                      |                                                                       |
| \-10002 | INVALID                             |                                                                       |
| \-10001 | NOT-CAPTURED                        |                                                                       |
| 1       | POINT\_AWARDED                      | Regular points awarded for making transaction                         |
| 2       | POINT\_AWARDED\_BILL\_PROMOTION     | Promotional points given on top of regular point at transaction level |
| 3       | POINT\_AWARDED\_LINEITEM            | Regular points awarded for purchashing a specific product             |
| 4       | POINT\_AWARDED\_LINEITEM\_PROMOTION | Promotional points given on top of regular point at line item level   |
| 5       | POINT\_AWARDED\_CUSTOMER\_PROMOTION | Promotional points given on top of regular point at customer level    |

## Points Category

| redemption\_type | category\_type                   | category\_id |
| ---------------- | -------------------------------- | ------------ |
| NON-REDEEMABLE   | PROMISED\_POINTS                 | 1,097        |
| NOT-APPLICABLE   | NOT-APPLICABLE                   | \-10,003     |
| REDEEMABLE       | REGULAR\_POINTS                  | 336          |
| NON-REDEEMABLE   | EXTERNAL\_TRIGGER\_BASED\_POINTS | 1,098        |
| NOT-CAPTURED     | NOT-CAPTURED                     | \-10,001     |
| NON-REDEEMABLE   | TRACKERS                         | 810          |
| INVALID          | INVALID                          | \-10,002     |

Points category can be of 4 types at Capillary backend, of which 3 shall be expected to show up at the  
front-end in exports

‘REGULAR_POINTS’ – These are redeemable points.  
‘TRACKERS’ – These shall not be available in the export.  
‘PROMISED_POINTS’ – These are strategy based and return window based delayed accrual points  
(conversion date is known for these and will be available in awarded_date)  
‘EXTERNAL_TRIGGER_BASED_POINTS’ – These are promised points that are expected to convert to  
regular points based on an externally received trigger. (conversion date is not known for these - don’t  
search for this anywhere)

Trackers will not be part of point fact.  
The treatment of promised points must be done based on points categories only (and not based on non-redeemable values during query writing)  
Screen reader support enabled.				

## Points events type

| id      | ENUM             | Description                                |
| ------- | ---------------- | ------------------------------------------ |
| \-10003 | NOT-APPLICABLE   |                                            |
| \-10002 | INVALID          |                                            |
| \-10001 | NOT-CAPTURED     |                                            |
| 1       | POINTS\_AWARDED  | Depicts that the points have been awarded  |
| 2       | POINTS\_DEDUCTED | Depicts that the points have been deducted |

## Date

| Column Name         | type    | Description                                                                                                              |
| ------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------ |
| date\_id            | Integer | Unique identifier of a date in the table                                                                                 |
| date                | Date    | Represents date in the format of DD-MM-YYYY. For example, 2018-01-01                                                     |
| day\_of\_month      | Integer | Stands for the day component (range between 1 to 31)                                                                     |
| week\_of\_year      | Integer | Stands for the calendar week of the year ( range between 1 to 52)                                                        |
| month               | String  | Stands for each month part Jan 2018                                                                                      |
| year                | Integer | Year in YYYY format                                                                                                      |
| quarter             | String  | Quarterly split of calendar year - Q1 Jan, Feb Mar; Q2 Apr, May, Jun, and so on                                          |
| quarter\_no         | Integer | Denotes the cumulative quarter count from beginning of date calendar. This is of no practical use case in report or list |
| year\_quarter\_no   | Integer | Denotes quarter number of a year - 1, 2, 3, 4 (1 for Q1, 2 for Q2 and so forth)                                          |
| week\_number        | Integer | It is the cumulative week count from beginning of a date calendar. This is of no practical use case in report or list    |
| week\_start\_date   | Date    | Start date of the calendar week in DD-MM-YYYY format                                                                     |
| week\_end\_date     | Date    | The date in the format of DD-MM-YYYY when the calendar week end                                                          |
| day\_of\_week       | Integer | Day of a week - Monday to Sunday                                                                                         |
| month\_no           | Integer | Denotes the cumulative month count from beginning of date calendar. This is of no practical use case in report or list   |
| month\_no\_of\_year | Integer | Denotes the month number of a year (1 for January , 2 for February and so forth)                                         |
| month\_of\_year     | Integer | Month of a year - January, February,..December                                                                           |

## Zone till

| Column Name        | Type    | Description                                                                                                  |
| ------------------ | ------- | ------------------------------------------------------------------------------------------------------------ |
| till\_id           | Integer | Denotes point of sale identifier                                                                             |
| till               | String  | Point of sale name                                                                                           |
| type               | String  | If general the store is a genuine data contributing store, if admin the store is a test store with fake data |
| is\_active         | String  | If 1 it means active otherwise its inactive. Active stores are stores where capillary software is activated  |
| store              | String  | Store code name                                                                                              |
| store\_description | String  | Sometime used to capture external nomenclature of client for store                                           |
| store\_name        | String  | Store name given by Capillary System                                                                         |
| zone\_name         | String  | Name of zone                                                                                                 |

## Time

| Column Name       | Type    | Description                                       |
| ----------------- | ------- | ------------------------------------------------- |
| time\_id          | Integer | Unique identifier of a date in the table          |
| time              | time    | Represents time in HH:MM:SS For example, 12:30:12 |
| <br>hour\_of\_day | Integer | Hour of the day - 0 to 24                         |
| minute\_of\_day   | Integer | Minute of day - 0 to 60                           |
| day\_shift        | String  | Shift of the day - Morning.Afternoon,Night        |
| day\_shift\_no    | Integer | Shift Number of day - 1 to 5                      |
| hour\_range       | String  | Hour range of day - (0-1),(1-2)...                |

## Program

| Column Name                     | Type     | Description                                       |
| ------------------------------- | -------- | ------------------------------------------------- |
| points\_currency\_ratio         | Interger | Ratio of the point and currency (Point/curreency) |
| redeemable\_point\_category\_id | integer  | Category id for the points which are redeemable   |
| description                     | String   | Descrption for the program                        |
| program\_name                   | String   | Name of the program                               |
| program\_id                     | Integer  | Unique identifier of the tables                   |

## Communication channel

| Column Name    | Type    | Description                                             |
| -------------- | ------- | ------------------------------------------------------- |
| id             | Integer | Unique identifier of the tables                         |
| channel        | String  | Name of the channel for which the communication happen  |
| activity\_name | String  | Name of the activity for which the communication happen |

## Loyalty type

| Column Name  | Type    | Description                     |
| ------------ | ------- | ------------------------------- |
| id           | Integer | Unique identifier of the tables |
| Loyalty type | String  | Type of loyalty for the user    |

## Order Channel

| Column Name    | Type    | Description                                              |
| -------------- | ------- | -------------------------------------------------------- |
| id             | Integer | Unique identifier of the tables                          |
| order\_channel | String  | Name of the channel using that the order has been placed |

## Repeat status

[block:parameters]
{
  "data": {
    "h-0": "Column Name",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "id",
    "0-1": "Integer",
    "0-2": "Unique identifier of the tables",
    "1-0": "Status",
    "1-1": "String",
    "1-2": "Status will be from below mentioned list<br>FIRST\\_TIME<br>INVALID<br>NOT-APPLICABLE<br>NOT-CAPTURED<br>REPEAT"
  },
  "cols": 3,
  "rows": 2,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


## Source type

[block:parameters]
{
  "data": {
    "h-0": "Column Name",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "id",
    "0-1": "Integer",
    "0-2": "Unique identifier of the tables",
    "1-0": "Type",
    "1-1": "String",
    "1-2": "Source type of event<br>instore<br>e-comm<br>newsletter<br>campaigns<br>NCA<br>WECHAT<br>MARTJACK<br>WEB\\_ENGAGE<br>FACEBOOK<br>TMALL<br>OTHERS<br>TAOBAO<br>"
  },
  "cols": 3,
  "rows": 2,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


## Customer slab

| Column Name                 | Type          | Description                                              |
| --------------------------- | ------------- | -------------------------------------------------------- |
| slab\_name                  | String        | Name of the Slab                                         |
| slab\_no                    | Integer       | Number of the slab                                       |
| auto\_update\_program\_slab | Unixtimestamo | Updated time when the program slab table the bee updated |
| serial\_no                  | Integer       | Unique identifier of the tables                          |

## SCD type

| Column Name | Type    | Description                     |
| ----------- | ------- | ------------------------------- |
| Id          | String  | Unique identifier of the tables |
| type        | Integer | Type of the SCD (0,1)           |

## Upgrade event type

| Column Name | Type    | Description                            |
| ----------- | ------- | -------------------------------------- |
| id          | Integer | Unique identifier of the tables        |
| category    | String  | category type for upgrade\_event\_type |
| name        | Name    | Name of the categories                 |

## Return type

[block:parameters]
{
  "data": {
    "h-0": "Column Name",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "id",
    "0-1": "Integer",
    "0-2": "Unique identifier of the tables",
    "1-0": "type",
    "1-1": "String",
    "1-2": "NOT-APPLICABLE<br>INVALID<br>NOT-CAPTURED<br>FULL<br>LINE\\_ITEM<br>AMOUNT<br>CANCELLED"
  },
  "cols": 3,
  "rows": 2,
  "align": [
    null,
    null,
    null
  ]
}
[/block]


## Item

| Column Name                | Type          | Description                                               |
| -------------------------- | ------------- | --------------------------------------------------------- |
| item\_code                 | string        | code for each and every item                              |
| brand\_name                | String        | Brand name for the item                                   |
| style                      | String        | Style for the item                                        |
| size                       | String        | Size of the Item                                          |
| inventory\_description     | String        | Description for item                                      |
| image\_url                 | Sting         | Link for the item image                                   |
| color                      | Sting         | Color of the item                                         |
| is\_valid                  | Boolen        | Stands for the validtaion for item                        |
| item\_id                   | Integer       | Unique identifier of the tables                           |
| auto\_update\_inv\_masters | Unixtimestamp | Timestamp when the inventry master table has been upadted |
| price                      | Integer       | Price of the item                                         |
