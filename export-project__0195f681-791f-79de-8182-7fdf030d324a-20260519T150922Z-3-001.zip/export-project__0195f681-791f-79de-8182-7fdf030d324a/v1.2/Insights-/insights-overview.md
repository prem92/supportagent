---
title: "Insights+ overview"
slug: "insights-overview"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 10:32:59 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jul 06 2022 04:59:40 GMT+0000 (Coordinated Universal Time)"
---
Insights+ is an advanced cloud-based business Intelligence tool that tracks an org’s business data from different sources and transforms the data into actionable insights. The vital business metrics help in making effective strategic and tactical business decisions.

It provides various reports with statistical proficiency. It has reports related to sales, campaigns, loyalty, product, CRM and also create custom reports as required for an organization. Leveraging such insights can not only help you drive product innovation but also track and improve the impact of product launches in real-time.

Insights+ is equipped with over 50 predefined charts and 250 key performance indicators (KPIs).

Other than reports, Insights+ allows you to export data and create customer segments.

Broad report categories:

There are four broad categories of reports. A report will fall into any of these categories.

1. Product
2. Sales
3. CRM
4. Customer

Report Types:  There are two types of reports in Insights+ - Standard Reports and Custom Reports.

- **Standard Reports**: These reports are common across organizations irrespective of their verticals and are available by default. These reports are available in the Standard Reports category.

| Report Name          | Description                                                                                                                                                                                                           |
| -------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Sales                | Provides an overview of business with top KPIs, across geography and product                                                                                                                                          |
| Customer Summary     | Provides a snapshot of the customer base                                                                                                                                                                              |
| Customer Transaction | Provides the summary of registrations and loyalty transactions                                                                                                                                                        |
| Store                | Provides the overall sales generated across stores and a summary of registrations and transactions at zone/concept/store level.                                                                                       |
| Product              | Provides category wise report of product performance with product-level KPIs. These reports can be drilled down to the item level.                                                                                    |
| Return Report        | Provides the summary of transaction returns in a given duration                                                                                                                                                       |
| Loyalty              | Provides the complete snapshot of the Org’s loyalty program                                                                                                                                                           |
| Points               | Provides the summary of points issued, redeemed and extra sales generated.                                                                                                                                            |
| Data Capture         | Provides the percentage capture rate of mobile numbers and email ids of all members of the Org                                                                                                                        |
| Campaign             | Provides a complete snapshot of campaigns, performance, ROIs, etc. and lets you drill down data at the segment level.                                                                                                 |
| Leads                | Provides a complete snapshot of leads report which contains total leads captured, conversion rate, open leads, won leads, conversion time, and performance of leads by time and by geography.                         |
| Referral Campaign    | Tracks the performance of a referral campaign based on the number of referrals sent and the conversion rate.                                                                                                          |
| SMS Credit Ledger    | Provides daily or monthly level SMS credit added, credit debited, and credit balance data for the org.                                                                                                                |
| Points Ledger Report | Provides monthly level data of points issued, points debited, and overall liability.  It also provides further drill down to split points debited based on the event type (redemption, expiry, return) per day level. |

- **Custom Reports**: Apart from the standard reports, Insights+ facilitates creating custom reports as per the org preference. 

## Features

Features of Insights+  
Following are the key benefits of Insights+:

- Provides the complete view of business with reports from different viewpoints such as loyalty, campaign, store, product, customer, segments, points, returns, and coupons
- Optimizes captured data for better reports and actionable analytics
- Ad-hoc analysis of big data sets
- Role-based access to restrict access to reports and data based on the user role and area
- Equipped with over 550 predefined KPIs and predefined charts
- Ability to create custom reports according to the organization's preference
- Quick accessing of reports through recent reports and favorite reports
- Like-to-like comparison of reports
- Dimension filters to view hierarchical data of segments, stores, zone, concepts or products 
- Flexibility to create custom dimensions and metric dimensions
- Drill-down report data with single clicks
- Download reports in Excel sheets
- Schedule reports on a fixed date or on a daily, weekly, or monthly basis. Receive reports through emails as links
- Export business data using various Fact and Dimension templates and also create custom templates if required
- Create customer segments to know who your best customers are and who need a push for segment migration reports
