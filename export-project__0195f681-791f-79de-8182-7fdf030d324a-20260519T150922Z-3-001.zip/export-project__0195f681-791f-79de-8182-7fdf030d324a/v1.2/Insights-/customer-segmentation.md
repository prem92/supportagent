---
title: "Customer segmentation"
slug: "customer-segmentation"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 20:05:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 06:15:31 GMT+0000 (Coordinated Universal Time)"
---
