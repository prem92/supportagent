---
title: "KPI and dimensions"
slug: "kpi-and-dimensions"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Apr 01 2022 11:50:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Apr 01 2022 11:50:40 GMT+0000 (Coordinated Universal Time)"
---
