---
title: "External facts"
slug: "external-facts"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 20:06:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jul 01 2022 09:32:37 GMT+0000 (Coordinated Universal Time)"
---
