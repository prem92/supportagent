---
title: "Try it APIs"
slug: "try-it-apis"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri May 27 2022 05:36:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jul 04 2022 10:36:31 GMT+0000 (Coordinated Universal Time)"
---
The new API documentation now lets you try out APIs by yourself. This article guides you how to run an API in the API documentation itself.

## Setup your environment

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/53d7b66-API_doc_GIF3.gif",
        "API doc GIF3.gif",
        1203
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


Before starting with API Try out, set your authentication and host URL. We have enabled Basic Auth for APIs that support Basic Auth.

Navigate to any API that you want to try out and scroll down to the **Authentication **section.  
Enter your TILL credentials - till ID and MD5 encoded password.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/389aecc-Authentication.png",
        "Authentication.png",
        735
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


In URL, click on host and enter your host URL according to the cluster.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7fa7fbe-host.png",
        "host.png",
        685
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


These details are saved as cookies as long as you close the browser or clear browser cache.

## Enter input values

Once you set your environment, you need to pass input values according to the API.

### Path & Query Parameters

If the API has path and parameters, you will see the table on the top. Path parameters are always mandatory and you will see the mandatory query parameters with the `required` tag. Provide inputs in the boxes right to it.

The URL keeps changing with the parameter values as you enter. See the updated URL in the `Try it` box on the right.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a2b1bad-Query_Parameters.png",
        "Query Parameters.png",
        1409
      ],
      "sizing": "80"
    }
  ]
}
[/block]


### Headers

If the API supports any additional headers, you will see a Headers section. Enter the header values accordingly. See the preceding screenshot for better understanding.

### Body Parameter

Usually, the schema or payload is complex for POST, and PUT calls especially when it comes to customer or transaction. Hence, you will see a sample payload for each use case.

Just copy the payload from the examples and modify it using any of your JSON editor such as Notepad++

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/348c5f4-Example.png",
        "Example.png",
        1415
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1d4c6b8-Example2.png",
        "Example2.png",
        672
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


Now, paste the updated payload in the RAW_BODY all the parameter descriptions in the body 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/721f393-RawBody.png",
        "RawBody.png",
        684
      ],
      "sizing": "80"
    }
  ]
}
[/block]


You are almost done! Just verify your input values and click on **Try it!** 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a4cfafb-TryIt.png",
        "TryIt.png",
        688
      ],
      "sizing": "80",
      "border": true
    }
  ]
}
[/block]


That's it. Just scroll down a bit to see the response.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/292d7be-Response.png",
        "Response.png",
        678
      ],
      "sizing": "smart",
      "border": true
    }
  ]
}
[/block]


#### What else?

- **See Response Headers**: See all the headers of the response by clicking on **Headers ** in the Response widget.
- **See Response Object**: You can also see the response object for each API under RESPONSES (center pane). Just scroll-down to the bottom of the respective page to access it.

> 📘 Currently, you can only see success objects.
