---
title: "Postman Collections"
slug: "postman-collections"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Dec 07 2021 09:37:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jul 06 2022 06:12:25 GMT+0000 (Coordinated Universal Time)"
---
## Getting Started

Postman is one of the most popular testing tools used for API testing. You can use the tool to create, test, and run APIs.  

We have created the Postman collections with our APIs. You can go through all the API entities, and import the collections into your own workspace. 

Run and test the APIs to see how to use them effectively according to your use case.

## Import Collections and Run APIs

The following steps guide you how to import Collections and run APIs on Postman.

1. Click on the "Run in Postman" button below. It will redirect you to postman's website.

[![Run in Postman](https://run.pstmn.io/button.svg)](https://god.postman.co/run-collection/c746973fee3e44602111?action=collection%2Fimport)

2. Choose whether to use the Postman web application or the installed application (Postman for Windows) 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/21222f0-postman_1.jpg",
        "postman 1.jpg",
        1347
      ],
      "border": true
    }
  ]
}
[/block]


3. Now, import the Capillary API Collection to a separate workspace on postman. Name the workspace. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c51ddac-postman_2.jpg",
        "postman 2.jpg",
        1366
      ],
      "border": true
    }
  ]
}
[/block]


4. Once the collection is imported into your workspace, you will see the 4 major entities i.e "**Customer**,  **Transaction**, **Points**, and **Coupon**". Each of these entities has some endpoints. 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6d60b86-postman_3.jpg",
        "postman 3.jpg",
        1366
      ],
      "border": true,
      "caption": "This is what your workspace would look like once the collections are imported."
    }
  ]
}
[/block]


5. Now to test and use these endpoints, first, you will have to authorize them with the help of the access token.  
      To generate an access token, go to the **OAuth** endpoint, it opens in a new tab. In **Body** enter your key and secret. and click on **Send **.  
   The `accessToken`is generated if a valid key and secret are entered.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a2ec5df-postman_4.jpg",
        "postman 4.jpg",
        1366
      ],
      "border": true
    }
  ]
}
[/block]


6. To authorize any other API endpoint, click on that endpoint > Go to **Headers** > Enter the `accessToken` generated in front of the `X-CAP-API-OAUTH-TOKEN`.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b14044e-postman_5.jpg",
        "postman 5.jpg",
        1366
      ],
      "border": true
    }
  ]
}
[/block]


## List of APIs included in Collection

| Collections                |
| :------------------------- |
| Customer API collection    |
| Transaction API collection |
| Points API collection      |
| Coupon API collection      |
