---
title: "Products Overview"
slug: "products-overview"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Mon Dec 06 2021 10:19:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 14 2022 12:28:41 GMT+0000 (Coordinated Universal Time)"
---
Capillary provides an end-to-end solution for marketing uses cases through its wide range of products covering custom data collection & unification, data analytics & insights, campaign & promotion execution, and loyalty program orchestration. Find more about Capillary products in the following links -

**1. Loyalty+ -**  Lets you increase repeat sales with personalized, omnichannel, loyalty programs by intelligently rewarding your customers for desired behavior. [Know more](https://docs.capillarytech.com/docs/getting-started-1).

**2. Engage+ -**  Allows you to personalize customer engagement with omnichannel retail marketing solutions. [Know more](https://docs.capillarytech.com/docs/engage-overview).

**3. Insights+ -** Provides you with profitable insights with AI-powered customer analytics. [Know more](https://docs.capillarytech.com/docs/reports-introduction).

**4. Customer Data Platform (CDP) -** An effective platform to ingest data from different sources and platforms. There are several products to help capture brand data from different sources. Check out more details. [Know more](https://docs.capillarytech.com/docs/integration-hub)
