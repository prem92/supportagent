---
title: "Loyalty+ AMJ'23"
slug: "loyalty-amj23-1"
type: ""
createdAt: "Thu May 18 2023 05:11:16 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/amj-2023-loyalty-release-notes)