---
title: "CDP | JAS'23"
slug: "cdp-jas23"
type: ""
createdAt: "Fri Oct 27 2023 10:23:35 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/jas-2023)