---
title: "October-Nov-Dec'24"
slug: "october-nov-dec24"
type: ""
createdAt: "Mon Nov 04 2024 12:47:39 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
* [**Engage+**](https://docs.capillarytech.com/docs/ond-2024-engage-releases)