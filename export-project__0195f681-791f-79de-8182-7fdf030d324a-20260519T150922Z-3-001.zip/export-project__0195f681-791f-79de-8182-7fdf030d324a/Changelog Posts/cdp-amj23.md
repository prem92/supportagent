---
title: "CDP | AMJ'23"
slug: "cdp-amj23"
type: ""
createdAt: "Thu Jun 15 2023 15:26:52 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/amj-2023-cdp-releases)