---
title: "Engage+ OND 21"
slug: "engage-ond-21"
type: ""
createdAt: "Tue Dec 28 2021 04:18:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes!](https://docs.capillarytech.com/changelog/engage-ond-21)

### DLT compliant SMS Campaigns

**Overview**\
TRAI has formulated certain guidelines to enhance control, prevent any fraudulent practice and provide greater safety to the end customer. As per the guidelines, the companies who want to communicate with their customers will now have to register themselves with Telecom Operators for sending SMS. The system will be governed using Blockchain technology also known as Distributed Ledger Technology (DLT).

Though TRAI has provided different platforms (Vodafone, Airtel, Jio, BSNL, etc.) to organizations for registering SMS content templates, the process of sharing the content templates with Gateway operators is still very manual and error-prone. Any mistake such as wrong header, wrong template-id, header and template mismatch, length of variable portion, etc. in the campaign configuration can cause the campaign to fail. 

#### Problem Statement

A lot of effort and money will be wasted if unregistered or wrong message templates are sent to operators.

Since the slightest mismatch between content templates can cause message failure, Capillary also wanted to ensure minimum manual edits in the approved content templates. 

#### High-level Solution

**Support for DLT approved SMS templates**-

* Users can now upload the DLT approved content templates file and load the approved content templates in Engage+.
* The upload option is available in the Engage+ Creatives section through which users can upload the content templates file downloaded from DLT platforms. For details on how to upload a template, see here.
* It also pre-checks certain errors such as Header value, template approval status, and template ID to ensure wrong templates are not loaded.

#### Benefit:

* The file upload option eliminates the need for manual re-writing of approved templates which is error-prone

### SMS campaigns to support only approved templates

* While creating SMS content in a campaign, you can only select from the approved content templates available in Engage+
* You can modify only the variables of the template. Various checks such as variable length, using only registered header, and template-id. are in place.

#### Benefit

This ensures campaigns are successfully run and TRAI regulation-compliant messages are delivered to customers.

#### Use Case

The Marketing Manager wants to send DLT compliant messages to his customers. For that, she can create the content templates in the DLT portal and submit them. Once approved by DLT, she can upload a file with content templates in Engage+ creatives. This file will be checked for mandatory information such as sender id, template-id, approval status, etc. Once the file is successfully uploaded, DLT approved SMS templates will be available in Creatives. These approved templates can then be used in Campaign messages. 

To see how to upload a template and for DLT FAQs, click here.

### OU/MLP filter in campaign creation

This release allows orgs with OUs to filter campaigns of each respective OU on the campaigns listing screen and also allows an org to see the OU name on screen throughout the flow of campaign creation so that they have visibility for which OU they are creating the campaign. 

#### Problem Statement

Many orgs have multiple OUs and there are various issues when we show all the campaigns of all OUs together for such orgs:

It is difficult for users to have visibility on how many and which campaigns are running for each OU.\
When a user is creating a campaign, it is confusing for the users to know for which OU they are creating the campaign.

#### Solution

A campaign-level filter based on OUs is introduced on the campaign listing screen.\
OU name is displayed on screen throughout the campaign creation flow so that users understand which OU they are creating campaigns for.

### MLP support in Engage+

#### Problem Statement

For Orgs with multiple Loyalty Programs, it is very important to uniquely segment customers belonging to different programs and then interact with them through personalized communications. 

*For example:*

Orgs with many partners: Orgs could issue Partner-co-branded loyalty cards to its customers. Customers use these cards during purchases to avail points/ discounts and other benefits. A customer can be part of more than one Partner Loyalty program.\
Conglomerate with a presence in different verticals such as Hotels, Airlines, and Retail - The org unit or brand in these verticals have their own loyalty program. A customer can be part of more than one Loyalty Programs. 

#### Solution

It is required to uniquely identify customers according to the Loyalty Program they belong to and send messages/offers accordingly. Sometimes the org may also want to do some cross-vertical sales. 

For more details, click here. 

#### Enhancements made

1. Scope filter on the Message creation page: This helps you select the target audience belonging to a certain loyalty program only. The selected scope is valid throughout the Campaign Message and thus will get applied to Filters and Labels.

The scope set in Message is also considered when creating an Audience Group. The audience list will have customers of the selected loyalty program.\
The scope is automatically applied to transaction and loyalty filters. 

2. Audience filter scope according to the selected OU

If you set OU scope in a message, then the Audience Group will have customers of the selected Loyalty Program by default.

### Transaction and Loyalty Filters can now understand scope definition -

* **Transaction filter example**: If Loyalty Program/Card Series A is selected and we give the condition “Include customers whose transaction count is 0-5 during specific date range", then only customers of the card series A who have done less than 5 transactions appear in the list.\
   Since one customer can belong to more than one Loyalty Program, 5 transactions might have been done with a combination of Card Series A/B/C. Without passing scope the identification of the right customer is not possible.
* **Loyalty filter example**: If Loyalty Program/Card Series A is selected and we give the condition “Include customers whose active points are in the range of 0-500 then customers who have less than 500 active points with Card Series A will only appear in the list.

   Since one customer can belong to more than one Loyalty Program, less than 500 points might have been with a combination of Card Series A+B+C. Without passing scope the identification of the right customer is not possible.

3. Labels and tags specific to loyalty program

Now labels/tags related to the selected loyalty program will be applied by default when the respective scope is set for the campaign.

For example: If the selected Loyalty program is A and the tag used in creatives is \{\{total\_points\_to\_expire\_day(7)}} then the Card Series A points will be included in the message.

New labels for Card Series (Card Number, Card Issue Date, Card Series Name) have also been added. 

**What's upcoming**

* Multiple Loyalty Programs selection: Marketers will be able to select more than one Loyalty \* Program as scope. If Loyalty Program A, B is selected, then all the customers of both A and B can be targeted for a campaign.
* New filters for Card Series: Card status, card creation, card expiry date, max no. of cards per user, tender code, and tender description.
* Few more card-related labels will be added in OND.
* The following Card Series related filters will be available in the OND quarter: card status, card creation, card expiry, max number of cards per customer, tender code, and tender description.