---
title: "CDP | 21st July '22"
slug: "cdp-21st-july-22"
type: ""
createdAt: "Fri Sep 16 2022 08:08:00 GMT+0000 (Coordinated Universal Time)"
hidden: true
metadata: 
  image: 
    - "https://files.readme.io/a6cd7ed-dbe2b0b-promotions.gif"
    - "dbe2b0b-promotions.gif"
    - 600
    - 269
    - "#000000"
  robots: "index"
---
We have some exciting enhancements in Connect+ that would make your file integration easier!\
[Click here to view the detailed Release Note!](https://docs.capillarytech.com/changelog/cdp-21st-july-22)

### More Secure Integration in Connect+

Continuing our focus on making our products enterprise-ready, we have introduced a few enhancements on Connect+, our no-code integration framework, to facilitate platform-to-platform integration.

#### Encryption and Decryption support

Ensuring data security, especially when data is in transit, is a security measure that any company that shares data with its stakeholders would be invested in. For this, the typical approach taken when sharing data is to encrypt it with a public key and share the encrypted files with stakeholders. Stakeholders can then decrypt the data using a private key for next steps. Similarly, when data is received from stakeholders, the expectation is that the stakeholder will encrypt the data using a public key and then share it back. The company can then decrypt data using a private key.

Until recently, Connect+ did not support encryption and decryption of data in any data flow templates. To address this and upgrade the platform on the security front, we have added support for decryption and encryption in specific templates. 

#### CSV to XML conversion support

In platform integration use cases, we have seen use cases where clients wanted data handback from Insights+ Export Framework to be in XML format. These use cases can now be handled on Connect+ with the new CSV to XML conversion template. Data exported using Export Framework can be unzipped and converted into XML files in batches for client consumption. The XML files can also be encrypted before sending to the client FTP destination. 

#### Header-less File Ingestion

One limitation of Connect+ was its inability to ingest CSV files with no headers. With a recent enhancement, Connect+ now has the provision to ingest headerless CSV files without losing out on any of the data manipulation functionalities that already exist on the product.

<Image className="border" border={true} src="https://files.readme.io/3f68e92-connect_features.gif" />