---
title: "CDP | JFM '23"
slug: "cdp-jfm23"
type: ""
createdAt: "Thu Mar 23 2023 05:12:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes !](https://docs.capillarytech.com/docs/jfm-2023-cdp-releases)