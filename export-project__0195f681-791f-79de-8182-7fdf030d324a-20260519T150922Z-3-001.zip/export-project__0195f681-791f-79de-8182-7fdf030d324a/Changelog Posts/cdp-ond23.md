---
title: "CDP | OND'23"
slug: "cdp-ond23"
type: ""
createdAt: "Fri Jan 19 2024 03:23:32 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/ond-2023-cdp-releases)