---
title: "CDP | JAS '21"
slug: "cdp-jas-21"
type: ""
createdAt: "Wed Sep 29 2021 12:18:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes!](https://docs.capillarytech.com/changelog/cdp-jas-21)!

Enhancements for this quarter.

* Retry Failed Loyalty Events
* Cart Promotions
* OTP Validation for Changing Customer Status

### I. Retry Failed Loyalty Events

On the customer profile page on Member Care, you can now view the list of loyalty events that have failed or are in the queue. In addition, you can also re-trigger failed events from the same page.

This release helps the support personnel whenever they receive calls/tickets from customers regarding loyalty event failures.

![](https://files.readme.io/a42ad9b-l_pending_events.gif)

### II. Cart Promotions

On the customer profile page on Member Care, a separate tab to view Cart Promotions has been introduced, where you can see all cart promotions issued to a customer and cart promotions redeemed by a customer.

![](https://files.readme.io/875bd1e-image.png)

### III. OTP Validation for Changing Customer Status

With this release, you can validate a customer's status change to Deleted status by entering the OTP that is sent to the customer on Member Care. For more details, see OTP Validation for Changing Customer Status.

<Image className="border" border={true} src="https://files.readme.io/f646ee8-otp_validation.gif" />