---
title: "Engage+ JAS 21"
slug: "engage-jas-21"
type: ""
createdAt: "Wed Sep 22 2021 04:21:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes!](https://docs.capillarytech.com/changelog/engage-jas-21)

### Revoke a promotion

This release allows an org to revoke certain promotions that have already been issued to customers.\
With this release, an org can now revoke a loyalty earning or reward promotion for a particular customer and also revoke an earn instance(s) of a particular promotion.

API

* To revoke a promotion(s) for a customer, pass the customerID and promotionID.
* To revoke an earn instance, pass the earnID along with customerID and promotionID.

### Limit the days for unlocking or earning a promotion

With this release, you can limit the days in which a customer can unlock a promotion. This will help to increase the customer's engagement with org more efficiently. You can configure the days in which the customer can unlock the promotion and this feature is available only for a single activity type of earning promotion. 

![](https://files.readme.io/ef1a3c6-promotons.png "promotons.png")

### Configure combo conditions in cart promotions

Earlier a customer could get incentivized even if they fulfilled only one condition out of three, as cart promotion supported ALL and OR based conditions and did check and validate expressions individually.

This feature allows an org to write a condition for combo offers. For example,

* Get chai and Samosa for 20
* Get iPhone and iWatch at 100K
* Buy 1 Shirt and 1 Jeans and get 50% off on Shoes.

![](https://files.readme.io/2230e43-shoes.png "shoes.png")

### Nested sorting logic in cart promotions

Brands were restricted to choose between expiry first or best discount strategy. Now they can decide the primary and secondary parameters for sorting among the two options available.

The promo engine allows brands to set the sorting logic used to decide which promotions to apply if there are multiple promotions applicable on products or carts. Brands could either sort them by Earliest expiry (a promotion that expires first) or Maximum discount, (promotion with the highest benefit).

![](https://files.readme.io/c2115ee-benefit.png "benefit.png")

### Multiple Language Support

**Problem Statement**\
Earlier, brands could display their content on the website and mobile app only in English, which was not understood by people from regions of the world. 

**Solution**\
We supported English as the base language for any configuration or meta around entities, but now we have extended the support to add multiple languages through this feature.

**Scope of the feature**

* **Cart promotions**: Standard or custom fields of offers created using Cart Promotions.
* **Store**: Store-related fields.

![](https://files.readme.io/f2d16da-fields.png "fields.png")

**Use Case**\
**Show promotion and store details in org's preferred language**: Orgs with an online presence (web/mobile app) in languages, other than English, can add translations for the required fields of cart promotion in their preferred language and show translated text on their website using APIs. 

**Before starting**

* You will need to enable the multi-lingual feature for the org.
* Have the support for different languages that you wanted to use. 
* Enable the fields (of cart promotion or stores) for which you need translations.\
  For this, you need to create a JIRA ticket and assign it to the support or project management team with the complete details of the requirement.

*It might take 24 to 48 working hours to enable multi-language/fields for tranlation for the org.*

**Adding translation content**

To navigate to this feature, in the Organization Settings, find an option titled Tools and click on Localize page where you will find the multi-lingual configuration. 

![](https://files.readme.io/e0d0ac6-heree.png "heree.png")

**APIs to fetch details in your preferred language**

*Get configs of a promotion* 

<Table align={["left","left"]}>
  <thead>
    <tr>
      <th style={{ textAlign: "left" }}>
        Request Type
      </th>

      <th style={{ textAlign: "left" }}>
        GET
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td style={{ textAlign: "left" }}>
        Headers
      </td>

      <td style={{ textAlign: "left" }}>
        Content-Type: application/json\
        X-CAP-API-AUTH-ORG-ID: \{\{orgId}}\
        Authorization: \{\{basic auth}}\
        Accept-Language: \{\{languagecode}}
      </td>
    </tr>
  </tbody>
</Table>

<HTMLBlock>{`
{host}/api_gateway/v1/promotions/config?promotionIds={promotionId}
`}</HTMLBlock>

<Table align={["left","left"]}>
  <thead>
    <tr>
      <th style={{ textAlign: "left" }}>
        Request Type
      </th>

      <th style={{ textAlign: "left" }}>
        GET
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td style={{ textAlign: "left" }}>
        Header
      </td>

      <td style={{ textAlign: "left" }}>
        Content-Type: application/json\
        X-CAP-API-AUTH-ORG-ID: \{\{orgId}}\
        Authorization: \{\{basic auth}}\
        Accept-Language: \{\{languagecode}}
      </td>
    </tr>
  </tbody>
</Table>

<HTMLBlock>{`
{host}/api_gateway/v1/promotions/till/{{tillID}}
`}</HTMLBlock>

#### FAQs

**How do we enable multilingual support for our organization?**\
Create a JIRA and assign it to the support or project management team. They will reach out to the respective team. It will take 24-48 working hours to enable this.  

**How to add a new language?**\
Create a JIRA and assign it to the support or project management team. They will reach out to the respective team. It will take 24-48 working hours to enable this.  

**What if I need it for another module apart from promotions and stores?**\
This will require effort from development and will go through the customer request or enhancement process.

### Offer Expiry Reminders

With this release, a notification is sent to a brand's or Capillary's POC before an offer expires. You can now change coupon expiry, issual, redemption settings based on the performance/ usage of coupons. For more details, click [here.](https://docs.capillarytech.com/docs/send-offer-expiry-reminders)

![](https://files.readme.io/2009d85-HERE.png "HERE.png")

### Message Delivery Status

**Problem Statement**\
When an org sends out a campaign message, the org used to receive a delivery report on whether the message was successfully sent or not after 12-24 hours. But customers needed an immediate response. This delay issue contributed to 30%-40% of the gateway issues.

**Solution**\
You can now see the time taken to update the delivery report on the Campaign's Message listing page. In case the delivery rate is not updated even after 12-24 hours, you can raise a ticket. For more details, click [here.](https://docs.capillarytech.com/docs/message-delivery-status)

![](https://files.readme.io/5a9f4da-HE.png "HE.png")

## June Releases

### Promo Engine - Enable cart & catalog promotions

Promo Engine is designed to change the way modern-day promotions are run & managed in-store.

As one of the newly introduced incentive mechanisms offered by Capillary. It brings together Capillary’s market-leading capabilities like event-driven rule-based engine, AI-powered personalization & propensity models, product and activity-based offers, cross-category upselling, and an array of benefits delivering instant gratification at the time of checkout.

**What challenges does it address?**

*Lack of personalization in POS promotions*\
Promotions so far have been a means of mass incentivizing customers on popular products. Modern-day POS’s offer it as a mainstream hook for in-store purchases rather than loyalty building. Customization at scale has become one of the key differentiators to gain customer loyalty and build relationships.

*Limitations imposed by technology at hand to optimize discounts*\
Configuring promotions based on real-time events and customer segments is a luxury few can afford. Even then it is nearly impossible to factor in all variables. 

**How does Promo Engine solve the problem?** 

<Table align={["left","left","left"]}>
  <thead>
    <tr>
      <th style={{ textAlign: "left" }}>

      </th>

      <th style={{ textAlign: "left" }}>
        Brand
      </th>

      <th style={{ textAlign: "left" }}>
        Customer
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td style={{ textAlign: "left" }}>
        Personalize Promotions
      </td>

      <td style={{ textAlign: "left" }}>
        * Tageted promotions  
        * Discount optimization  
        * Flexible program setup  
        * Diverse benefits 
      </td>

      <td style={{ textAlign: "left" }}>
        * Personalized experience  

        * Instant gratification  

        * Relevant offers & more visibility 
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Convenient setup & ease of usage
      </td>

      <td style={{ textAlign: "left" }}>
        * Manage all from one place  

        * Create & optimize on the go  

        * Advanced budgeting control 
      </td>

      <td style={{ textAlign: "left" }}>
        * No OTP or coupon code  
        * Faster checkout 
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Visibility & Control
      </td>

      <td style={{ textAlign: "left" }}>
        * Real-time monitoring  

        * Measure and optimize spends  

        * Multivariate testing 
      </td>

      <td style={{ textAlign: "left" }}>
        * Activate/deactivate  
        * Earn or exchange points for rewards 
      </td>
    </tr>
  </tbody>
</Table>

**Sample use cases**

Fashion retail brands can go beyond popular small ticket items and think more about driving experience to build loyalty

* **Know them better and engage more** - Customers increasingly recognize the value of their data. Offer rewards and better experience as motivation to share their data. For eg. Unlock 10% off Denim products up to $20 on date of birth update or email address update
* **Milestone based** - Get 10% off on the next 5 transactions(min cart amount of $100) once you complete $1000 in annual purchase
* **Experiential hooks** - Gift matching accessories or products to create that experiential hook and gratification. Shop for clothing products worth $200 and get a free Duffle Bag or anti-theft bag

Grocery or supermarket chains can incentivize frequent shoppers with seasonal promotions and upsell long-tail products or bundle them with their regular purchases. 

* **Day & Time-based** - Get an additional 5% off on your grocery purchases above $100 when you shop on Wednesdays between. 11 AM - 1 AM. Max discount of $50 in a single transaction and $200 annually
* **Restrictions** - Buy 3 milk packets and get 50% off on custard flavors. Can be availed twice in a single transaction, 5 times in a month, and max 10 times per customer on selected stores
* **Catalog/SKU** -  With every purchase of frozen products get 20% off on bacon. Offer applicable on category purchases above $100

One of the leading global fuel distributors uses Promo Engine to incentivize partners and individuals to purchase products beyond fuel products. It offers fleet owners rewards for when drivers make purchases while the drivers get promotions like free refreshments such as tea, coffee, biscuits, and other similar items on their regular fueling.

*Few of the live promotions,*

* **Segment-based** - 4 wheeler owners can get free filter coffee ($4/-) or mini cappuccino ($5/-) when customers fuel for $100. Avail once in 7 days and max 5 times
* **Quantity or Unit level** - Discount of $1/gallon when you purchase fuel above 2 gallons. Offer capped to 10 gallons/day and a maximum of 100 gallons in a month
* **The points in their wallet can mean much more** - Redeem 2000 points and get Main Grade fuel worth $50. Offer valid till 31 July on select stations on specific fuel categories

[Vertical specific long list of use cases](https://docs.google.com/presentation/d/15CD4gBtYcy_KHpLp5vlo_vxzoLy7PXal2M3ix7xhpVs/edit#slide=id.gddea5dd438_0_0)

#### Supported promotion types

* **Loyalty promotions**\
  Target promotions issued by broadcasting to loyalty customers For e.g. Get 20% off on Arrow shirts for customers who transacted in the last 90 days.

**\* Loyalty earning promotions**\
Issued in the locked state and on customers completing the activity or milestone For eg. Get 100 off on your purchase by updating your email address

* **POS promotions**\
  These are not issued to customers and apply to any loyalty customers who shop at the POS

* **Reward promotions**\
  These are created and linked to the Marvel rewards catalogue of the brand. Customers can get these promotions by simply redeeming their points. For eg. Redeem 1000 points and get a cold coffee free on your transaction worth $10 or more.

### Mobile design mode in email editor

Our "Drag & Drop" email editor empowers marketers to design emails that supports all devices. After introducing mobile design mode, now marketers can switch between Desktop and Mobile view during the email design and see the preview on mobile devices without going into the preview mode.

![](https://files.readme.io/7c9698a-mode.gif "mode.gif")