---
title: "Incentives+ AMJ'23"
slug: "loyalty-amj23"
type: ""
createdAt: "Thu May 18 2023 04:46:13 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/amj-2023-incentives-release-notes)