---
title: "CDP | OND '21"
slug: "cdp-ond-21"
type: ""
createdAt: "Sat Dec 25 2021 12:09:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes!](https://docs.capillarytech.com/changelog/cdp-ond-21)!

* Card Module Enhancements
  * Support for Card Customer Fields
  * Card Update Event in event notifications
  * Support to get card details on Sharingan
* Authentication for Behavioral Events

### I. Support for Card Custom Fields

By default, we support several standard and extended fields for cards. However, your brand requires storing additional information like card delivery address, chip information, state, or PIN code. Most of such additional fields are of type string and unsupported by default extended fields.

With this release, you can add new field types and custom data to make them align with your requirement.

#### Use Case

Card information that needs to be captured but does not fit into the available card extended fields can now be captured with card custom fields. Some examples can be card delivery address, city, state, pin code etc.

While adding a new custom field for a card, the field scope should be selected as “customer\_card”

<Image className="border" border={true} src="https://files.readme.io/afc609f-card_custom_fields.gif" />

The following APIs now support adding or fetching card custom field details.

1. [GET v2/customer](https://docs.capillarytech.com/reference/get-customer-details-2)
2. [POST v2/customer](https://docs.capillarytech.com/reference/add-customer-1)
3. [POST v2/card](https://docs.capillarytech.com/reference/add-card-details-single)
4. [PUT v2/card](https://docs.capillarytech.com/reference/update-card-details-single)
5. [GET v2/card](https://docs.capillarytech.com/reference/get-card-details)
6. [PUT v2/card/bulk](https://docs.capillarytech.com/reference/update-card-details-bulk)

### II. Card update event in Event Notification

[Card Update Event](https://docs.capillarytech.com/docs/event-schema-payload#points-expired-event-pointsexpired) added to the list of available events in Event notifications. You can now receive events whenever a card is updated via Card Update APIs - PUT v2/card and PUT v2/card/bulk.

#### Use Case

 A notification needs to be sent to the customer once the physical card is dispatched for delivery. Card status labels and card custom fields like address are updated via card update API and a notification is triggered.

### III. Support to fetch Card details on Sharingan

Sharingan now supports fetching the card details of a customer. You can access all card details like card number, series code, card status, label, extended fields, etc.

#### Use Case

Show card details of a customer on a microsite.

### IV. Authentication for Behavioral Events

Earlier, the Webhook API requests did not require even a basic authentication. Anyone could just copy the schema and send requests to Capillary.

You can now secure your Webhook API requests with authentication. The added layer of authentication is extremely helpful in preventing fraud or abuse of data. The ideal case where authentication is effective is when your brand uses behavioral events to reward customers with points or coupons.

To avail of added security, you need to get the authentication enabled for the brand by raising a ticket with the platform team. You are good to go and you can use till credentials for authenticating requests from Webhook API. You can either use Basic Auth or OAuth.

#### Use Case

Brands using Behavioral events for rewarding customers by issuing points/coupons which have monetary value can use authentication to prevent abuse/fraud.