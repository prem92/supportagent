---
title: "Insights | JAS'23"
slug: "insights-jas23"
type: ""
createdAt: "Tue Dec 19 2023 08:22:58 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/release-notes-jas23)