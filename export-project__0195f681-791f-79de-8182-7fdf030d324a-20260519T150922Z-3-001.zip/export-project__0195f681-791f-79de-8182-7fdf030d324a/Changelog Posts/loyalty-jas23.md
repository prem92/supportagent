---
title: "Loyalty+ | JAS'23"
slug: "loyalty-jas23"
type: ""
createdAt: "Wed Jul 26 2023 05:01:18 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/jas23-release-notes)