---
title: "Engage+ JFM 21"
slug: "engage-jfm-21"
type: ""
createdAt: "Tue Mar 30 2021 04:24:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes!](https://docs.capillarytech.com/changelog/engage-jfm-21)

### Support of OU level sender IDs

#### Problem Statement

Many InTouch clients have different org units (OUs) or brands set up within the parent organization. Each of these org units has its own marketing strategy. Hence, clients who have multiple OUs expect Intouch to support OUs across Capillary products.  

As a part of this larger enhancement, Engage+ can now support different sender IDs for each OU to send messages. 

* Only the sender IDs that are tagged to the OU will be available in the message creation flow (refer to step 8). Therefore, an OU will not be able to use the sender IDs of other OUs.
* If no sender ID is tagged to an OU, then the default sender Id of the organization will be auto-populated in the message creation flow(delivery settings).

The following are steps to tag sender IDs to an OU. 

* Navigate to **Organization Settings > Communications & Gateway >  Domains > OU - Sender ID**s Tagging. 

![](https://files.readme.io/8838159-TAGG.png "TAGG.png")

* Navigate to the OU for which you want to configure sender IDs.
* Click Add Sender Domain.
* Choose the Sender Domain in the first dropdown list. 

![](https://files.readme.io/5e34141-LIST.png "LIST.png")

* In GSM sender IDs, select GSM sender IDs to tag to the sender domain. 
* In CDMA sender IDs, select CDMA sender IDs to tag to the sender domain.
* In Default Sender IDs, select the default sender ID for each network type - GSM and CDMA. While message creation, by default, these sender IDs are selected. 

![](https://files.readme.io/ed72496-SEL.png "SEL.png")

*You can tag the sender Ids that belong to another domain of the OU. For that, repeat steps 2 to 6.*

* Click Save.

Once configured, you can check the default sender IDs for each OU, on **Engage+ > New campaign > New message > Delivery settings.** 

![](https://files.readme.io/5f868c1-DEL.png "DEL.png")

*You can also select any of the other sender Ids that are tagged to the OU.*

### Partner broadcast messages

Partner broadcast message is an extension of the No communication - Incentive Only campaign. 

#### Problem Statement

Brands that already have a third-party system to communicate with customers and prefer using Capillary CRM to manage issue coupons and promotions.  

**Solution**\
We have introduced a new FTP channel as an endpoint to campaigns. With this

* a CSV with user IDs and associated tags will be saved to an FTP folder.
* incentives will be issued to customers but no communication will be sent.

To enable no communication:

* On the campaign Content page, enable \**No communication messages.* 

![](https://files.readme.io/bc97a1a-messages.png "messages.png")

You will see an option to **Add FTP location.**

* Set up the FTP location where the exported file needs to save.
* Click on Add column and select the labels to be exported.
* In Message content, enter the message to send.

Once the message is executed, the customer ID along with the selected labels are exported to the defined FTP location. The last column in the CSV file will have the message content after the labels are resolved for the respective user.

For a step-by-step guide to creating Partner Broadcast Messages, view our help doc

### Viber Channel Support

Viber is one of the most popular messaging apps in the Philippines and we have added this as a new channel in Engage+. This will help multinational companies such as Petron, Shell, Abbot, etc. to target customers wherever is popular.

**Subscription**\
Capillary will provide the brands with the subscription API (Update Subscriptions) to capture Viber consent. This API can be used to update consent that can be captured from the customer from different channels such as:

* Point of Sale where the cashier updates it on behalf of the customer.
* Missed call to a phone number.
* Microsite where customers can provide consent that can be distributed as a Campaign or through in-store QR Code scan.
* During the registration flow in a Website or App.

**Integration**\
Capillary has integrated with Infobip (gateway) who will be in charge of sending the actual Viber Messages. Viber enablement requires filling up a form with the below details and sharing the following details with Infobip.

* Brands details
* Description of business
* Status Message
* Images
* What type of messages the brands want to send - promotional or transactional or both, etc.

Infobip will create a verified business account on Viber, map it into their system and provide access to the APIs to Capillary for sending messages.

**Creatives**\
With the Business Account, a brand can send:

* Text Message - Limit is 1000 characters
* Text Message + Image\
  Image can be selected from the computer or gallery (Dimensions: 300px x 400px,Size: 10mb)
* Text Message + Image + Button\
  Button Text (20 Characters) & URL for redirection when clicked. URL needs to shart with https\://

![](https://files.readme.io/0bd0cb0-plo.png "plo.png")

**Reporting**

* Only delivery reports are available. 
* Reports on how many customers saw or opened the message are not available.

**Message Throughput**

* The default speed of a Viber instance is 100 msg/sec.

**Pricing**\
The below rates have been negotiated between Capillary and Infobip. The sales/ CS team should add a margin on the below and share with new/ existing customers.

*Country-wise Viber Pricing in Euros* 

| Countries   | Transactional Charge | Promotional Charges | Monthly fee |
| :---------- | :------------------- | :------------------ | :---------- |
| Philippines | 0.0008               | 0.0012              | 200         |
| Thailand    | 0.0048               | 0.0060              | 200         |
| Vietnam     | 0.0075               | 0.0090              | 200         |
| Malaysia    | 0.0070               | 0.0100              | 200         |

**Support Documentation**

* [Creating content for Viber](https://docs.capillarytech.com/docs/create-viber-content)
* [Creating creative or template for Viber](https://docs.capillarytech.com/docs/create-viber-template)

**Future Roadmap:**

* Allow Viber channel in Message Strategy - Personalisation, Channel Optimisation and X-engage