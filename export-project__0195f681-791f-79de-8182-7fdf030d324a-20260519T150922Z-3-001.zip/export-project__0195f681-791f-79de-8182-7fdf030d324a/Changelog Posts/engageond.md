---
title: "Engage+| OND '22"
slug: "engageond"
type: ""
createdAt: "Tue Jan 10 2023 10:48:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes !](https://docs.capillarytech.com/docs/ond-2022-releases)