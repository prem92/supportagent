---
title: "Engage+ AMJ 21"
slug: "engage-amj-21"
type: ""
createdAt: "Sun Jun 27 2021 04:23:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes!](https://docs.capillarytech.com/changelog/engage-amj-21)

### Social Media CRM Ads - Facebook & Instagram

**Problem Statement**

* CRM marketers have been using direct channels such as SMS, Email, Mobile Push, etc to engage with their customers, whereas, users are increasingly using social media. Hence, it makes sense for CRM marketers to engage customers where they are.
* Telecom regulations are getting stricter and the cost of SMS is increasing. Hence, for brands, social media is a good alternative to SMS. 

**Solution**

* With this release, we support Social media CRM campaigns in Engage+.

**Features**

* Enables marketers to configure CRM campaigns on Facebook, Instagram, and Facebook partner networks directly from Engage+.
* Currently, Facebook & Instagram Image, Carousel, and Video ads are supported.

**Upcoming**

* Google Display Ads will be supported (Post 3 - 4 quarters).
* Performance reports will additionally reflect KPIs reported by the social channel itself  (Post 3 - 4 quarters).\
  For details, see [Create a Facebook Campaign](https://docs.capillarytech.com/docs/create-a-facebook-campaign#explore).

### Attach both offers and point strategy in a message

**Problem Statement**\
Many organizations prefer sending communication to customers with the following functionality. 

* Assign one or more offers to a message and share the offer details such as offer name and voucher code with customers.
* Show the customer's current points and points nearing to expire (in the next 30 days).\
  Earlier, after attaching an offer to a message, it was not possible to attach Points Strategy (Loyalty Program) to that message. 

Loyalty-related tags such as loyalty points, expiring points (in the next 30 days) were unavailable.

**Solution**\
Now, brands can attach both offers and point strategy to a message. 

To attach both offer and point strategy, follow the steps.

* In Content (Creative + Incentive), hover on Add Incentives to see the following options.
  * Add offers
  * Add points

![](https://files.readme.io/4252c4c-points.png "points.png")

> 📘
>
> To create a new offer, see create new offer section.\
> To know more about points strategy, see the points strategy.

* Select Add offers to include offers to the message and preview the added Offers.

![](https://files.readme.io/7b1351a-offers.png "offers.png")

* Select Add points to include points related information to the message. 
  * In Points Strategy, select the loyalty program to issue points to customers in different tiers.

![](https://files.readme.io/c4d24eb-tiers.png "tiers.png")

* Preview the added Points(loyalty program) and click **Continue**.

![](https://files.readme.io/67b17a5-continue.png "continue.png")