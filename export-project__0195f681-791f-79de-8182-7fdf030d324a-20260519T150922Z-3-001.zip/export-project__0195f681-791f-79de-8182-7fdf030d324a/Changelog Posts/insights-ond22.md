---
title: "Insights+ | OND'22"
slug: "insights-ond22"
type: ""
createdAt: "Fri Jan 27 2023 05:33:21 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes !](https://docs.capillarytech.com/changelog/insights-ond22)

# Introducing Expiry Notification Alerts for Exports

### Problem Statement

1. Currently, the end validity for scheduled exports is a maximum of one year and creators of the exports do not receive an expiry alert notification when the schedules are about to expire. 
2. A new duplicate export with a unique name needs to be created every time for the same expired export.

### Overview of the feature

The below image shows the whole overview of the feature. The highlighted feature in **red** are part of the export expiry notification feature release.

<Image align="center" className="border" border={true} src="https://files.readme.io/d954311-image.png" />

### Use cases

* As a brand, I want to know which of my exports are about to expire.

* As a creator of the export, I want to extend the end validity date of my exports before they cross the expiration date.

### Feature Description:

Creators of the scheduled exports can now edit and extend the end validity date of their schedules before the end validity date.

* The creator will be notified **3 days before the end validity date via email** and also **an alert notification** will be placed on the UI under the new bell icon.
* Users can either view the export details or choose to extend the end validity date from the UI as well.

<Image align="center" className="border" width="250px" border={true} src="https://files.readme.io/e6f10ce-image.png" />

* The notification under the bell icon will be available for the 7 **days post-end validity date**. Users can still choose to extend the validity date of the export even if it has crossed the end validity date by editing the export and updating the export.
* Users can view the end validity status for all the scheduled exports on the export schedule listing page. The status definition is as below -
  * **Completed** - Only for exports whose **frequency is once**. The user will receive a notification when the one-time exports are completed.
  * **Ends in 'X' days** - User will be able to see when their exports are about to expire in X days.
  * **Expire** - Exports that have expired and crossed the end validity date.

<Image align="left" className="border" border={true} src="https://files.readme.io/5953ac3-Validity_Date_Extension_GIF.gif" />

**Note - The end validity Date can be edited and extended ONLY by the creator of the scheduled export.**

***

# Introducing BI Tool Connectors

### Problem Statement

Currently, Business intelligence (BI) tools, such as Tableau, Power BI, etc. often require data to be manually imported from Insights+ through exports which can be a time-consuming and error-prone process. Additionally, the data may be in different formats, making it difficult to use BI tools.

### Use cases

* As an analyst, I want to be able to see Capillary's databricks data in another visualization tool.
* As a leadership stakeholder, I want to see data from different sources on one external dashboard.

### Feature Description:

Introducing Capillary's databricks connectors, connectors can help you to import/query data directly in the visualization tool through the databricks data connector. In order to get started, you must have access to databricks. Detailed information to connect can be found here [Steps to connect using BI Tool Connector]()

### Benefits of using databricks connectors -

1. Challenges faced by visualization tools to read and analyze data through export framework can be minimized.
2. Handback data can now be easily visualized on BI tools in a structured format as available in databricks.
3. Seamless flow of information and easy integration with BI tools that also improve the data management process.
4. NO more data migration issues, now you can easily plug and play data in any third-party visualization tool.

### Existing Process

How data is sent to BI tools.

<Image align="center" className="border" border={true} src="https://files.readme.io/455811a-image.png" />

### Using BI Tool Connector

<Image align="center" className="border" border={true} src="https://files.readme.io/e189672-image.png" />

### How to enable databricks connector -

For more details - Steps to Connect using Databricks Connector

<Image align="center" className="border" border={true} src="https://files.readme.io/0ec27bd-image.png" />

***

# We are now more vertical-ready in Insights+

As are moving towards onboarding more brands across verticals such as fuel retail, hospitality, CPG and so on in past years. With this, demands to make the reporting customization have also increased.

We have now introduced the conversion of UI labels in Insights+ for the airline industry. For eg - Currently, across an organization, an airline vertical may not want to see points mentioned anywhere in its reporting view. Instead, you can now enable custom namespace conversion under the organization settings and *points* will be replaced with *miles* across the organization in Insights+.

*Below images show how the UI labels change once the custom namespace feature is enabled.*

![](https://files.readme.io/b373e44-image.png)

<Image align="center" src="https://files.readme.io/99d61a4-image.png" />

/

> *Please note: The feature is now enabled for aviation-focused organizations initially on a pilot basis. We will be rolling out soon for other verticals over the next quarters.*

*You can find the steps to enable this feature here:*[https://docs.capillarytech.com/docs/configure-custom-namespace-for-organisation](https://docs.capillarytech.com/docs/configure-custom-namespace-for-organisation)