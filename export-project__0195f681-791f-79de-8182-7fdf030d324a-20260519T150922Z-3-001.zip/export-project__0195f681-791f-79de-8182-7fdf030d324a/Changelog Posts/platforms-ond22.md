---
title: "Platforms | OND'22"
slug: "platforms-ond22"
type: ""
createdAt: "Tue Jan 10 2023 10:36:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes !](https://docs.capillarytech.com/changelog/platforms-ond22)

## 1. Data Erasure Requests

With the introduction of General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA) acts and the general increase in awareness on data privacy, platforms/businesses that capture sensitive customer data are now expected to allow customers to do the following.

1. Request any data collected from the customers be deleted
2. Request access to the data saved concerning them

As a first step towards becoming Customer-First Data Guardians, Capillary’s data platform is now equipped to handle Personally Identifiable Information(PII) deletion requests. Organizations on the Capillary platform that want to empower its customers to delete PII collected can now use Capillary’s deletion request API for this purpose. Brands can integrate the deletion API on their loyalty apps or web properties and allow customers to raise account/PII deletion requests directly.

### 1.1 How does the deletion process work?

The process will be as follows, assuming the request is raised from an app:

![](https://files.readme.io/9ab2f1c-3BE1FC36-254B-4946-80FC-61142B3B48F1_4_5005_c.jpeg)

There are a few configurations to note here

1. Enable PII deletion - This configuration (CONF\_ENABLE\_PII\_DELETION) needs to be enabled first for the deletion feature to work. The configuration can be found in Organization Settings -> Organization Setup -> PII configurations in Intouch platform.
2. Waiting period - This is an org-level configuration (CONF\_PII\_DATA\_DELETE\_AFTER\_DAYS)  and refers to the number of days up to which the request will be in pending state. After the waiting period lapses, deletion will proceed. Note that the deletion request can be canceled as long as the waiting period has not lapsed.
3. Customer status -  The deletion feature will work only in orgs where Customer Status feature is enabled and at least one status label has been set up against each status.

### 1.2What gets deleted?

The following will be deleted once deletion process is complete.

1. Mobile, E-mail and External ID
2. Cards linked to the customer
3. Custom fields and extended fields (unless organization chooses to retain them - there is a config for this at field level on Intouch)
4. Profiles (including WebEngage)
5. Communication channel
6. Credentials in Auth Engine
7. Any logs that have PII - Audit logs, identifier change logs and so on
8. Payment modes and attributes (against transactions)
9. dentifiers (used for transactions)

Note that events data such as transactions, points/points-related data, behavioral events, coupon issual/redemptions and so on will not be deleted. These will continue to remain on our platform along with the user identifier of the customer.

### 1.3Member Care Implications

Deleted customer profiles cannot be viewed on Member Care as of now as profiles will not be searchable. Even if you view a profile using a URL that points to a deleted customer profile (via user ID), Member Care will say that the customer is not found.

Also, as of now, there is no front end yet on Member Care to view/approve deletion requests. This front end will be built in JFM '23. 

## 2.Transaction Approval Workflow

A new type of request entity - transaction request - was built last quarter to support Customer Service Representative (CSR) workflows for receipt scan-based loyalty programs. In receipt scanning loyalty programs, which are typically run by Consumer Packaged Goods(CPG) companies, customers make a purchase at a store, scan the purchase receipt and upload it to an app or web portal of the company running a loyalty program to earn points. 

In this workflow, the interpretation of the uploaded receipt is typically done by a receipt scanning service that is able to identify the line items (specific to the company), quantity, amount and other relevant details and then make a transaction add call to the CDP for earning rewards. This interpretation of receipts by the scanning service might be inaccurate at times and the receipt will have to go through a manual review process by CSRs of the brand. 

CSRs can now review the content via Member Care of the transaction and images of receipts uploaded by the customer, modify it if needed and then approve it so that the transaction is captured and points are issued to the customer. 

![](https://files.readme.io/8a134e2-image3.gif)

Note that the frontend that is shown above is not natively built on Member Care. It has been built on Sharingan, Capillary’s micro site builder, and integrated into Member Care. This is part of our initiative to transform Member Care into an extensible platform where brands can add their own pages and customer profile actions.

## 3. User Groups on Member Care

User group view is now available on Member Care new UI. Think of this as something similar to the customer view but for groups. Similar to the customer view, you will now be able search for a group - using group external ID or primary member identifiers and view information such as

1. Group details - Name, identifier, status, attributes, primary member details and associated company details (if available)
2. List of members and points contribution (downloadable in Excel as of now)
3. Loyalty details - Group slab, points summary and tracker details
4. Group transactions - Along with details on members who made the transactions

![](https://files.readme.io/939d5e1-image1.gif)

That apart, if user group feature is enabled for the organization, the customer view will also have some additions including

1. List of groups the customer being viewed is part of (downloadable in Excel as of now)
2. Company hierarchy including parent and child details (if available)

### 3.1Upcoming Enhancements

Note that this feature is in beta and under active development. The following details are expected to be added soon:

3.1.1 Group View

* Widget to view list of members and member details

* Points ledger screen in group view to see loyalty events

* Goodwill points issual action

* Group transfer action

  3.1.2 Customer View

* Widget to view list of groups and group details

* Hierarchy screen to navigate across/view company hierarchy