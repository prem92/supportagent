---
title: "Loyalty+ | OND'22"
slug: "loyalty-ond22"
type: ""
createdAt: "Fri Jan 27 2023 07:26:05 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes !](https://docs.capillarytech.com/docs/ond-2022-loyalty-releases-copy)