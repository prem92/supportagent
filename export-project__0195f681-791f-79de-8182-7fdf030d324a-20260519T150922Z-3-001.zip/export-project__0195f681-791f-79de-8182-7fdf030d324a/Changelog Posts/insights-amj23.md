---
title: "Insights+ | AMJ'23"
slug: "insights-amj23"
type: ""
createdAt: "Wed Jul 19 2023 08:05:07 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/release-notes-amj23#masking-pii-data-on-the-databricks)