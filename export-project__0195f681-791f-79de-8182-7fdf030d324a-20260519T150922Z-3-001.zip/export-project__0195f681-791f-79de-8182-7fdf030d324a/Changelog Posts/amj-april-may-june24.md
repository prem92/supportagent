---
title: "April-May-June '24"
slug: "amj-april-may-june24"
type: ""
createdAt: "Fri May 24 2024 10:14:53 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
* **[Insights+](https://docs.capillarytech.com/docs/release-notes-amj24)**
* **[Loyalty+](https://docs.capillarytech.com/docs/amj-2024-loyalty-release-notes)**
* **[Incentives](https://docs.capillarytech.com/docs/amj-2024-incentives-release-notes)**
* **[Engage+](https://docs.capillarytech.com/docs/release-notes-amj24)**
* **[Capillary Platform](https://docs.capillarytech.com/docs/amj-2024-cdp-releases)**