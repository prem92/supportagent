---
title: "Insights+ | JFM'23"
slug: "insights-jfm23"
type: ""
createdAt: "Fri Apr 07 2023 10:59:05 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release Notes](https://docs.capillarytech.com/docs/release-notes-jfm-23)