---
title: "Engage + JAS 22"
slug: "engage-jas-22"
type: ""
createdAt: "Thu Oct 06 2022 10:29:07 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed release note!](https://docs.capillarytech.com/changelog/engage-jas-22)

> **These are the product enhancements and new changes that have been introduced to Engage+ in the quarter JAS'22.**

## CONTENT

1. WhatsApp channel - Changes in Campaign Integration for Karix\
   I. Support CTA buttons\
   II. Media Support (only available with Tanla and not available with Twilio)\
   III. CTA Dynamic url for karix (not for twillio)\
   IV. Unsubscribe is optional
2. Journey UI Product Filter
3. Test and Control in Journey
4. DLT Enhancement
5. Push  Channel -  Journey
6. Engage+ filter requirement
7. Card-based filter in the Engage+ Audience
8. MLP Scope in Campaigns

### 1. WhatsApp channel - Changes in  Campaign Integration for Karix

Capillary Technologies has provided integration of Whatsapp channel for Katrix. This quarter we have made a few new and exciting changes where we have added new gateways in Whatsapp Channel. Here we are supporting the CTA buttons along with the whatsapp messages, adding media(Image) as a part of whatsapp message, and also Dynamic call to action URLs for a better and smooth experience for customers of Katrix.\
This new change is going to make a good impact on customer engagement and uplift the personalized experience of customers through whatsApp channel.

#### I. Support CTA buttons

* **Problem description**

These days customers(specifically GenZ and Millennials) are too much busy in daily life that they are willing to somehow avoid the time consumed on websites and apps while using them for certain different reasons. Due to this many times even after knowing about the offers and sales running people are not actually going on sites and using those offers.\
 **The communication sent through WhatsApp in text format is less engaging and not enough for the customers and much more time-consuming for them to reach the pages or websites that companies wanted the customers to visit.** *\*Generally LINKs are used for this purpose\`*\*

* **How are we solving this Problem**
  1. For making the interaction of customers more engaging and more worth it we are introducing ***Call to Action Buttons*** support within the sent communications
  2. Here we will be able to send Buttons embedded with the URL links which will directly take the customers to the webpages where previously it was too sluggish process for them to reach.
  3. Currently, Capillary's WhatsApp Channel supports a maximum of two types of CTA buttons that one org can send with a single message at a time, these **Type of action** are -\
     **(a) Phone number. (b) Websites**

<Image className="border" border={true} src="https://files.readme.io/3b9a98b-image.png" />

<Image className="border" border={true} src="https://files.readme.io/6133b94-image.png" />

4. > 👍 NOTE
   >
   > * If the org want to send both the buttons at a time, they have to click on  **+Add the button**  to adding the second button. 
   > * Org can not use same kind of button for more than once.\
   >     eg. Org can't use to website buttons or to phone number button.

5. To use this feature you can refer to the documentation.

* **Use Cases to understand the product features**\
     **Case 1**
  1. Assume an org "ABC" is a fashion brand and wants to inform the customer about the live sale for all the customers running on the official website,
  2. So to inform the customers, the org sends a WhatsApp message to them on their registered contact numbers.
  3. Now the org wants that the customer should directly open the page where they can see the active offers.
  4. So now using  CTA buttons the org can directly add the URL link of the webpage to the button and can send the message along with the button to the customer. Here the org has to use **websites** under the ***type of action*** dropdown and have to copy website URL where org wants customers to redirect.
  5. Now when the customer curiously will tap the button, the customer will be redirected to the live sale webpage of the org's website.\
     **Case 2**\
     In case of adding mobile no. button for the triggering customers to directly **call** and contact the org for any enquiry one has to select **Phone number** in the ***Type of Action*** dropdown.

#### II. Media Support (only available with Tanla and not available with Twilio)

* **Problem Description**

These days long and text-heavy communications sent the customers for any purpose are unhealthy communication in terms of responses and success rates of those communications sent in the campaigns. As these days customers are more and more attracted to media as compared to written communication. So it is a desired requirement for having an option of adding media while sending a communication through WhatsApp.

* **How we are solving this problem?**
  1. Inside the WhatsApp communication channel, we have introduced the option of adding media. (Currently supporting image)
  2. Here you can directly drop the image or select the image file from the computer which you want to send as a communication message through WhatsApp as a communication.
  3. The format of the image that is accepted is - JPEG.JPG.PNG\
     Size supported - up to 5MB\
     Maximum aspect ratio - 1.91:1
  4. To understand how to use this feature you can refer to the documentation.
* **Use case to understand product features.**
  1. Consider that the org wants to inform their customer about the new arrivals of amazing watches in their offline/online stores.
  2. Now to attract customers and to make communication more engaging they can attach template images showing the watches inside the image and informing about the offer-related things.
  3. Refer to this screenshot to understand how will it look -

#### III. CTA Dynamic URL for karix (not for twillio):

* **Problem description**\
  While adding buttons for the website we are only having an option to add the Static URL in the *URL type*. Here we were only having a fixed result on clicking the button to which the URL is integrated. The result was independent on any user-related or page webpage-specific parameters.
  > A static URL is one in which the content of the web page remains the same as long as the changes are not hard coded within the HTML.
* **How we are solving this problem?**
  1. So now we have introduced the option of adding **Dynamic URL** in the section of *URL type*.
  2. What is a dynamic URL?\
     A dynamic URL is an address - or Uniform Resource Locator (URL) - of a Web page with content that depends on variable parameters that are provided to the server that delivers it. The parameters may be already present in the URL itself or they may be the result of user input.
  3. Now while selecting URL type in the drop-down orgs will be able to see the option to add a dynamic URL.
  4. eg. Landing pages are  have***Static URLs***\
     OTT platforms (eg. Netflix) have ***Dynamic URLs***

![](https://files.readme.io/a1c4596-image.png)

5. To understand how to use this feature you can refer to the documentation.

* **Use case to understand the product feature**
  1. let's say you got a button attached to the message sent on whatsApp by an XYZ e-commerce platform Informing you about the 50% sale.\
     You tap on the button to visit the website -
  2. Now in case, the button is ***static***: the home page of the website will open where you **have to login** and this page will be the same for all the users
  3. But in the case of ***Dynamic Button***: the page that will open will already have the user details logged in by using your Google account.

#### IV. Unsubscribe is optional

* **Problem Description**\
  Our clients were not much satisfied with the default unsubscribe option along with the communication messages we were sending through WhatsApp.
* **How we are solving this problem?**
  1. The change that we have made to solve this problem is that now the **unsubscribing has become optional and is now org-dependent.**
  2. This will be totally upon orgs to decide whether they want to keep the unsubscribe button with the message or not.
  3. While WhatsApp message creation flow when you select the Text as a communication medium, under the message writing box you will be able to see a check box where you can select either you want to send Unsubscribe as an option or you don’t want that button.
  4. To understand how to use this feature you can refer to the documentation.

<Image className="border" border={true} src="https://files.readme.io/8939fd7-image.png" />

### 2.Journey UI Product Filter

Introducing the Journey’s Product Filter. Now we can filter the users on the basis of transactional behavior by the filter “ Basket sum with the product”. This will help the orgs to put up the different conditions for the customers on the basis of Brands, Categories, and Product types that they had purchased in past.

* Problem Description\
  We want to categorize the customers on the basis of their product-wise purchase behaviors to improve their experience in a more and more personalized way. This will help our clients to engage with their customers in a more personalized way specific to the kind of products they have purchased.
* How we are solving this problem?

  1. To solve the mentioned problem a new product enhancement has been done in the filters while making the journey. 

  2. This is called the Product filter, Which will help us to categorize and filter the customers on the basis of the product they have purchased, the product categories they have purchased, or the brand of that product.

  3. You can find this filter while setting up the entry trigger. This will come under the user event where the filter will examine the customer's current transaction. 

  4. While adding the entry path conditions you will find this filter named **"basket sum with product"**

  5. To understand how to use this feature you can refer to the documentation.

> 📘 **NOTE**
>
> * You can select all three conditions for line item in a single condition. For this just you have to go and click the **+/-Additional condition** buttton where you can select the **Attributes**(Brands, category and product) or upload **SKU** list as a csv file. Refer the image attached below.

* **Use cases to understand product features**
  1. Case 1: let us assume a case that an XYZ org wants to onboard those customers on the journey -
     * 1. * Who has purchased a *product* Laptop with basket sum *greater than* 10000 USD that comes under the electronics *category*?
          1. Here the org have to mention the amount (i.e 10000 USD) - basket sum, grater to which they want to filter the product.
          2. Now for this case, the org has to use this above-mentioned product filter called **"Basket sum with product"**.
          3. Here they have to select the attributes Category and Product type by clicking the **+/-Additional Condition** button.\
             Refer to the image below to understand the configuration.
          * 1) 1)

<Image className="border" border={true} src="https://files.readme.io/3d77b10-image.png" />

<Image className="border" border={true} src="https://files.readme.io/84df182-image.png" />

2. Case 2: Consider a  case where the org wants to onboard those customers in the journey, who have purchased the product with the mentioned SKUs in a specific csv file.
   1. Here in the **+/-Addition condition** section they will select SKU instead of attribute.
   2. here they have to upload a **CSV file**.\
      Refer to the image to understand the configuration.

<Image className="border" border={true} src="https://files.readme.io/e875874-image.png" />

<Image className="border" border={true} src="https://files.readme.io/f21939c-image.png" />

### 3. Test and Control in Journey

We have introduced the test and control feature in Journey too. This will help the marketer to understand the campaign performance and cohort behavior, which will enable marketers with better insights. Hence, will enable marketers to run performative engagement strategies on the audience group.

* **Problem Description**

There is always a demand from the clients to know about what is the hit rate and Incremental sales because of the Journey campaign they are using. So some actions are required to calculate the required that will help the clients to get the data to track the success of the campaigns.

* **How we are solving this problem?**\
  We have Test and Control functionality in engage+ product at the global level and at each campaign level, which is successively used by brands. Given, that we are introducing the Journey product, moving the current timeline and DVS customers to Journey we would need to support the global test and control. Additionally, test and control functionality will enable marketers to derive better insights from the journey engagements ran.

**How to set up Global test and control in Journey Campaign?**

* Orgs which has already configured test and control in settings, the same config would be considered as input for journey product.
* Orgs which does not have it configured yet, there would be no group of control user but as soon as configured the logic should start working for them.\
  **Reporting**\
  Following KPIs would impact the functionality -

*Hit rate* - The ratio of the total Customer who Responded and the total Customer Contacted\
*Incremental sale* - ((Test Hit Rate - Control Hit Rate) *(TEST Responders Spend per Customer)* (Test Customers Contacted))/100

### 4. DLT Enhancement.

Previously while doing the SMS Registration the maximum no. of characters for the sender Id was restricted to 6 characters but after the enhancement, it has been changed to the range of 3-9 characters. This will increase the possible sender ids and can range a larger no. of customers.\
**Message Categories**\
For DLT-enabled orgs, the following are the three different SMS categories available.\
Promotional: Any message sent with the intention to promote or sell a product, goods, or service. Service content mixed with promotional content is also treated as promotional. A sender ID of 3-9 numeric digits needs to be used. Promotional messages sent to non-registered customers after receiving their consent will come under the category of Service Explicit.\
Service Explicit: Any service message which doesn’t fall under the category of service message (inferred consent) will be considered as Service explicit message. To send such messages, the Sender ID of 3-9 alphabetic characters needs to be used. Promotional messages sent to registered customers after receiving their consent will come under the category of Service Explicit.\
Service-Inferred/Implicit: Any message, arising out of the customer's actions or their relationship with the sender, that is not promotional, and is not in the interest of the customer to block. Sender ID of 3-9 alphabetic characters needs to be used. Notifications such as order confirmations, payment alerts, purchase updates, website/app login OTP, and other vital updates can be transmitted from Service Implicit route.

### 5. Push Notification - Journey

* Similar to the Broadcast campaign now we are introducing the Push Channel as a new engagement block in Journey campaigns. By adding push channel we want to increase the Omni channel engagement capability of our journey campaigns.
* **Why required?**
  1. Increase Omni channel capabilities of our product.
  2. Enhance the digital marketing capabilities of our product.
  3. Provide marketers with complex journey flows with the addition of engagement blocks etc. with detailed insights from channels like push notifications.
* **How it works?**
  1. You will be able to see the Engagement block with the name **Push Notification** in the engagement section. on the left.(refer to the image attached)
  2. You can add the M-Push engagement block to the journey just by picking and dropping the block from the engagement section to the journey.
  3. To configure this click on the setting icon that will appear when you will hover over the m push block inside the journey.

<Image className="border" border={true} src="https://files.readme.io/d0c116f-image.png" />

4. Users should be able to select the account of Push Notification, we will show accounts on choosing page before configuration.

<Image className="border" border={true} src="https://files.readme.io/5b1efdc-image.png" />

5. Users can create from scratch or select from already existing templates.
6. Once the user has selected/created the template, the push notification block's content would be configured.

### 6. Engage+ filter requirement

* **Problem description**
  1. Client want to reach out to customers who are not as frequent in the current month(or period A) as compared to the previous month(or period b). Through right communication and offers frequency needs to be maintained if not improved.
  2. All marketing team highlighted that they need the below filter as it is a very frequent requirement for them
* **How are we solving this problem?**
  1. On the clients requirement we are introducing a new filter which is **"No. of Transactions"** where orgs will be able to filter the audience on the basis of no. of transactions they have made in the mentioned time period.
  2. You can get the customer's details based on the number of transactions in a specific period of time.
  3. You can select the range using the operators Greater than equal, Less than equal, Equals, and In the range of (this also considers the minimum and maximum transaction count mentioned).
  4. You can also choose the duration by specifying the specific date or relative date or lifetime. Also you can narrow down the duration by adding more fields by clicking **+/- Fields** 
  5. Click on apply to see the result of filtered audience. Refer the screenshots below for more understanding.
  6. Tap the [link](https://docs.capillarytech.com/docs/transaction-based-filters#no-of-transaction) to understand this more in detail.
* **Use case to understand the product filter**

**Case 1.**\
**Filter condition**: Customer transacted xx (8-30 times / range) times in a month(March / selected dates) and then made  at least Y(3) less transactions in the next month( April / selected dates)

**Example**

1. Customer A transacted 15 times in Mar 2022 and then transacted 10 times in Apr 2022\
   Will be counted because in Mar - no of transactions falls in the range(8-30) and in Apr  - the number of transactions decreased by at least 3 transactions.
2. Customer A transacted 15 times in Mar 2022 and then transacted 13 times in Apr 2022\
   Will not be counted because in Mar - no. of transactions falls in the range but in Apr  - the number of transactions decreased by less than 3 transactions.
3. Customer A transacted 5 times in Mar 2022 and then transacted 1 time in Apr 2022\
   Will not be counted because in Mar - no. of transactions does not fall in the range

**Case  2.**

1. Let the **Filter condition**is :  Include customers whose total transaction count is in range of 100 to 1500 between 26th Sep'22 and 29th Sep'22

<Image className="border" border={true} src="https://files.readme.io/e12335a-image.png" />

2. So as we can see in the example that out of total no. of audience of 4349578 after applying the filter we only get 14  customers that come under the scope of this filter.

<Image className="border" border={true} src="https://files.readme.io/9f8ffce-image.png" />

### 7. Card based filter in the Engage+ Audience

**Feature description**

* We have introduced the new **Card series filter** in the audience manager which is going to filter out the audience on the basis of card series.
* Currently we have introduces three sub category filters -
  1. **Card status**\
     Here the audience with specified card status will be filtered out from the selected customers.\
     Card status could be : card deleted, expired, deleted ,suspended, card generated , active, card expired ,card blocked, and not issued.\
     **Example:**XYX org want to filter out customer with **Active** card status from all the loyalty customer.

<Image className="border" border={true} src="https://files.readme.io/d932a1f-image.png" />

<Image className="border" border={true} src="https://files.readme.io/963a933-image.png" />

2. **No. of Card**\
   This filter will include/exclude the customer who have "x" no. of cards during the specified duration. Here durstion can be specified dates or relative dates.

   **Example**: Lets take a case where we have "A+B+C" no of total customers and we want to include the customers who have cards equal to "x" in number. That too between the date range of 25th sept 22 to  28th sept 22.\
   After applying the filters we got B no of such customers who have x no. of cards.\
   Refer the screen shot to understand the example 

<Image className="border" border={true} src="https://files.readme.io/640eaac-image.png" />

<Image className="border" border={true} src="https://files.readme.io/5bbb4ea-image.png" />

3. **Card creation:**\
   In this filter you can filter out the customers on the basis of dates in which card is created. Here either you can select the specific dates or the relative days for specifying the duration.\
   **Example**: Org XYZ wants to include the audience who have created there card in the Specific date duration between DD/MM/YYYY to DD*/ MM*/ YYYY\*.\
   Refer the Screenshots attached below to understand the filter,

<Image className="border" border={true} src="https://files.readme.io/b03af05-image.png" />

![](https://files.readme.io/6d301e7-image.png)

### 8. MLP Scope in Campaigns

Many organizations either conglomerates or single entities might require to configure multiple loyalty programs.

* Large conglomerates may require to set up different loyalty programs for their sub-organizations.\
  **For example:**\
  A conglomerate that operates in different verticals such as hotels, airlines, retail, etc. under different brand names. All these brands have their own loyalty program. Again, a customer can be part of more than one Loyalty Program.
* An organization may partner with various other companies and have different partner-loyalty programs with different partners.\
  **For example:**\
  A petroleum company has partnered with many companies. It has rolled out partner-loyalty programs with 130+ partners. It gives partner-co-branded loyalty cards to its customers. Customers use these cards during purchases and avail of points/discounts and other benefits. Again, a customer can be part of more than one partner-loyalty program.

**Enhancements**

To use this feature, follow these steps.

* The Loyalty program can be selected from the dropdown menu. Search functionality is also provided for ease of use.
* Since there can be multiple Card Series/ OUs belonging to the same Loyalty program, the selection needs to be done at the Card Series or OU level.

Usage example:

* For orgs, one loyalty program may encompass multiple card series. Hence, the scope can be selected at the Card Series level. Marketers can select Loyalty Program > Card Series.

* For Petron Org, however, there is a 1-1 mapping between loyalty program and card series hence the scope can be selected at Card series structure.\
  1366

* For orgs such as Tata, one loyalty program like the Tata Group Loyalty Program may encompass loyalty programs for different OUs such as Titan, Tanishq, etc. Hence the scope can be selected at the OU level and hence marketers can select Loyalty Program > OU.

* ![](https://files.readme.io/cc9b376-image.png)

* Creating Audience by applying Filter:

* **Label resolution for content will be as per the selected scope:** If for any message scope is ‘not-None’ then for Label resolution the selected Loyalty Program is passed as scope. The Loyalty and card-related Labels/ tags will get resolved for the respective Program only.\
  **For example:** If the selected Loyalty program is A and the tag used in creatives is \{\{total\_points\_to\_expire\_day(7)}} then the Card Series A points will be mentioned in the message.

* New Labels for Card Series (Card Number, Card Issue Date, Card Series Name) have also been added.\
  **Usage Nuance:**\
  For a petroleum company, one customer can have more than one card from the same Card series/ Loyalty Program. In case of any conflict on tag resolution, the card which was more recently used in a transaction or recently registered will be used.

![](https://files.readme.io/2e0415c-image.png)