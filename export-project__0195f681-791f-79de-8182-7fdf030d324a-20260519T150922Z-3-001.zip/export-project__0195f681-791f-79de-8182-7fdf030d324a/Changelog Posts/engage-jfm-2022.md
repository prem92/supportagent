---
title: "JFM 2022 | Engage+"
slug: "engage-jfm-2022"
type: ""
createdAt: "Thu Jul 14 2022 11:14:11 GMT+0000 (Coordinated Universal Time)"
hidden: true
---
* **Enhanced Drag & Drop Email Editor**  
* **Connect with your customers on WhatsApp**
* **DND Customer database enhancements**

### Enhanced Drag & Drop Email Editor

An enhanced Drag-and-drop editor for emails to improve the overall user experience and ease the content editing experience. You can now see the following improvements -

Title\
Title as a block has been introduced in the Content block of the drag and drop editor. This helps in establishing a hierarchy in the content while creating an email.

Paragraph\
You can see it in the **Content** block of the drag-and-drop editor. You can use any number of paragraphs of any length that share the same content formatting, such as font family, font size, and font weight.

List\
You can see it in the Content block of the editor. It provides specialized support lists with improved styling options, font management, copy-paste operations, and formatting options same as the **Paragraph** block.

For more details, see [here](https://docs.capillarytech.com/docs/jfm-2022-engage-releases#enhanced-drag--drop-email-editor).

### Connect with your customers on WhatsApp

Engage+ now supports WhatsApp as a native channel for Broadcast Campaign messages. WhatsApp is the most popular messaging app for the last 10 years with a Monthly Active User base of 1.6 Billion. Below features make this channel more interactive and efficient:

* Rich media messaging such as text, video, location, picture, voice, document, buttons, etc.
* Reliable delivery report information eg: sent, delivered, read, etc.
* Higher and faster delivery and read rate than other channels.
* Official certified account, higher user trust.

For more details, see [here](https://docs.capillarytech.com/docs/jfm-2022-engage-releases#connect-with-your-customers-on-whatsapp)

### DND Customer database enhancements

Brands or Gateway companies did not have direct access to the DND customer database. The current DND status against any customer profile in the Capillary database is not accurate.

We have made the following changes in Engage+ due to above-mentioned reasons:

* Through Engage+ brand can reach out to all customers and won’t honor the current NDNC status in Capillary’s database.
* Removed the option of “Send to NDNC customers” from Campaign Message delivery settings.
* Removed NDNC-related filters from Audience Manager.

For more details, see [here](https://docs.capillarytech.com/docs/jfm-2022-engage-releases#dnd-customer-database-enhancements)

### New filters in Audience Manager

To boost customer engagement through campaigns, we offer various types of filters to help the user in targeting a precise audience set. We continuously try to add valid filters so that brands can have more edges while creating an audience base for running campaigns.

* **Shopped for distinct products/categories/attributes**\
  This lets you filter audiences who have shopped a particular product (Item) n times in different transactions.\
  For more details, see [Shopped for distinct Product/Category/Attribute](https://docs.capillarytech.com/docs/jfm-2022-engage-releases#1-shopped-for-distinct-productscategoriesattributes)
* **Average Item Value:**\
  This lets you filter out the audience on their average spending on selected items.\
  For more details, see the [Average item value filter.](https://docs.capillarytech.com/docs/jfm-2022-engage-releases#2-average-item-value)
* **Favorite product at the item level**\
  This lets you filter out the audience on their absolute amount spent on respective selected items.\
  For more details, see [Favorite Product at the Item Level.](docs.capillarytech.com/docs/jfm-2022-engage-releases#3-favorite-product-at-the-item-level)