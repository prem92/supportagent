---
title: "Loyalty+ | JFM'23"
slug: "loyalty-jfm23"
type: ""
createdAt: "Fri Jan 27 2023 08:21:04 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Detailed Release Notes !](https://docs.capillarytech.com/docs/jfm-2023)