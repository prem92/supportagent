---
title: "Jan-Feb-March '24"
slug: "jfm24"
type: ""
createdAt: "Wed Feb 21 2024 06:42:05 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
Release notes for the features released in the first quarter of 2024:\
**-[Engage+](https://docs.capillarytech.com/docs/jfm2024-engage-release-notes)**\
**-[CDP](https://docs.capillarytech.com/docs/jfm-2024-cdp-releases)**\
**-[Loyalty+](https://docs.capillarytech.com/docs/jfm-2024-loyalty-releases)**\
**-[Incentives](https://docs.capillarytech.com/docs/jfm2024incentives-release-notes)**\
**-[Insights+](https://docs.capillarytech.com/docs/release-notes-jfm24)**