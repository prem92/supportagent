---
title: "Loyalty | OND'23"
slug: "loyalty-ond23"
type: ""
createdAt: "Thu Jan 11 2024 11:32:29 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/ond-2023-loyalty-release-notes)