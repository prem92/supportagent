---
title: "Engage+ JAS 2023"
slug: "engage-jas-2023"
type: ""
createdAt: "Mon Oct 16 2023 07:17:08 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[Release notes](https://docs.capillarytech.com/docs/jas-2023-engage-release-notes)