---
title: "July-August-September '24"
slug: "july-august-september-24"
type: ""
createdAt: "Wed Sep 25 2024 04:34:56 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
* [**Loyalty+**](https://docs.capillarytech.com/docs/jas-2024-loyalty-release-notes)
* [**Incentives**](https://docs.capillarytech.com/docs/jas-2024-incentives-release-notes)
* [**Capillary Platform**]()
* **[Engage+](https://docs.capillarytech.com/docs/jas-2024-engage-releases)**